﻿using System;
using System.Linq;
using System.Data.Entity;
using System.Linq.Expressions;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.DataContext;

namespace SD.Rough.Average.Data.Repositories
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : BaseEntity
    {
        internal BaseDbContext _dbContext;
        internal IDbSet<TEntity> _dbSet;

        public Repository(BaseDbContext context)
        {
            _dbContext = context;
            _dbSet = context.Set<TEntity>();

            //_dbContext.Database.Log = x => System.Diagnostics.Debug.WriteLine(x);
        }


        public virtual TEntity GetById(int id) => _dbSet.Find(id);
        public virtual IList<TEntity> GetAll() => _dbSet.ToList();

        public IList<TEntity> GetWithTracking(Expression<Func<TEntity, bool>> predicate) => _dbSet.Where(predicate).ToList();
        public IList<TEntity> Get(Expression<Func<TEntity, bool>> predicate) => _dbSet.AsNoTracking().Where(predicate).ToList();
        public IList<TEntity> Get(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> query = _dbSet;

            foreach (var prp in includeProperties)
            {
                query.Include(prp);
            }

            return query.Where(predicate).ToList();
        }

        public TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate) => _dbSet.FirstOrDefault(predicate);
        public TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> query = _dbSet;

            foreach (var prp in includeProperties)
            {
                query.Include(prp);
            }

            return query.FirstOrDefault(predicate);
        }

        public IQueryable<TEntity> Select(Expression<Func<TEntity, bool>> predicate = null,
                Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                List<Expression<Func<TEntity, object>>> includeProperties = null,
                int? page = null, int? pageSize = null)
        {
            IQueryable<TEntity> query = _dbSet;

            if (includeProperties != null)
                includeProperties.ForEach(prop => { query = query.Include(prop); });

            query = predicate != null ? query.Where(predicate) : query;

            query = orderBy != null ? orderBy(query) : query;

            query = (page != null && pageSize != null) ? (query.Skip((page.Value - 1) * pageSize.Value).Take(pageSize.Value)) : query;

            return query;
        }

        // TODO: Refactoring - Do not expose IQueryable from repository
        public IQueryable<TEntity> Select(Expression<Func<TEntity, bool>> predicate,
            params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> query = _dbSet;
            //foreach (var prp in includeProperties)
            //{
            //    query.Include(prp);
            //}
            return query.Where(predicate);
        }

        public bool IsEntryExists(TEntity entity) => _dbSet.Local.Any(e => e == entity);

        public bool IsEntryExists(Expression<Func<TEntity, bool>> predicate) => _dbSet.Any(predicate);

        #region DataChangesMethods
        public virtual TEntity Add(TEntity entity)
        {
            //_dbSet.Add(entity);
            return _dbSet.Add(entity);
        }
        public virtual IList<TEntity> AddMany(IEnumerable<TEntity> entities)
        {
            IList<TEntity> resultData = new List<TEntity>();
            foreach (TEntity entity in entities)
            {
                resultData.Add(Add(entity));
            }
            return resultData;
        }

        public virtual TEntity Update(TEntity entity) => AttachEntry(entity);
        public virtual IList<TEntity> UpdateMany(IEnumerable<TEntity> entities)
        {
            IList<TEntity> resultData = new List<TEntity>();
            foreach (TEntity entity in entities)
            {
                resultData.Add(Update(entity));
            }
            return resultData;
        }

        /// <summary>
        /// Hard Delete
        /// </summary>
        /// <param name="entity"></param>
        public virtual void Delete(TEntity entity)
        {
            //AttachEntry(entity, EntityState.Deleted);
            var entry = _dbContext.Entry(entity);

            if (_dbContext.Entry(entity).State == EntityState.Detached)
                _dbSet.Attach(entity);

            _dbSet.Remove(entity);
        }

        /// <summary>
        /// Hard Delete
        /// </summary>
        /// <param name="id"></param>
        public virtual void Delete(int id)
        {
            var entity = _dbSet.Find(id);

            if (entity != null)
                Delete(entity);
        }

        /// <summary>
        /// Hard Delete
        /// </summary>
        /// <param name="entities"></param>
        public virtual void DeleteMany(IEnumerable<TEntity> entities)
        {
            entities.ToList().ForEach(e => Delete(e));
        }
        #endregion

        internal TEntity AttachEntry(TEntity entity, EntityState stateForEntry = EntityState.Modified)
        {
            entity.ModifiedOn = DateTime.Now;

            var entry = _dbContext.Entry(entity);

            if (entry.State == EntityState.Detached)
            {
                _dbSet.Attach(entity);
                entry = _dbContext.Entry(entity);
            }
            entry.State = stateForEntry;

            return entity;
        }
    }
}
