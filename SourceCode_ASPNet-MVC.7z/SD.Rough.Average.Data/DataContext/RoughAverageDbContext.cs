﻿using System.Data.Entity;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Mapping;
using static SD.Rough.Average.Core.AppGlobalSettings;

namespace SD.Rough.Average.Data.DataContext
{
    public class RoughAverageDbContext : BaseDbContext
    {
        public RoughAverageDbContext() : base($"Name={RoughAverageDBConnStringKey}") { }

        public DbSet<AppUser> AppUsers { get; set; }
        public DbSet<Color> Colors { get; set; }

        public DbSet<Clarity> Clarities { get; set; }
        public DbSet<ClarityTemporal> ClarityTemporals { get; set; }

        public DbSet<Designation> Designations { get; set; }
        public DbSet<DiameterSieveSize> DiameterSieveSizes { get; set; }
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Lot> Lots { get; set; }
        public DbSet<LotFile> LotFiles { get; set; }
        public DbSet<LotAssign> LotAssigns { get; set; }
        public DbSet<Loss> Losses { get; set; }
        public DbSet<LossType> LossTypes { get; set; }
        public DbSet<Machine> Machines { get; set; }
        public DbSet<MachineType> MachineTypes { get; set; }
        public DbSet<MeasureType> MeasureTypes { get; set; }
        public DbSet<Menu> Menus { get; set; }
        public DbSet<PlanningLevel> PlanningLevels { get; set; }
        public DbSet<PolishedSieveSize> PolishedSieveSizes { get; set; }
        public DbSet<PolishedStone> PolishedStones { get; set; }
        public DbSet<Rate> Rates { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<RoleMenu> RoleMenus { get; set; }
        public DbSet<RoughCategory> RoughCategories { get; set; }
        public DbSet<Rejection> Rejections { get; set; }
        public DbSet<RoughCategoryRoughType> RoughCategoryRoughType { get; set; }
        public DbSet<RoughColorShade> RoughColorShades { get; set; }
        public DbSet<ColorRateVersion> ColorRateVersions { get; set; }
        public DbSet<NonMakeableStone> NonMakeableStones { get; set; }
        public DbSet<ExtraMakeableStone> ExtraMakeableStones { get; set; }

        public DbSet<RoughSize> RoughSizes { get; set; }
        public DbSet<RoughType> RoughTypes { get; set; }
        public DbSet<RoughSizeSieveSize> RoughSizeProportionSieveSizes { get; set; }
        public DbSet<RoughSizePolishedSieveSize> RoughSizePolishedSieveSizes { get; set; }
        public DbSet<SarinActivity> SarinActivities { get; set; }
        public DbSet<Shape> Shapes { get; set; }
        public DbSet<SieveSize> SieveSizes { get; set; }
        public DbSet<SieveSizeFileImport> SieveSizeFileImports { get; set; }
        public DbSet<Stone> Stones { get; set; }
        public DbSet<SubRough> SubRoughs { get; set; }

        public DbSet<TopsParameter> TopsParameters { get; set; }
        public DbSet<TopsParameterTemporal> TopsParameterTemporals { get; set; }

        public DbSet<Tops> Topses { get; set; }

        public DbSet<LotStoneTopsParameter> LotStoneTopsParameters { get; set; }
        public DbSet<StoneTopsParameter> StoneTopsParameters { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new AppUserMap());
            modelBuilder.Configurations.Add(new ColorMap());

            modelBuilder.Configurations.Add(new ClarityMap());
            modelBuilder.Configurations.Add(new ClarityTemporalMap());

            modelBuilder.Configurations.Add(new DesignationMap());
            modelBuilder.Configurations.Add(new DiameterSieveSizeMap());
            modelBuilder.Configurations.Add(new EmployeeMap());
            modelBuilder.Configurations.Add(new LotMap());
            modelBuilder.Configurations.Add(new LotFileMap());
            modelBuilder.Configurations.Add(new LotAssignMap());
            modelBuilder.Configurations.Add(new LossMap());
            modelBuilder.Configurations.Add(new LossTypeMap());
            modelBuilder.Configurations.Add(new MachineMap());
            modelBuilder.Configurations.Add(new MachineTypeMap());
            modelBuilder.Configurations.Add(new MeasureTypeMap());
            modelBuilder.Configurations.Add(new MenuMap());
            modelBuilder.Configurations.Add(new PlanningLevelMap());
            modelBuilder.Configurations.Add(new PolishedSieveSizeMap());
            modelBuilder.Configurations.Add(new PolishedStoneMap());
            modelBuilder.Configurations.Add(new RejectionMap());
            modelBuilder.Configurations.Add(new RateMap());
            modelBuilder.Configurations.Add(new RoleMap());
            modelBuilder.Configurations.Add(new RoleMenuMap());
            modelBuilder.Configurations.Add(new RoughCategoryMap());
            modelBuilder.Configurations.Add(new RoughCategoryRoughTypeMap());
            modelBuilder.Configurations.Add(new RoughColorShadeMap());
            modelBuilder.Configurations.Add(new ColorRateVersionMap());
            modelBuilder.Configurations.Add(new RoughSizeMap());
            modelBuilder.Configurations.Add(new RoughTypeMap());
            modelBuilder.Configurations.Add(new RoughSizeSieveSizeMap());
            modelBuilder.Configurations.Add(new RoughSizePolishedSieveSizeMap());
            modelBuilder.Configurations.Add(new SarinActivityMap());
            modelBuilder.Configurations.Add(new ShapeMap());
            modelBuilder.Configurations.Add(new SieveSizeMap());
            modelBuilder.Configurations.Add(new SieveSizeFileImportMap());
            modelBuilder.Configurations.Add(new StoneMap());
            modelBuilder.Configurations.Add(new SubRoughMap());

            modelBuilder.Configurations.Add(new TopsParameterMap());
            modelBuilder.Configurations.Add(new TopsParameterTemporalMap());

            modelBuilder.Configurations.Add(new TopsMap());
            modelBuilder.Configurations.Add(new NonMakeableStoneMap());
            modelBuilder.Configurations.Add(new ExtraMakeableStoneMap());

            modelBuilder.Configurations.Add(new LotStoneTopsParameterMap());
            modelBuilder.Configurations.Add(new StoneTopsParameterMap());
        }
    }
}
