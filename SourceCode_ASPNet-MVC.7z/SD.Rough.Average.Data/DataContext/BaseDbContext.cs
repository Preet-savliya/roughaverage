﻿using System.Data.Entity;

namespace SD.Rough.Average.Data.DataContext
{
    public abstract class BaseDbContext : DbContext
    {
        public BaseDbContext(string nameOfConnectionString) : base(nameOfConnectionString) { }

        public override int SaveChanges() => base.SaveChanges();

        //public override int SaveChanges()
        //{
        //    try
        //    {
        //        return base.SaveChanges();

        //    }
        //    catch (DbEntityValidationException e)
        //    {
        //        foreach (var eve in e.EntityValidationErrors)
        //        {
        //            foreach (var ve in eve.ValidationErrors)
        //            {
        //                string v = ve.ErrorMessage;
        //            }
        //        }
        //        throw;
        //    }
        //}

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }
    }
}
