﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.Infrastructure.Annotations;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace SD.Rough.Average.Data.Extensions
{
    public static class EntityTypeConfiguration
    {
        /// <summary>
        /// Method to set Unique Key Constraint and Index
        /// </summary>
        /// <param name="property"></param>
        /// <param name="indexName"></param>
        /// <param name="columnOrder"></param>
        /// <returns></returns>
        public static PrimitivePropertyConfiguration HasUniqueIndexAnnotation(this PrimitivePropertyConfiguration property, string indexName, int columnOrder)
        {
            var indexAnnotation = new IndexAnnotation(new IndexAttribute(indexName, columnOrder) { IsUnique = true });
            return property.HasColumnAnnotation(IndexAnnotation.AnnotationName, indexAnnotation);
        }
    }
}
