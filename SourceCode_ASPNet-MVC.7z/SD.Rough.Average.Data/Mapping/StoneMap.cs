﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class StoneMap : BaseEntityMap<Stone>
    {
        public StoneMap()
        {
            // Ignored Properties
            Ignore(p => p.IsExist);
            Ignore(p => p.IsInsertUpdateSuccess);
            Ignore(p => p.IsDelete);
            Ignore(p => p.IsValid);
            Ignore(p => p.Comment);
            Ignore(p => p.StoneNumberNumeric);
            Ignore(p => p.FileName);

            Property(p => p.StoneDate)
                .HasColumnType("date")
                .IsRequired(); //Not Null

            Property(p => p.StoneTime)
                .IsRequired();

            Property(p => p.StoneNumber)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Stone_StoneNumber_LotId_MachineId", 0);

            Property(p => p.Weight)
                .HasColumnType("numeric") //DataType
                .HasPrecision(5, 3) //Size
                .IsRequired();

            Property(p => p.IsM2Stone)
               .IsRequired();

            Property(p => p.LotId)
                .HasUniqueIndexAnnotation("UQ_Stone_StoneNumber_LotId_MachineId", 1);

            Property(p => p.MachineId)
                .HasUniqueIndexAnnotation("UQ_Stone_StoneNumber_LotId_MachineId", 2);

            Property(p => p.MeasureTypeId)
                .IsRequired();

            Property(p => p.PlanningLevelId)
                .IsRequired();

            //Table & Column Mapping
            ToTable("StoneDetail");

            Property(p => p.LotId).HasColumnName("LotId").HasColumnOrder(2);
            Property(p => p.LotFileId).HasColumnName("LotFileId").HasColumnOrder(3);
            Property(p => p.StoneDate).HasColumnName("StoneDate").HasColumnOrder(4);
            Property(p => p.StoneTime).HasColumnName("StoneTime").HasColumnOrder(5);
            Property(p => p.StoneNumber).HasColumnName("StoneNumber").HasColumnOrder(6);
            Property(p => p.Weight).HasColumnName("Weight").HasColumnOrder(7);
            Property(p => p.OpertorId).HasColumnName("OperatorId").HasColumnOrder(8);
            Property(p => p.MachineId).HasColumnName("MachineId").HasColumnOrder(9);
            Property(p => p.MeasureTypeId).HasColumnName("MeasureTypeId").HasColumnOrder(10);
            Property(p => p.PlanningLevelId).HasColumnName("PlanningLevelId").HasColumnOrder(11);
            Property(p => p.IsM2Stone).HasColumnName("IsM2Stone").HasColumnOrder(12);

            //Relationships
            HasRequired(st => st.Lot) // 1 Stone is associated with 1 Lot only
                .WithMany(l => l.Stones) //Lot can have Multiple Stones
                .HasForeignKey(fk => fk.LotId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasOptional(st => st.LotFile) // 1 Stone is associated with 1 Lot file only
                .WithMany(l => l.Stones) //Lot file can have Multiple Stones
                .HasForeignKey(fk => fk.LotFileId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasRequired(st => st.Operator) // 1 Stone is associated with 1 Operator only
                .WithMany() //1 operator have Multiple Stones
                .HasForeignKey(fk => fk.OpertorId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasRequired(st => st.Machine) // 1 Stone is associated with 1 Machine only
                .WithMany() //1 Machine have Multiple Stones
                .HasForeignKey(fk => fk.MachineId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasRequired(st => st.MeasureType) // 1 Stone is associated with 1 MeasureType only
                .WithMany() //1 Measuretype is assigned to Multiple Stones
                .HasForeignKey(fk => fk.MeasureTypeId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasRequired(st => st.PlanningLevel) // 1 Stone is associated with 1 PlanningLevel only
                .WithMany() //1 PlanningLevel is assigned to Multiple Stones
                .HasForeignKey(fk => fk.PlanningLevelId) //Foreign Key
                .WillCascadeOnDelete(false);
        }
    }
}
