﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class DiameterSieveSizeMap : BaseEntityMap<DiameterSieveSize>
    {
        #region Ctor
        public DiameterSieveSizeMap()
        {
            Property(p => p.Diameter)
                .HasColumnType("numeric")
                .HasPrecision(5, 2)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_DiameterSieveSize_Diameter_EffectiveFrom", 0);

            Property(p => p.DiameterUpTo)
                .HasColumnType("numeric")
                .HasPrecision(5, 2);

            Property(p => p.SieveSizeId)
                .IsRequired();

            Property(p => p.EffectiveFrom)
                .HasColumnType("date")
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_DiameterSieveSize_Diameter_EffectiveFrom", 1);

            Property(p => p.SieveSizeFileImportId)
                .IsOptional();

            //Table & Column Mapping
            ToTable("DiameterSieveSizeMap");

            Property(p => p.Diameter).HasColumnName("Diameter").HasColumnOrder(2);
            Property(p => p.DiameterUpTo).HasColumnName("DiameterUpTo").HasColumnOrder(3);
            Property(p => p.SieveSizeId).HasColumnName("SieveSizeId").HasColumnOrder(4);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(5);
            Property(p => p.SieveSizeFileImportId).HasColumnName("SieveSizeFileImportId").HasColumnOrder(6);

            //Relationships
            HasRequired(r => r.SieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.SieveSizeId);

            HasOptional(r => r.SieveSizeFileImport)
                .WithMany(sf => sf.DiameterSieveSizes)
                .HasForeignKey(fk => fk.SieveSizeFileImportId)
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
