﻿using SD.Rough.Average.Data.Extensions;
using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class RoughCategoryRoughTypeMap : BaseEntityMap<RoughCategoryRoughType>
    {
        #region Ctor
        public RoughCategoryRoughTypeMap()
        {
            //Properties
            Property(p => p.RoughTypeId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughCategoryRoughType_RoughTypeId_RoughCategoryId", 0);

            Property(p => p.RoughCategoryId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughCategoryRoughType_RoughTypeId_RoughCategoryId", 1);

            Property(p => p.IsBehaveSeparately)
                .IsOptional();

            Property(p => p.DisplayOrder)
                .IsRequired();


            //Table & Column Mapping
            ToTable("RoughCategoryRoughTypeMap");

            Property(p => p.RoughTypeId).HasColumnName("RoughTypeId").HasColumnOrder(2);
            Property(p => p.RoughCategoryId).HasColumnName("RoughCategoryId").HasColumnOrder(3);
            Property(p => p.IsBehaveSeparately).HasColumnName("IsBehaveSeparately").HasColumnOrder(4);
            Property(p => p.DisplayOrder).HasColumnName("DisplayOrder").HasColumnOrder(5);

            //RelationShip
            HasRequired(r => r.RoughType)
                .WithMany(rt => rt.RoughCategoryRoughTypes)
                .HasForeignKey(fk => fk.RoughTypeId)
                .WillCascadeOnDelete(false);

            HasRequired(r => r.RoughCategory)
                .WithMany()
                .HasForeignKey(fk => fk.RoughCategoryId)
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
