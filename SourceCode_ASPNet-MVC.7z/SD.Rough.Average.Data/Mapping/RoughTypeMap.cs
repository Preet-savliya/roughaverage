﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class RoughTypeMap : BaseEntityMap<RoughType>
    {
        #region Ctor
        public RoughTypeMap()
        {
            //Properties
            Property(p => p.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughType_Name", 0);

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();  // Accepts Null

            //Table & Column Mapping
            ToTable("RoughTypeMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(3);
        }
        #endregion
    }
}
