﻿using SD.Rough.Average.Data.Extensions;
using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class LotAssignMap : BaseEntityMap<LotAssign>
    {
        #region Ctor
        public LotAssignMap()
        {
            Property(p => p.LotId)
                .HasUniqueIndexAnnotation("UQ_LotAssign_LotId_AssignedTo", 0)
                .IsRequired();

            Property(p => p.AssignedTo)
                .HasUniqueIndexAnnotation("UQ_LotAssign_LotId_AssignedTo", 1)
                .IsRequired();

            Property(p => p.AssignedOn)
                .IsOptional()
                .HasColumnType("datetime2");

            // Table
            ToTable("LotAssignDetail");

            Property(p => p.LotId).HasColumnName("LotId").HasColumnOrder(2);
            Property(p => p.AssignedTo).HasColumnName("AssignedTo").HasColumnOrder(3);
            Property(p => p.AssignedOn).HasColumnName("AssignedOn").HasColumnOrder(4);

            HasRequired(la => la.Lot)
                .WithMany(l => l.LotAssigns)
                .HasForeignKey(fk => fk.LotId)
                .WillCascadeOnDelete(false);

            HasRequired(l => l.Assigning) // 1 lot is associated with 1 operator
                .WithMany()
                .HasForeignKey(fk => fk.AssignedTo)
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
