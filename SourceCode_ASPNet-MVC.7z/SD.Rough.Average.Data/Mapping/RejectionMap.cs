﻿using SD.Rough.Average.Data.Extensions;
using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class RejectionMap : BaseEntityMap<Rejection>
    {
        public RejectionMap()
        {
            Property(x => x.SubRoughId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Rejection_SubRoughId_SarinActivityId", 0);

            Property(x => x.SarinActivityId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Rejection_SubRoughId_SarinActivityId", 1);

            Property(x => x.PieceCount)
                .IsRequired();

            Property(p => p.Weight)
                .IsRequired()
                .HasColumnType("numeric")
                .HasPrecision(6, 3);

            ToTable("RejectionDetail");

            Property(p => p.SubRoughId).HasColumnName("SubRoughId").HasColumnOrder(2);
            Property(p => p.SarinActivityId).HasColumnName("SarinActivityId").HasColumnOrder(3);
            Property(p => p.PieceCount).HasColumnName("PieceCount").HasColumnOrder(4);
            Property(p => p.Weight).HasColumnName("Weight").HasColumnOrder(5);

            HasRequired(r => r.SubRough) 
                .WithMany(s => s.Rejections)
                .HasForeignKey(fk => fk.SubRoughId) 
                .WillCascadeOnDelete(false);

            HasRequired(r => r.SarinActivity)
                .WithMany()
                .HasForeignKey(fk => fk.SarinActivityId)
                .WillCascadeOnDelete(false);

        }
    }
}
