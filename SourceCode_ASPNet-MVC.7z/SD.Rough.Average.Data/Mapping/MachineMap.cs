﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class MachineMap : BaseEntityMap<Machine>
    {
        #region Ctor
        public MachineMap()
        {
            //Properties
            Property(p => p.Number)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Machine_Number", 0);

            Property(p => p.MachineTypeId)
                .IsRequired();

            //Table and Column Mapping
            ToTable("MachineMaster");

            Property(p => p.Number).HasColumnName("Number").HasColumnOrder(2);
            Property(p => p.MachineTypeId).HasColumnName("MachineTypeId").HasColumnOrder(3);

            //Relationships
            HasRequired(m => m.MachineType)
                .WithMany()
                .HasForeignKey(fk => fk.MachineTypeId)
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
