﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class SubRoughMap : BaseEntityMap<SubRough>
    {
        public SubRoughMap()
        {
            Ignore(p => p.GroupName);
            Ignore(p => p.Name);
            Ignore(p => p.SarinActivity);
            Ignore(p => p.Comment);
            Ignore(p => p.IsPrintSubRoughDetail);
            Ignore(p => p.PriceList);
            Ignore(p => p.SieveSizeFileName);
            
            Property(p => p.RoughTypeId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_SubRough_RoughTypeId_RoughColorShadeId_Number_RoughSizeId_PieceCount_Weight", 0);

            Property(p => p.RoughColorShadeId)
                .IsOptional()
                .HasUniqueIndexAnnotation("UQ_SubRough_RoughTypeId_RoughColorShadeId_Number_RoughSizeId_PieceCount_Weight", 1);

            Property(p => p.RoughSizeId)
               .IsOptional()
               .HasUniqueIndexAnnotation("UQ_SubRough_RoughTypeId_RoughColorShadeId_Number_RoughSizeId_PieceCount_Weight", 2);

            Property(p => p.Number)
                .IsOptional()
                .HasUniqueIndexAnnotation("UQ_SubRough_RoughTypeId_RoughColorShadeId_Number_RoughSizeId_PieceCount_Weight", 3);

            Property(p => p.PieceCount)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_SubRough_RoughTypeId_RoughColorShadeId_Number_RoughSizeId_PieceCount_Weight", 4);

            Property(p => p.Weight)
                .IsRequired()
                .HasColumnType("numeric")
                .HasPrecision(6, 3)
                .HasUniqueIndexAnnotation("UQ_SubRough_RoughTypeId_RoughColorShadeId_Number_RoughSizeId_PieceCount_Weight", 5);

            Property(p => p.MakeablePieceCount)
                .IsOptional();

            Property(p => p.MakeableWeight)
                .IsOptional()
                .HasColumnType("numeric")
                .HasPrecision(6, 3);

            Property(p => p.MakeableTopsPieces)
                .IsOptional();

            Property(p => p.MakeableTopsWeight)
                .IsOptional()
                .HasColumnType("numeric")
                .HasPrecision(6, 3);

            Property(p => p.EmployeeId)
                .IsRequired();

            Property(p => p.AssignedOn)
                .HasColumnType("datetime2")
                .IsRequired();

            Property(p => p.MakeableEntryDate)
               .HasColumnType("datetime2");

            Property(p => p.MakeableTopsEntryDate)
                .HasColumnType("datetime2");

            Property(p => p.RoughMinPolishedDiameter)
                .IsRequired()
                .HasColumnType("numeric")
                .HasPrecision(6, 3);

            Property(p => p.RoughTopsPolishedDiameter)
                .IsRequired()
                .HasColumnType("numeric")
                .HasPrecision(6, 3);

            Property(p => p.MakeableMinPolishedDiameter)
                .IsOptional()
                .HasColumnType("numeric")
                .HasPrecision(6, 3);

            Property(p => p.MakeableTopsPolishedDiameter)
                .IsOptional()
                .HasColumnType("numeric")
                .HasPrecision(6, 3);

            Property(p => p.SieveSizeFileImportId)
                .IsOptional();

            Property(p => p.IsLotBySize)
                .IsRequired();

            Property(p => p.Description)
                .IsOptional()
                .HasMaxLength(150)
                .IsUnicode(false);

            ToTable("SubRoughDetail");

            // Property(p => p.RoughId).HasColumnName("RoughId").HasColumnOrder(2);
            Property(p => p.RoughTypeId).HasColumnName("RoughTypeId").HasColumnOrder(2);
            Property(p => p.RoughColorShadeId).HasColumnName("RoughColorShadeId").HasColumnOrder(3);
            Property(p => p.Number).HasColumnName("Number").HasColumnOrder(4);
            Property(p => p.RoughSizeId).HasColumnName("RoughSizeId").HasColumnOrder(5);
            Property(p => p.Weight).HasColumnName("Weight").HasColumnOrder(6);
            Property(p => p.PieceCount).HasColumnName("PieceCount").HasColumnOrder(7);
            Property(p => p.AssignedOn).HasColumnName("AssignedOn").HasColumnOrder(8);
            Property(p => p.EmployeeId).HasColumnName("EmployeeId").HasColumnOrder(9);
            Property(p => p.RoughMinPolishedDiameter).HasColumnName("RoughMinPolishedDiameter").HasColumnOrder(10);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(11);
            Property(p => p.MakeableWeight).HasColumnName("MakeableWeight").HasColumnOrder(13);
            Property(p => p.MakeablePieceCount).HasColumnName("MakeablePieceCount").HasColumnOrder(14);
            Property(p => p.RoughTopsPolishedDiameter).HasColumnName("RoughTopsPolishedDiameter").HasColumnOrder(15);
            Property(p => p.IsLotBySize).HasColumnName("IsLotBySize").HasColumnOrder(16);
            Property(p => p.MakeableMinPolishedDiameter).HasColumnName("MakeableMinPolishedDiameter").HasColumnOrder(17);
            Property(p => p.MakeableTopsPolishedDiameter).HasColumnName("MakeableTopsPolishedDiameter").HasColumnOrder(18);
            Property(p => p.MakeableEntryDate).HasColumnName("MakeableEntryDate").HasColumnOrder(19);
            Property(p => p.SieveSizeFileImportId).HasColumnName("SieveSizeFileImportId").HasColumnOrder(20);            

            //Relationships
            //HasRequired(sr => sr.Rough) // 1 SubRough is associated with 1 Rough only
            //    .WithMany(r => r.SubRoughs) //Rough can have Multiple SubRough
            //    .HasForeignKey(fk => fk.RoughId) //Foreign Key
            //    .WillCascadeOnDelete(false);

            HasRequired(sr => sr.RoughType) // 1 rough is associated with 1 one Roughtype
                .WithMany() // 1 roughType has many roughs
                .HasForeignKey(fk => fk.RoughTypeId) //foreignKey
                .WillCascadeOnDelete(false);

            HasOptional(sr => sr.RoughColorShade)
                .WithMany()
                .HasForeignKey(fk => fk.RoughColorShadeId)
                .WillCascadeOnDelete(false);

            HasRequired(sr => sr.Employee) // 1 subrough is associated with 1 one Employee
               .WithMany() // 1 employee has many subroughs
               .HasForeignKey(fk => fk.EmployeeId) //foreignKey
               .WillCascadeOnDelete(false);

            HasOptional(sr => sr.RoughSize) // 1 subrough is associated with 1 RoughCutSize
               .WithMany() // 1 RoughtCutSize has many subroughs
               .HasForeignKey(fk => fk.RoughSizeId) //foreignKey
               .WillCascadeOnDelete(false);

            HasOptional(sr => sr.SieveSizeFileImport) 
               .WithMany(ss => ss.SubRoughs) 
               .HasForeignKey(fk => fk.SieveSizeFileImportId)
               .WillCascadeOnDelete(false);

        }
    }
}
