﻿using SD.Rough.Average.Data.Extensions;
using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class LossMap : BaseEntityMap<Loss>
    {
        public LossMap()
        {
            Property(x => x.SubRoughId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Loss_SubRoughId_SarinActivityId_LossTypeId", 0);

            Property(x => x.SarinActivityId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Loss_SubRoughId_SarinActivityId_LossTypeId", 1);

            Property(x => x.LossTypeId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Loss_SubRoughId_SarinActivityId_LossTypeId", 2);

            Property(x => x.PieceCount)
                .IsOptional();

            Property(p => p.Weight)
                .IsRequired()
                .HasColumnType("numeric")
                .HasPrecision(6, 3);

            Property(p => p.Description)
                .IsOptional()
                .HasMaxLength(100)
                .IsUnicode(false);

            ToTable("LossDetail");

            Property(p => p.SubRoughId).HasColumnName("SubRoughId").HasColumnOrder(2);
            Property(p => p.SarinActivityId).HasColumnName("SarinActivityId").HasColumnOrder(3);
            Property(p => p.LossTypeId).HasColumnName("LossTypeId").HasColumnOrder(4);
            Property(p => p.PieceCount).HasColumnName("PieceCount").HasColumnOrder(5);
            Property(p => p.Weight).HasColumnName("Weight").HasColumnOrder(6);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(7);

            HasRequired(r => r.SubRough)
                .WithMany(s => s.Losses)
                .HasForeignKey(fk => fk.SubRoughId)
                .WillCascadeOnDelete(false);

            HasRequired(r => r.SarinActivity)
                .WithMany()
                .HasForeignKey(fk => fk.SarinActivityId)
                .WillCascadeOnDelete(false);

            HasRequired(r => r.LossType)
                .WithMany()
                .HasForeignKey(fk => fk.LossTypeId)
                .WillCascadeOnDelete(false);
        }
    }
}
