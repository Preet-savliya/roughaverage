﻿using SD.Rough.Average.Data.Extensions;
using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class SarinActivityMap : BaseEntityMap<SarinActivity>
    {
        #region Ctor
        public SarinActivityMap()
        {
            //Properties
            Property(p => p.Name)
                .HasMaxLength(30)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_SarinActivity_Name", 0);

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();

            //Table & Column Mapping
            ToTable("SarinActivityMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(3);
        }
        #endregion
    }
}
