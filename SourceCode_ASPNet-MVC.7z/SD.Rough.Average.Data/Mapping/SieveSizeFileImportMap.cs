﻿using SD.Rough.Average.Data.Extensions;
using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class SieveSizeFileImportMap : BaseEntityMap<SieveSizeFileImport>
    {
        #region Ctor
        public SieveSizeFileImportMap()
        {
            Property(p => p.Name)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            Property(p => p.EffectiveFrom)
                .HasColumnType("date")
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_SieveSizeFileImport_EffectiveFrom", 0); ;

            //Table & Column Mapping
            ToTable("SieveSizeFileImportDetail");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(3);
        }
        #endregion
    }
}
