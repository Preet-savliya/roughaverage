﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class RoleMap : BaseEntityMap<Role>
    {
        #region Ctor
        public RoleMap()
        {
            //Properties
            Property(p => p.Name)
                .HasMaxLength(15)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Role_Name", 0);

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();

            //Table & Column Mapping
            ToTable("RoleMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(3);
        }
        #endregion
    }
}
