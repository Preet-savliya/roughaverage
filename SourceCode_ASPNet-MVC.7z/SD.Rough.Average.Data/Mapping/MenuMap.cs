﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class MenuMap : BaseEntityMap<Menu>
    {
        public MenuMap()
        {
            //Ignore Properties
            Ignore(p => p.IsSelected);
            //Ignore(p => p.SelectedTopMenu);
            //Ignore(p => p.SelectedChildMenu);

            Property(p => p.Name)
                .HasMaxLength(40)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Menu_Name_ParentId", 0);

            Property(p => p.Controller)
                .HasMaxLength(50)
                .IsUnicode(false)
                .IsOptional();

            Property(p => p.Action)
                .HasMaxLength(50)
                .IsUnicode(false)
                .IsOptional();

            Property(p => p.ParentId)
                .IsOptional()
                .HasUniqueIndexAnnotation("UQ_Menu_Name_ParentId", 1);

            Property(p => p.DisplayOrder)
                .IsRequired();

            ToTable("MenuMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Controller).HasColumnName("Controller").HasColumnOrder(3);
            Property(p => p.Action).HasColumnName("Action").HasColumnOrder(4);
            Property(p => p.ParentId).HasColumnName("ParentId").HasColumnOrder(5);
            Property(p => p.DisplayOrder).HasColumnName("DisplayOrder").HasColumnOrder(6);

            HasOptional(r => r.ParentMenu)
                .WithMany(r => r.Menus)
                .HasForeignKey(r => r.ParentId)
                .WillCascadeOnDelete(false);
        }
    }
}
