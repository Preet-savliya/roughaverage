﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class MachineTypeMap : BaseEntityMap<MachineType>
    {
        #region Ctor
        public MachineTypeMap()
        {
            //Properties
            Property(p => p.Name)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_MachineType_Name", 0);

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();

            //Table & Column Mapping
            ToTable("MachineTypeMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(3);
        }
        #endregion
    }
}
