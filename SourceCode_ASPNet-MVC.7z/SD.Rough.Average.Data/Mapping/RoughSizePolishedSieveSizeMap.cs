﻿namespace SD.Rough.Average.Data.Mapping
{
    using Models;
    using SD.Rough.Average.Data.Extensions;

    public class RoughSizePolishedSieveSizeMap : BaseEntityMap<RoughSizePolishedSieveSize>
    {
        #region Ctor
        public RoughSizePolishedSieveSizeMap()
        {
            //Properties
            Property(p => p.RoughSizeId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughSizePolishedSieveSize_RoughSizeIdPolishedSieveSizeIdEffectiveFrom", 0);

            Property(p => p.PolishedSieveSizeId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughSizePolishedSieveSize_RoughSizeIdPolishedSieveSizeIdEffectiveFrom", 1);

            Property(p => p.EffectiveFrom)
                .HasColumnType("date")
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughSizePolishedSieveSize_RoughSizeIdPolishedSieveSizeIdEffectiveFrom", 2);

            //Table & Column Mapping
            ToTable("RoughSizePolishedSieveSizeMap");

            Property(p => p.RoughSizeId).HasColumnName("RoughSizeId").HasColumnOrder(2);
            Property(p => p.PolishedSieveSizeId).HasColumnName("PolishedSieveSizeId").HasColumnOrder(3);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(4);

            //Relationships
            HasRequired(r => r.RoughSize)
                .WithMany(sr => sr.RoughSizePolishedSieveSizes)
                .HasForeignKey(fk => fk.RoughSizeId);

            HasRequired(r => r.PolishedSieveSize)
                .WithMany(sr => sr.RoughSizePolishedSieveSizes)
                .HasForeignKey(fk => fk.PolishedSieveSizeId)
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
