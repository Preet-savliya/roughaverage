﻿namespace SD.Rough.Average.Data.Mapping
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.Extensions;

    public class ColorMap : BaseEntityMap<Color>
    {
        #region Ctor
        public ColorMap()
        {
            // Properties

            Property(p=>p.Name)
                .HasMaxLength(15)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Color_Name", 0);

            Property(p => p.Description)
               .HasMaxLength(100)
               .IsUnicode(false)
               .IsOptional();

            // Table & Column Mappint
            ToTable("ColorMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(3);
        }
        #endregion
    }
}
