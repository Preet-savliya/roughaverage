﻿using SD.Rough.Average.Models;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace SD.Rough.Average.Data.Mapping
{
    public class BaseEntityMap<TEntity> : EntityTypeConfiguration<TEntity> where TEntity : BaseEntity
    {
        #region Ctor
        public BaseEntityMap()
        {
            //Primary Key
            HasKey(key => key.Id);

            //Properties
            Property(p => p.Id)
              .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity); //Identity-AutoIncrement

            Property(p => p.IsActive)
                .IsRequired();

            Property(p => p.CreatedBy)
                .IsRequired();

            Property(p => p.CreatedOn)
                .IsRequired()
                .HasColumnType("datetime2");

            Property(p => p.ModifiedBy)
                .IsOptional();

            Property(p => p.ModifiedOn)
                .IsOptional()
                .HasColumnType("datetime2");

            //Column Mapping
            Property(p => p.Id).HasColumnName("Id").HasColumnOrder(1);
            Property(p => p.IsActive).HasColumnName("IsActive");
            Property(p => p.CreatedBy).HasColumnName("CreatedBy");
            Property(p => p.CreatedOn).HasColumnName("CreatedOn");
            Property(p => p.ModifiedBy).HasColumnName("ModifiedBy");
            Property(p => p.ModifiedOn).HasColumnName("ModifiedOn");

            //Relationship
            HasRequired(r => r.CreatedByUser)
                .WithMany() //Uni Direction - 1-User => M-Entries - Relationship
                .HasForeignKey(fk => fk.CreatedBy) //Foreign Key
                .WillCascadeOnDelete(false);

            HasOptional(r => r.ModifiedByUser) //ModifiedBy field is nullable in all tables
                .WithMany() //Uni Direction - 1-User => M-Entries - Relationship
                .HasForeignKey(fk => fk.ModifiedBy) //Foreign Key
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
