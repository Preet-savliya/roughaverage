﻿namespace SD.Rough.Average.Data.Mapping
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.Extensions;

    public class RoughSizeMap : BaseEntityMap<RoughSize>
    {
        #region Ctor
        public RoughSizeMap()
        {
            // Properties
            Property(p => p.Name)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasUniqueIndexAnnotation("UQ_RoughSize_Name", 0)
                .IsRequired();

            Property(p => p.DisplayName)
                .HasMaxLength(10)
                .IsUnicode(false)
                .HasUniqueIndexAnnotation("UQ_RoughSize_DisplayName", 1)
                .IsRequired();

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();

            //Table & Column Mapping
            ToTable("RoughSizeMaster");

            Property(p => p.Name).HasColumnOrder(2);
            Property(p => p.DisplayName).HasColumnOrder(3);
            Property(p => p.DisplayOrder).HasColumnOrder(4);
            Property(p => p.Description).HasColumnOrder(5);
        }
        #endregion
    }
}
