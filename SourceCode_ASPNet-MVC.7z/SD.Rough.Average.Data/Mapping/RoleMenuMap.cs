﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class RoleMenuMap : BaseEntityMap<RoleMenu>
    {
        #region Ctor
        public RoleMenuMap()
        {
            //Properties
            Property(p => p.RoleId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoleMenu_RoleId_MenuId", 0);

            Property(p => p.MenuId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoleMenu_RoleId_MenuId", 1);

            //Table & Column Mapping
            ToTable("RoleMenuMap");

            Property(p => p.RoleId).HasColumnName("RoleId").HasColumnOrder(2);
            Property(p => p.MenuId).HasColumnName("MenuId").HasColumnOrder(3);

            //RelationShip FK
            HasRequired(r => r.Roles)
                .WithMany(r => r.RoleMenus)
                .HasForeignKey(r => r.RoleId)
                .WillCascadeOnDelete(false);

            HasRequired(r => r.Menus)
                .WithMany()
                .HasForeignKey(r => r.MenuId)
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
