﻿namespace SD.Rough.Average.Data.Mapping
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.Extensions;

    public class LossTypeMap : BaseEntityMap<LossType>
    {
        public LossTypeMap()
        {
            //Properties
            Property(p => p.Type)
                .HasMaxLength(40)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_LossType_Type", 0);

            Property(p => p.Code)
                .IsFixedLength()
                .HasMaxLength(4)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_LossType_Code", 0);

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();  // Accepts Null

            //Table & Column Mapping
            ToTable("LossTypeMaster");

            Property(p => p.Code).HasColumnName("Code").HasColumnOrder(2);
            Property(p => p.Type).HasColumnName("Type").HasColumnOrder(3);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(4);
        }
    }
}
