﻿namespace SD.Rough.Average.Data.Mapping
{
    using SD.Rough.Average.Models;

    public class RateMap : BaseEntityMap<Rate>
    {
        public RateMap()
        {
            // Properties
            Property(p => p.Diameter)
                .HasPrecision(5, 2);

            Property(p => p.UnitPrice)
                .HasPrecision(8, 3);

            // Table & Column Mappint
            ToTable("RateMaster");

            Property(p => p.ColorRateVersionId).HasColumnOrder(2);
            Property(p => p.ShapeId).HasColumnOrder(3);
            Property(p => p.ClarityId).HasColumnOrder(4);
            Property(p => p.Diameter).HasColumnOrder(5);
            Property(p => p.UnitPrice).HasColumnOrder(6);

            //Relationship
            HasRequired(p => p.ColorRateVersion)
                .WithMany()
                .HasForeignKey(p => p.ColorRateVersionId)
                .WillCascadeOnDelete(false);

            HasRequired(p => p.Shape)
                .WithMany()
                .HasForeignKey(p => p.ShapeId)
                .WillCascadeOnDelete(true);

            HasRequired(p => p.Clarity)
                .WithMany()
                .HasForeignKey(p => p.ClarityId)
                .WillCascadeOnDelete(false);
        }
    }
}
