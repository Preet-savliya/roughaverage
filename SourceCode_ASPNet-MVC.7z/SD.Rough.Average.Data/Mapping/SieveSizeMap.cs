﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class SieveSizeMap : BaseEntityMap<SieveSize>
    {
        public SieveSizeMap()
        {
            Property(p => p.Name)
                .HasMaxLength(8)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_SieveSize_Name", 0);

            //Property(p => p.Diameter)
            //    .HasPrecision(4, 2)
            //    .IsRequired();

            ToTable("SieveSizeMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            //Property(p => p.Diameter).HasColumnName("Diameter").HasColumnOrder(3);
        }
    }
}
