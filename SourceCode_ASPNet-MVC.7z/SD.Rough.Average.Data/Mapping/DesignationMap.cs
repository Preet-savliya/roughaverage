﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class DesignationMap : BaseEntityMap<Designation>
    {
        #region Ctor
        public DesignationMap()
        {
            //Properties
            Property(p => p.Name)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Designation_Name", 0);

            ToTable("DesignationMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
        }
        #endregion
    }
}
