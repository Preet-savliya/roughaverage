﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class MeasureTypeMap : BaseEntityMap<MeasureType>
    {
        #region Ctor
        public MeasureTypeMap()
        {
            //Properties
            Property(p => p.Code)
                .HasMaxLength(1)
                .IsFixedLength()
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_MeasureType_Code", 0);

            Property(p => p.Name)
                .HasMaxLength(30)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_MeasureType_Name", 0);

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();  // Accepts Null

            //Table & Column Mapping
            ToTable("MeasureTypeMaster");

            Property(p => p.Code).HasColumnName("Code").HasColumnOrder(2);
            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(3);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(4);
        }
        #endregion
    }
}
