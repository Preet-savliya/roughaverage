﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class ClarityMap : BaseEntityMap<Clarity>
    {
        public ClarityMap()
        {
            Property(p => p.Name)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Clarity_Name", 0);

            Property(p => p.GroupName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsRequired();

            Property(p => p.EffectiveFrom)
                .HasColumnType("date")
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Clarity_Name_EffectiveFrom", 1);

            Property(p => p.DisplayOrder)
                .IsRequired();

            ToTable("ClarityMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.GroupName).HasColumnName("GroupName").HasColumnOrder(3);
            Property(p => p.DisplayOrder).HasColumnName("DisplayOrder").HasColumnOrder(4);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(5);
        }
    }

    public class ClarityTemporalMap : BaseEntityMap<ClarityTemporal>
    {
        public ClarityTemporalMap()
        {
            Property(p => p.Name)
                .HasMaxLength(10)
                .IsUnicode(false)
                .IsRequired();

            Property(p => p.GroupName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsRequired();

            Property(p => p.EffectiveFrom)
                .HasColumnType("date")
                .IsRequired();

            Property(p => p.EffectiveTo)
                .HasColumnType("date")
                .IsRequired();                

            Property(p => p.DisplayOrder)
                .IsRequired();

            ToTable("ClarityMasterTemporal");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.GroupName).HasColumnName("GroupName").HasColumnOrder(3);
            Property(p => p.DisplayOrder).HasColumnName("DisplayOrder").HasColumnOrder(4);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(5);
            Property(p => p.EffectiveTo).HasColumnName("EffectiveTo").HasColumnOrder(6);
        }
    }
}
