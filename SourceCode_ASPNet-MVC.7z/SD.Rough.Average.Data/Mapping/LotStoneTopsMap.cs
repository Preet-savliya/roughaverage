﻿using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class LotStoneTopsParameterMap : BaseEntityMap<LotStoneTopsParameter>
    {
        public LotStoneTopsParameterMap()
        {
            Property(p => p.LotId)
                .IsRequired();

            ToTable("LotStoneTopsParameterDetail");

            Property(p => p.LotId).HasColumnName("LotId").HasColumnOrder(2);
            Property(p => p.StoneNumberFrom).HasColumnName("StoneNumberFrom").HasColumnOrder(3);
            Property(p => p.StoneNumberTo).HasColumnName("StoneNumberTo").HasColumnOrder(4);

            HasRequired(p => p.Lot)
                .WithMany(l => l.LotStoneTopsParameters)
                .HasForeignKey(p => p.LotId)
                .WillCascadeOnDelete(true);
        }
    }

    public class StoneTopsParameterMap : BaseEntityMap<StoneTopsParameter>
    {
        public StoneTopsParameterMap()
        {
            Property(p => p.TopsDiameter)
                .HasPrecision(5, 3);

            ToTable("StoneTopsParameterDetail");

            Property(p => p.LotStoneTopsParameterId).HasColumnName("LotStoneTopsParameterId").HasColumnOrder(2);
            Property(p => p.ClarityId).HasColumnName("ClarityId").HasColumnOrder(3);
            Property(p => p.TopsDiameter).HasColumnName("TopsDiameter").HasColumnOrder(4);

            HasRequired(p => p.LotStoneTopsParameter)
                .WithMany(p => p.StoneTopsParameters)
                .HasForeignKey(p => p.LotStoneTopsParameterId)
                .WillCascadeOnDelete(true);

            HasRequired(p => p.Clarity)
                .WithMany()
                .HasForeignKey(p => p.ClarityId)
                .WillCascadeOnDelete(false);
        }
    }
}
