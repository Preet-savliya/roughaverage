﻿using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class TopsMap : BaseEntityMap<Tops>
    {
        #region Ctor
        public TopsMap()
        {
            // Ignored Properties
            Ignore(p => p.IsValid);
            Ignore(p => p.Comment);

            Property(p => p.StoneId)
                .IsRequired();

            Property(p => p.PartWeight)
                .HasColumnType("numeric")
                .HasPrecision(5, 3)
                .IsRequired();

            //Table & Column Mapping
            ToTable("TopsDetail");

            Property(p => p.StoneId).HasColumnName("StoneId").HasColumnOrder(2);
            Property(p => p.PartWeight).HasColumnName("PartWeight").HasColumnOrder(3);

            //Relationships
            HasRequired(ts => ts.Stone) // 1 TopsStone is associated with 1 Stone only
                .WithMany(s => s.Topses) //Stone can have Multiple TopsStoneDetails
                .HasForeignKey(fk => fk.StoneId) //Foreign Key
                .WillCascadeOnDelete(true);
        }
        #endregion
    }
}
