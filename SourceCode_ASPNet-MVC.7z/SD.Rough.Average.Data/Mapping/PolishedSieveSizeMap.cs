﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class PolishedSieveSizeMap : BaseEntityMap<PolishedSieveSize>
    {
        #region Ctor
        public PolishedSieveSizeMap()
        {
            Ignore(p => p.MinDiameter);
            Ignore(p => p.MaxDiameter);

            Property(p => p.Name)
                .HasMaxLength(15)
                .IsUnicode(false)
                .IsRequired();

            Property(p => p.MinSieveSizeId)
                .IsOptional()
                .HasUniqueIndexAnnotation("UQ_PolishedSieveSize_MinSieveSizeId_MaxSieveSizeId_EffectiveFrom_IsActive_ParentId", 0);

            Property(p => p.MaxSieveSizeId)
                .IsOptional()
                .HasUniqueIndexAnnotation("UQ_PolishedSieveSize_MinSieveSizeId_MaxSieveSizeId_EffectiveFrom_IsActive_ParentId", 1);

            Property(p => p.EffectiveFrom)
                .HasColumnType("date")
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_PolishedSieveSize_MinSieveSizeId_MaxSieveSizeId_EffectiveFrom_IsActive_ParentId", 2);

            Property(p => p.IsActive)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_PolishedSieveSize_MinSieveSizeId_MaxSieveSizeId_EffectiveFrom_IsActive_ParentId", 3);

            Property(p => p.ParentId)
                .IsOptional()
                .HasUniqueIndexAnnotation("UQ_PolishedSieveSize_MinSieveSizeId_MaxSieveSizeId_EffectiveFrom_IsActive_ParentId", 4);

            Property(p => p.IsPointerApply)
                .IsRequired();

            ToTable("PolishedSieveSizeMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.MinSieveSizeId).HasColumnName("MinSieveSizeId").HasColumnOrder(3);
            Property(p => p.MaxSieveSizeId).HasColumnName("MaxSieveSizeId").HasColumnOrder(4);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(5);
            Property(p => p.ParentId).HasColumnName("ParentId").HasColumnOrder(6);
            Property(p => p.IsPointerApply).HasColumnName("IsPointerApply").HasColumnOrder(7);

            //Relationships
            HasOptional(ms => ms.MinSieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.MinSieveSizeId)
                .WillCascadeOnDelete(false);

            HasOptional(ms => ms.MaxSieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.MaxSieveSizeId)
                .WillCascadeOnDelete(false);

            HasOptional(r => r.ParentPolishedSieveSize)
                .WithMany(c => c.ChildPolishedSieveSizes)
                .HasForeignKey(fk => fk.ParentId)
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
