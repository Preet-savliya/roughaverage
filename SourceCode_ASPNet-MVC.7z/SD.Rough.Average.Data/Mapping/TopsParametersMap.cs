﻿using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class TopsParameterMap : BaseEntityMap<TopsParameter>
    {
        public TopsParameterMap()
        {
            Ignore(p => p.Name);

            Property(p => p.MinSieveSizeId)
                .IsOptional();
            Property(p => p.MaxSieveSizeId)
                .IsOptional();

            Property(p => p.EffectiveFrom)
                .HasColumnType("date")
                .IsRequired();

            ToTable("TopsParameterMaster");

            Property(p => p.MinSieveSizeId).HasColumnName("MinSieveSizeId").HasColumnOrder(2);
            Property(p => p.MaxSieveSizeId).HasColumnName("MaxSieveSizeId").HasColumnOrder(3);
            //Property(p => p.ClarityId).HasColumnName("ClarityId").HasColumnOrder(4);
            //Property(p => p.ColorId).HasColumnName("ColorId").HasColumnOrder(5);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(6);

            HasOptional(ms => ms.MinSieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.MinSieveSizeId)
                .WillCascadeOnDelete(false);

            HasOptional(ms => ms.MaxSieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.MaxSieveSizeId)
                .WillCascadeOnDelete(false);

            //HasRequired(ms => ms.Clarity)
            //    .WithMany()
            //    .HasForeignKey(fk => fk.ClarityId)
            //    .WillCascadeOnDelete(false);

            //HasRequired(ms => ms.Color)
            //    .WithMany()
            //    .HasForeignKey(fk => fk.ColorId)
            //    .WillCascadeOnDelete(false);
        }
    }

    public class TopsParameterTemporalMap : BaseEntityMap<TopsParameterTemporal>
    {
        public TopsParameterTemporalMap()
        {
            Property(p => p.MinSieveSizeId)
                .IsOptional();

            Property(p => p.MaxSieveSizeId)
                .IsOptional();

            Property(p => p.EffectiveFrom)
                .HasColumnType("date")
                .IsRequired();

            Property(p => p.EffectiveTo)
                .HasColumnType("date")
                .IsRequired();

            ToTable("TopsParameterMasterTemporal");

            Property(p => p.TopsParameterId).HasColumnName("TopsParameterId").HasColumnOrder(2);
            Property(p => p.MinSieveSizeId).HasColumnName("MinSieveSizeId").HasColumnOrder(3);
            Property(p => p.MaxSieveSizeId).HasColumnName("MaxSieveSizeId").HasColumnOrder(4);
            //Property(p => p.ClarityId).HasColumnName("ClarityId").HasColumnOrder(5);
            //Property(p => p.ColorId).HasColumnName("ColorId").HasColumnOrder(6);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(5);
            Property(p => p.EffectiveTo).HasColumnName("EffectiveTo").HasColumnOrder(6);
        }
    }
}

