﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class LotMap : BaseEntityMap<Lot>
    {
        public LotMap()
        {
            Ignore(p => p.IsValidTops);

            Property(p => p.SubRoughId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Lot_SubRoughId_SieveSizeId_SizeSign_PieceCount_Weight_SarinActivityId", 0);

            Property(p => p.SieveSizeId)
                .IsOptional()
                .HasUniqueIndexAnnotation("UQ_Lot_SubRoughId_SieveSizeId_SizeSign_PieceCount_Weight_SarinActivityId", 1);

            Property(p => p.SizeSign)
                .HasMaxLength(1)
                .IsFixedLength()
                .IsUnicode(false)
                .IsOptional()
                .HasUniqueIndexAnnotation("UQ_Lot_SubRoughId_SieveSizeId_SizeSign_PieceCount_Weight_SarinActivityId", 2);

            Property(p => p.PieceCount)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Lot_SubRoughId_SieveSizeId_SizeSign_PieceCount_Weight_SarinActivityId", 3);

            Property(p => p.Weight)
                .IsRequired()
                .HasColumnType("numeric")
                .HasPrecision(6, 3)
                .HasUniqueIndexAnnotation("UQ_Lot_SubRoughId_SieveSizeId_SizeSign_PieceCount_Weight_SarinActivityId", 4);

            Property(p => p.SarinActivityId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_Lot_SubRoughId_SieveSizeId_SizeSign_PieceCount_Weight_SarinActivityId", 5);

            Property(p => p.IsTopsLot)
                .IsOptional();

            Property(p => p.ClarityId)
                .IsOptional();

            Property(p => p.RoughCategoryId)
                .IsOptional();

            Property(p => p.ColorShadeId)
                .IsOptional();

            Property(p => p.ColorRateVersionId)
               .IsOptional();

            Property(p => p.Description)
                .IsOptional()
                .HasMaxLength(100)
                .IsUnicode(false);

            //Table
            ToTable("LotDetail");

            Property(p => p.SubRoughId).HasColumnName("SubRoughId").HasColumnOrder(2);
            Property(p => p.Weight).HasColumnName("Weight").HasColumnOrder(3);
            Property(p => p.PieceCount).HasColumnName("PieceCount").HasColumnOrder(4);
            Property(p => p.SieveSizeId).HasColumnName("SieveSizeId").HasColumnOrder(5);
            Property(p => p.SizeSign).HasColumnName("SizeSign").HasColumnOrder(6);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(7);
            Property(p => p.SarinActivityId).HasColumnName("SarinActivityId").HasColumnOrder(8);
            Property(p => p.ClarityId).HasColumnName("ClarityId").HasColumnOrder(9);
            Property(p => p.RoughCategoryId).HasColumnName("RoughCategoryId").HasColumnOrder(10);
            Property(p => p.ColorShadeId).HasColumnName("ColorShadeId").HasColumnOrder(11);

            Property(p => p.IsTopsLot).HasColumnName("IsTopsLot");

            HasRequired(l => l.SubRough) // 1 Lot is associated with 1 SubRough only
                .WithMany(sr => sr.Lots) //SubRough can have Multiple Lots
                .HasForeignKey(fk => fk.SubRoughId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasRequired(l => l.SarinActivity) // 1 Lot is associated with 1 Sarin Activity only
                .WithMany()
                .HasForeignKey(fk => fk.SarinActivityId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasOptional(l => l.Clarity) // 1 Lot is associated with 1 Clarity only on Makeable planning
                .WithMany()
                .HasForeignKey(fk => fk.ClarityId) //Foreign Key
                .WillCascadeOnDelete(false);

            //HasRequired(l => l.Assigning) // 1 lot is associated with 1 operator
            //    .WithMany()
            //    .HasForeignKey(fk => fk.AssignedTo)
            //    .WillCascadeOnDelete(false);

            HasOptional(l => l.RoughCategory)
                .WithMany()
                .HasForeignKey(fk => fk.RoughCategoryId)
                .WillCascadeOnDelete(false);

            HasOptional(l => l.RoughColorshade)
                .WithMany()
                .HasForeignKey(fk => fk.ColorShadeId)
                .WillCascadeOnDelete(false);

            HasOptional(l => l.ColorRateVersion)
                .WithMany()
                .HasForeignKey(fk => fk.ColorRateVersionId)
                .WillCascadeOnDelete(false);
        }
    }
}
