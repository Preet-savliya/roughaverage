﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class AppUserMap : BaseEntityMap<AppUser>
    {
        #region Ctor
        public AppUserMap()
        {
            //Properties
            Property(p => p.RoleId)
                .IsRequired();

            Property(p => p.EmployeeId)
                .IsRequired();

            Property(p => p.LoginId)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_AppUser_LoginId", 0);

            Property(p => p.Password)
                .HasMaxLength(400)
                .IsUnicode(false)
                .IsRequired();

            Property(p => p.LoginStatus)
                .IsRequired();

            Property(p => p.LastLoginOn)
                .IsOptional()
                .HasColumnType("datetime2");

            //Table & Column Mapping
            ToTable("UserMaster");

            Property(p => p.EmployeeId).HasColumnName("EmployeeId").HasColumnOrder(2);
            Property(p => p.LoginId).HasColumnName("LoginId").HasColumnOrder(3);
            Property(p => p.Password).HasColumnName("Password").HasColumnOrder(4);
            Property(p => p.RoleId).HasColumnName("RoleId").HasColumnOrder(5);
            Property(p => p.LoginStatus).HasColumnName("LoginStatus").HasColumnOrder(6);
            Property(p => p.LastLoginOn).HasColumnName("LastLoginOn").HasColumnOrder(7);

            //Relationship
            HasRequired(p => p.Role) // role is associated to user
                .WithMany() // 1 role is assigned to many user
                .HasForeignKey(p => p.RoleId) // ForeignKey 
                .WillCascadeOnDelete(false);

            HasRequired(p => p.Employee) 
                .WithMany() 
                .HasForeignKey(p => p.EmployeeId) // ForeignKey 
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
