﻿namespace SD.Rough.Average.Data.Mapping
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.Extensions;

    public class RoughColorShadeMap : BaseEntityMap<RoughColorShade>
    {
        #region Ctor
        public RoughColorShadeMap()
        {
            //Properties
            Property(p => p.Name)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughColorShade_Name", 0);

            Property(p => p.LotColorGroupName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsOptional();

            Property(p => p.LotColorDisplayOrder)
                .IsOptional();

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();  // Accepts Null

            //Table & Column Mapping
            ToTable("RoughColorShadeMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.LotColorGroupName).HasColumnName("LotColorGroupName").HasColumnOrder(3);
            Property(p => p.LotColorDisplayOrder).HasColumnName("LotColorDisplayOrder").HasColumnOrder(4);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(5);

            // Relationships
            HasOptional(e => e.Color)
               .WithMany()
               .HasForeignKey(fk => fk.ColorId)
               .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
