﻿using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class ExtraMakeableStoneMap : BaseEntityMap<ExtraMakeableStone>
    {
        #region Ctor
        public ExtraMakeableStoneMap()
        {
            //Table
            ToTable("ExtraMakeableStoneDetail");

            Property(p => p.LotId).HasColumnOrder(2);
            Property(p => p.StoneNumber).HasColumnOrder(3);
            //Relationships
            HasRequired(l => l.Lot) 
                .WithMany() 
                .HasForeignKey(fk => fk.LotId) //Foreign Key
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
