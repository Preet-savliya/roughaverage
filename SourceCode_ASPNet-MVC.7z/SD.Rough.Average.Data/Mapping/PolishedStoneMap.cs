﻿using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class PolishedStoneMap : BaseEntityMap<PolishedStone>
    {
        public PolishedStoneMap()
        {
            // Ignored Properties
            Ignore(p => p.IsValid);
            Ignore(p => p.Comment);
            Ignore(p => p.SieveSize);

            Property(p => p.PartWeight)
                .HasColumnType("numeric")
                .HasPrecision(5, 3)
                .IsRequired();

            Property(p => p.PolishedWeight)
                .HasColumnType("numeric")
                .HasPrecision(5, 3)
                .IsRequired();

            Property(p => p.Rate)
                .HasColumnType("numeric")
                .HasPrecision(8, 2)
                .IsRequired();

            Property(p => p.OldRate)
               .HasColumnType("numeric")
               .HasPrecision(8, 2);

            Property(p => p.Diameter)
                .HasColumnType("numeric")
                .HasPrecision(5, 2)
                .IsRequired();

            Property(p => p.Length)
                .HasColumnType("numeric")
                .HasPrecision(5, 3)
                .IsRequired();

            Property(p => p.MeasureByValue)
                .HasColumnType("numeric")
                .HasPrecision(5, 2)
                .IsRequired();

            Property(p => p.OldMeasureByValue)
                .HasColumnType("numeric")
                .HasPrecision(5, 2);            

            Property(p => p.MinSieveSizeId)
                .IsOptional();

            Property(p => p.MaxSieveSizeId)
                .IsOptional();

            Property(p => p.StoneId)
                .IsRequired();

            Property(p => p.ColorRateVersionId)
                .IsOptional();

            Property(p => p.ClarityId)
                .IsOptional();

            Property(p => p.ShapeId)
                .IsOptional();

            /* Property(p => p.Rate)
                 .IsRequired();*/

            //Table & Column Mapping
            ToTable("PolishedStoneDetail");

            Property(p => p.StoneId).HasColumnName("StoneId").HasColumnOrder(2);
            Property(p => p.ColorRateVersionId).HasColumnName("ColorRateVersionId").HasColumnOrder(3);
            Property(p => p.ClarityId).HasColumnName("ClarityId").HasColumnOrder(4);
            Property(p => p.ShapeId).HasColumnName("ShapeId").HasColumnOrder(5);
            Property(p => p.PartWeight).HasColumnName("PartWeight").HasColumnOrder(6);
            Property(p => p.PolishedWeight).HasColumnName("PolishedWeight").HasColumnOrder(7);
            Property(p => p.Rate).HasColumnName("Rate").HasColumnOrder(8);
            Property(p => p.OldRate).HasColumnName("OldRate").HasColumnOrder(9);
            Property(p => p.Diameter).HasColumnName("Diameter").HasColumnOrder(10);
            Property(p => p.Length).HasColumnName("Length").HasColumnOrder(11);
            Property(p => p.MeasureByValue).HasColumnName("MeasureByValue").HasColumnOrder(12);
            Property(p => p.OldMeasureByValue).HasColumnName("OldMeasureByValue").HasColumnOrder(13);
            Property(p => p.MinSieveSizeId).HasColumnName("MinSieveSizeId").HasColumnOrder(14);
            Property(p => p.MaxSieveSizeId).HasColumnName("MaxSieveSizeId").HasColumnOrder(15);

            //Relationships
            HasRequired(psd => psd.Stone) // 1 PolishedStone is associated with 1 Stone only
                .WithMany(s => s.PolishedStones) //Stone can have Multiple PolishedStoneDetails
                .HasForeignKey(fk => fk.StoneId) //Foreign Key
                .WillCascadeOnDelete(true);

            HasOptional(psd => psd.ColorRateVersion) // 1 PolishedStone is associated with 1 ColorRateVersion only
                .WithMany() //1 ColorRateVersion is assigned Many PolishedStone
                .HasForeignKey(fk => fk.ColorRateVersionId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasOptional(psd => psd.Clarity) // 1 PolishedStone is associated with 1 Clarity only
                .WithMany() //1 Clarity is assigned Many PolishedStone
                .HasForeignKey(fk => fk.ClarityId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasOptional(psd => psd.Shape) // 1 PolishedStone is associated with 1 Shape only
                .WithMany() //1 Shape is assigned to many PolishedStone
                .HasForeignKey(fk => fk.ShapeId) //Foreign Key
                .WillCascadeOnDelete(false);

            HasOptional(ms => ms.MinSieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.MinSieveSizeId)
                .WillCascadeOnDelete(false);

            HasOptional(ms => ms.MaxSieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.MaxSieveSizeId)
                .WillCascadeOnDelete(false);
        }
    }
}
