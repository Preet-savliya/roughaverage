﻿namespace SD.Rough.Average.Data.Mapping
{
    public class RoughMap : BaseEntityMap<Models.Rough>
    {
        #region Ctor
        public RoughMap()
        {
            Property(p => p.Weight)
                .IsRequired()
                .HasColumnType("numeric")
                .HasPrecision(8, 3);

            Property(p => p.PieceCount)
                .IsRequired();

            Property(p => p.Description)
                .IsOptional()
                .HasMaxLength(100)
                .IsUnicode(false);

            Property(p => p.RoughTypeId)
                .IsRequired();

            //Table and column mapping
            ToTable("RoughDetail");

            Property(p => p.Weight).HasColumnName("Weight").HasColumnOrder(2);
            Property(p => p.PieceCount).HasColumnName("PieceCount").HasColumnOrder(3);
            Property(p => p.RoughTypeId).HasColumnName("RoughTypeId").HasColumnOrder(4);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(6);

            //Relationship
            HasRequired(r => r.RoughType) // 1 rough is associated with 1 one Roughtype
                .WithMany() // 1 roughType has many roughs
                .HasForeignKey(fk => fk.RoughTypeId) //foreignKey
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
