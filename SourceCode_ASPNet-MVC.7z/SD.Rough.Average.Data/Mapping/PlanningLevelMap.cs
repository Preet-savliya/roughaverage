﻿namespace SD.Rough.Average.Data.Mapping
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.Extensions;

    public class PlanningLevelMap : BaseEntityMap<PlanningLevel>
    {
        #region Ctor
        public PlanningLevelMap()
        {
            //Properties
            Property(p => p.Name)
                .HasMaxLength(30)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_PlanningLevel_Name", 0);

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();  // Accepts Null

            //Table & Column Mapping
            ToTable("PlanningLevelMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(3);
        }
        #endregion
    }
}
