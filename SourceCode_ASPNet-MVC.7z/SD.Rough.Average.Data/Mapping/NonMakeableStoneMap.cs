﻿using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class NonMakeableStoneMap : BaseEntityMap<NonMakeableStone>
    {
        #region Ctor
        public NonMakeableStoneMap()
        {
            //Table
            ToTable("NonMakeableStoneDetail");

            Property(p => p.LotId).HasColumnOrder(2);
            Property(p => p.StoneNumber).HasColumnOrder(3);
            //Relationships
            HasRequired(l => l.Lot) 
                .WithMany() 
                .HasForeignKey(fk => fk.LotId) //Foreign Key
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
