﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class ColorRateVersionMap : BaseEntityMap<ColorRateVersion>
    {
        public ColorRateVersionMap()
        {
            Property(p => p.Name)
                .HasMaxLength(15)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_ColorRateVersion_ColorIdName", 0);

            Property(p => p.ColorId)
                .HasUniqueIndexAnnotation("UQ_ColorRateVersion_ColorIdName", 1);

            Property(p => p.EffectiveFrom)
                .HasColumnType("date");

            ToTable("ColorRateVersionMaster");

            Property(p => p.ColorId).HasColumnName("ColorId").HasColumnOrder(2);
            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(3);
            Property(p => p.EffectiveFrom).HasColumnName("EffectiveFrom").HasColumnOrder(4);

            HasRequired(p => p.Color)
                .WithMany(p => p.ColorRateVersions)
                .HasForeignKey(p => p.ColorId) // ForeignKey 
                .WillCascadeOnDelete(false);
        }
    }
}
