﻿using SD.Rough.Average.Models;

namespace SD.Rough.Average.Data.Mapping
{
    public class EmployeeMap : BaseEntityMap<Employee>
    {
        #region Ctor
        public EmployeeMap()
        {
            //Properties
            Property(p => p.EmployeeNo)
                .HasMaxLength(10); // Maximum Size

            Property(p => p.FirstName)
                .HasMaxLength(20) // Maximum Size
                .IsUnicode(false)
                .IsRequired(); //Not Null

            Property(p => p.LastName)
                .HasMaxLength(20)
                .IsUnicode(false)
                .IsRequired();

            Property(p => p.DesignationId)
                .IsRequired();

            //Table & Column Mapping
            ToTable("EmployeeMaster");

            Property(p => p.EmployeeNo).HasColumnName("EmployeeNo").HasColumnOrder(2);
            Property(p => p.FirstName).HasColumnName("FirstName").HasColumnOrder(3);
            Property(p => p.LastName).HasColumnName("LastName").HasColumnOrder(4);
            Property(p => p.DesignationId).HasColumnName("DesignationId").HasColumnOrder(5);

            //Relationship
            HasRequired(p => p.Designation) // 1 designation is associated to 1 employee
                .WithMany(p => p.Employees) // 1 designation is assigned to many employess
                .HasForeignKey(p => p.DesignationId) // ForeignKey 
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
