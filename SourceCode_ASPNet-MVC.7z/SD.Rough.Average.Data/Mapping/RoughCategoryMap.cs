﻿namespace SD.Rough.Average.Data.Mapping
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.Extensions;

    public class RoughCategoryMap : BaseEntityMap<RoughCategory>
    {
        #region Ctor
        public RoughCategoryMap()
        {
            //Properties
            Property(p => p.Name)
                .HasMaxLength(30)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughCategory_Name", 0);

            Property(p => p.Description)
                .HasMaxLength(100)
                .IsUnicode(false)
                .IsOptional();  // Accepts Null

            //Table & Column Mapping
            ToTable("RoughCategoryMaster");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.Description).HasColumnName("Description").HasColumnOrder(3);
        }
        #endregion
    }
}
