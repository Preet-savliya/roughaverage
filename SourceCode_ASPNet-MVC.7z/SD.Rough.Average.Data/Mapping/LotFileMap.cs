﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    public class LotFileMap : BaseEntityMap<LotFile>
    {
        #region Ctor
        public LotFileMap()
        {
            Property(p => p.LotId)
                .HasUniqueIndexAnnotation("UQ_LotFileDetail_LotId_FileName", 0);

            Property(p => p.FileName)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_LotFileDetail_LotId_FileName", 1);
            //Table
            ToTable("LotFileDetail");

            Property(p => p.LotId).HasColumnOrder(2);
            Property(p => p.FileName).HasColumnOrder(3);

            //Relationships
            HasRequired(l => l.Lot)
                .WithMany(sr => sr.LotFiles)
                .HasForeignKey(fk => fk.LotId) //Foreign Key
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
