﻿using SD.Rough.Average.Data.Extensions;

namespace SD.Rough.Average.Data.Mapping
{
    using Models;
    public class RoughSizeSieveSizeMap : BaseEntityMap<RoughSizeSieveSize>
    {
        #region Ctor
        public RoughSizeSieveSizeMap()
        {
            //Properties
            Property(p => p.RoughSizeId)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughSizeSieveSize_RoughSizeIdName", 0);

            Property(p => p.Name)
                .HasMaxLength(12)
                .IsUnicode(false)
                .IsRequired()
                .HasUniqueIndexAnnotation("UQ_RoughSizeSieveSize_RoughSizeIdName", 1);

            Property(p => p.MinSieveSizeId)
                .IsOptional();

            Property(p => p.MaxSieveSizeId)
                .IsOptional();

            Property(p => p.DisplayOrder)
                .IsRequired();

            //Table & Column Mapping
            ToTable("RoughSizeSieveSizeMap");

            Property(p => p.Name).HasColumnName("Name").HasColumnOrder(2);
            Property(p => p.RoughSizeId).HasColumnName("RoughSizeId").HasColumnOrder(3);
            Property(p => p.MinSieveSizeId).HasColumnName("MinSieveSizeId").HasColumnOrder(4);
            Property(p => p.MaxSieveSizeId).HasColumnName("MaxSieveSizeId").HasColumnOrder(5);
            Property(p => p.DisplayOrder).HasColumnName("DisplayOrder").HasColumnOrder(6);

            //Relationships
            HasRequired(r => r.RoughSize)
                .WithMany(sr => sr.RoughSizeSieveSizes)
                .HasForeignKey(fk => fk.RoughSizeId);

            HasOptional(ms => ms.MinSieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.MinSieveSizeId)
                .WillCascadeOnDelete(false);

            HasOptional(ms => ms.MaxSieveSize)
                .WithMany()
                .HasForeignKey(fk => fk.MaxSieveSizeId)
                .WillCascadeOnDelete(false);
        }
        #endregion
    }
}
