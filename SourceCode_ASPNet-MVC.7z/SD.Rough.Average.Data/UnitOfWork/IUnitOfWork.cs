﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.Repositories;

namespace SD.Rough.Average.Data.UnitOfWork
{
    public interface IUnitOfWork
    {
        void Save();
        
        IRepository<TEntity> Repository<TEntity>() where TEntity : BaseEntity;
        
        void Dispose();
        void Dispose(bool disposing);
    }
}
