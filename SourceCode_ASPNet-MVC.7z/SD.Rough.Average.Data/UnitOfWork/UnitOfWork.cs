﻿using System;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.DataContext;
using SD.Rough.Average.Data.Repositories;
using System.Data;

namespace SD.Rough.Average.Data.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private BaseDbContext _dbContext;
        private Dictionary<string, dynamic> _repositories;

        private bool _disposed;

        public UnitOfWork(BaseDbContext context)
        {
            _dbContext = context;
            _repositories = new Dictionary<string, dynamic>();
        }

        public void Save()
        {
            if (_dbContext != null)
            {
                using (var dbTransaction = _dbContext.Database.BeginTransaction(IsolationLevel.ReadCommitted))
                {
                    try
                    {
                        _dbContext.SaveChanges();
                        dbTransaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                }
            }
        }
        public IRepository<TEntity> Repository<TEntity>() where TEntity : BaseEntity
        {
            if (_repositories == null)
            {
                _repositories = new Dictionary<string, dynamic>();
            }

            var type = typeof(TEntity).Name;

            if (_repositories.ContainsKey(type))
            {
                return (IRepository<TEntity>)_repositories[type];
            }

            var repositoryType = typeof(Repository<>);

            _repositories.Add(type, Activator.CreateInstance(repositoryType.MakeGenericType(typeof(TEntity)), _dbContext));

            return _repositories[type];
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        public virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing)
            {
                if (_dbContext != null)
                {
                    _dbContext.Dispose();
                    _dbContext = null;
                }
            }
            _disposed = true;
        }
    }
}
