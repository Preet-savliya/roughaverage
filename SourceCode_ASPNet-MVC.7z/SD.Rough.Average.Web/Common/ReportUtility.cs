﻿using System.Linq;

using SD.Rough.Average.Models;
using SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel;

using static SD.Rough.Average.Core.AppGlobalSettings;
using static SD.Rough.Average.Services.Shared.LotExtensions;

namespace SD.Rough.Average.Web.Common
{
    public class ReportUtility
    {
        public static ReportSummary CalculateWhitenerSummary(SubRough subRough,
            string sarinActivity, bool isTopsLot)
        {
            decimal totalStoneRoughWeight = (sarinActivity == RoughSarinActivity
                ? subRough.Lots.LotsBySarinActivity(sarinActivity)
                : subRough.Lots.LotsBySarinActivity(sarinActivity, isTopsLot))
                .Select(x => x.Stones.Sum(s => s.Weight))
                .Sum();

            decimal cutWeight = sarinActivity == RoughSarinActivity
                ? subRough.Weight.Value
                : (subRough.MakeableWeight.HasValue ? subRough.MakeableWeight.Value : 0);

            var whitenerSummary = new ReportSummary()
            {
                Weight = totalStoneRoughWeight - cutWeight
            };

            whitenerSummary.Average = cutWeight > 0
                ? whitenerSummary.Weight / cutWeight
                : 0;

            return whitenerSummary;
        }
    }
}