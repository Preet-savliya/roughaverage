﻿using System.IO;
using System.Web.Hosting;
using System.Collections.Generic;
using Newtonsoft.Json;
using SD.Rough.Average.Core;
using SD.Rough.Average.Services;
using System.Linq;

namespace SD.Rough.Average.Web.Common
{
    public class LotFileHeaderProvider
    {
        public static IReadOnlyList<LotFileHeaderSchema> LoadSchema()
        {
            var fileContent = File.ReadAllText(HostingEnvironment.MapPath(AppGlobalSettings.LotFileHeadersFilePath));

            var jsonDataObjectType = new[] { new { Name = "", IsMultipart = false, DerivedFromParts = false } };
            var result = JsonConvert.DeserializeAnonymousType(fileContent, jsonDataObjectType);

            return result
                .Select(s => new LotFileHeaderSchema
                {
                    Name = s.Name,
                    AttributeOf = s.IsMultipart ? AttributeOf.Part : AttributeOf.Stone,
                    DerivedFromParts = s.DerivedFromParts
                }).ToList().AsReadOnly();

            //return JsonConvert.DeserializeObject<List<LotFileHeaderSchema>>(fileContent).AsReadOnly();
        }

        //public static IReadOnlyList<LotFileHeaderSchema> LoadSchema(bool fileWithColor)
        //{
        //    var headersFile = fileWithColor
        //        ? AppGlobalSettings.LotFileHeadersWithColorFilePath
        //        : AppGlobalSettings.LotFileHeadersFilePath;

        //    var fileContent = File.ReadAllText(HostingEnvironment.MapPath(headersFile));

        //    return JsonConvert.DeserializeObject<List<LotFileHeaderSchema>>(fileContent).AsReadOnly();
        //}
    }
}