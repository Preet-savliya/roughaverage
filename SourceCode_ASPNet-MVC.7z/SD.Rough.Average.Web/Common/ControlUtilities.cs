﻿using System;
using System.Linq;
using System.Web.Mvc;
using System.Collections.Generic;
using SD.Rough.Average.Core;

namespace SD.Rough.Average.Web.Common
{
    public static class ControlUtility
    {
        public static IList<SelectListItem> GetEntryStatusData()
        {
            return new List<SelectListItem>()
            {
                new SelectListItem() { Text = "Active", Value = "true", Selected = true },
                new SelectListItem() { Text = "InActive", Value = "false" },
            };
        }
    }

    public static class SelectListExtensions
    {
        public static IList<SelectListItem> ToSelectListItem<T>(this IEnumerable<T> data,
            Func<T, object> toGetValue, Func<T, object> toGetText, object selectedId)
        {
            IList<SelectListItem> resultData = new List<SelectListItem>();

            return data
                .Select(x => new SelectListItem
                {
                    Value = toGetValue(x).ToString(),
                    Text = toGetText(x).ToString(),
                    Selected = (selectedId != null && toGetValue(x).ToString() == selectedId.ToString())
                }).ToList();
        }

        public static IList<SelectListItem> ToSelectListItem<T>(this IEnumerable<T> data,
            Func<T, object> toGetValue, Func<T, object> toGetText, object selectedId = null,
            DropdownDefaultValue defaultItemText = DropdownDefaultValue.None, string defaultItemValue = "0")
        {
            IList<SelectListItem> resultData = new List<SelectListItem>();

            resultData = data
                .Select(x => new SelectListItem
                {
                    Value = toGetValue(x).ToString(),
                    Text = toGetText(x).ToString(),
                    Selected = (toGetValue(x) == selectedId)
                }).ToList();

            if (defaultItemText != DropdownDefaultValue.None)
            {
                SelectListItem defaultSelectListItem = new SelectListItem
                {
                    Value = defaultItemValue,
                    Text = Convert.ToString(defaultItemText)
                };
                resultData.Insert(0, defaultSelectListItem);
            }

            return resultData;
        }
    }
}