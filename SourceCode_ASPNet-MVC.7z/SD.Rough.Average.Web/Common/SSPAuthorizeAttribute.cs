﻿using SD.Rough.Average.Models;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace SD.Rough.Average.Web.Common
{
    public enum SSPAuthorizeOption
    {
        /// <summary>
        /// No security checking, enable to access by public client. No login required
        /// </summary>
        Public = 0,
        /// <summary>
        /// User should be logged in into system, but no role based permission will be checked
        /// </summary>
        Login = 1,
        /// <summary>
        /// User should be logged in into system and role based permission will also check
        /// </summary>
        Permission = 2
    }

    public class SSPAuthorizeAttribute : AuthorizeAttribute
    {
        #region Private Fields
        private readonly SSPAuthorizeOption _option;
        private const string SESSION_USER = "LogonUser";
        #endregion

        #region Ctor
        public SSPAuthorizeAttribute()
        {
            _option = SSPAuthorizeOption.Login;
        }

        public SSPAuthorizeAttribute(SSPAuthorizeOption authorize)
        {
            _option = authorize;
        }
        #endregion

        #region Methods
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool result = false;

            switch (_option)
            {
                case SSPAuthorizeOption.Public:
                    result = true;
                    break;

                case SSPAuthorizeOption.Login:
                    if (LogonUser(httpContext) != null && LogonUser(httpContext).Id > 0)
                        result = true;
                    break;

                case SSPAuthorizeOption.Permission: // After Client login system, also require further permissions check to access current page.       

                    if (LogonUser(httpContext) != null && LogonUser(httpContext).Id > 0)
                        result = true;
                    break;

                default:
                    result = base.AuthorizeCore(httpContext);
                    break;

            }
            return result;
        }

        /// <summary>
        ///  If unauthorize, redirect to sigin page again. Note: We must have Home.Signin action method in each web project.
        ///  Reference: http://markfreedman.com/index.php/2012/02/28/handling-session-and-authentication-timeouts-in-asp-net-mvc/
        /// </summary>
        /// <param name="filterContext"></param>
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (LogonUser(filterContext) == null)
            {
                // If it is ajax calling for example render partial views.
                // Reference: http://stackoverflow.com/questions/5238854/handling-session-timeout-in-ajax-calls
                //
                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.HttpContext.Response.Clear();

                    // Important part here, prevent system going to the orignal calling method.
                    filterContext.Result = new RedirectToRouteResult(
                        new RouteValueDictionary
                        {
                            { "action", "UnAuthorizedAjaxCall" },
                            { "controller", "Account"},
                            { "message", "Your session has timed out. Please login again"}
                        });
                    filterContext.HttpContext.Response.StatusCode = 401; //Unauthorized Reference: http://www.w3.org/Protocols/rfc2616/rfc2616-sec10.html
                    filterContext.HttpContext.Response.End();
                }
                else
                {
                    // redirect to the logon page.
                    filterContext.Result = new RedirectToRouteResult(
                        new RouteValueDictionary
                        {
                            { "action", "Login" },
                            { "controller", "Account" },
                            { "message", "Your session has timed out. Please login again"}
                        });
                }
            }
        }

        /// <summary>
        ///  Current logon user entity. Keeping User's generic information and User roles, permissions data in a session called "SessionLogonUser".
        ///  Note: Don't keep user login password in here for security.
        ///  It is read only property.
        /// </summary>
        protected AppUser LogonUser(HttpContextBase httpContext)
        {
            if (httpContext.Session[SESSION_USER] != null)
                return httpContext.Session[SESSION_USER] as AppUser;
            else
                return null;
        }
        protected AppUser LogonUser(AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.Session[SESSION_USER] != null)
                return filterContext.HttpContext.Session[SESSION_USER] as AppUser;
            else
                return null;

        }
        #endregion
    }
}