﻿using System;
using System.ComponentModel.DataAnnotations;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels
{
    public class RoughSearchViewModel : BaseViewModel
    {
        [DisplayFormat(DataFormatString = DecimalFormatString)]
        [Display(Name = "Rough weight")]
        public decimal? Weight { get; set; }

        [DisplayFormat(DataFormatString = NumberFormatString)]
        [Display(Name = "Piece count")]
        public int? PieceCount { get; set; }
        public int? RoughTypeId { get; set; }

        [DisplayFormat(DataFormatString = DateFormatString)]
        public DateTime? CreatedOnDateFrom { get; set; }

        [DisplayFormat(DataFormatString = DateFormatString)]
        public DateTime? CreatedOnDateTo { get; set; }
    }
}