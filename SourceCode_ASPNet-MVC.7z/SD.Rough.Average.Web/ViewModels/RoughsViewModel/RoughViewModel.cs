﻿using System.ComponentModel.DataAnnotations;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels
{
    public class RoughViewModel : BaseViewModel
    {
        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), DecimalPositiveMinValue, WeightMaxValue, ErrorMessage = DecimalPositiveZeroErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Rough weight")]
        public decimal? Weight { get; set; }

        [DisplayFormat(DataFormatString = NumberFormatString, ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Range(IntPositiveMinValue, PieceMaxValue, ErrorMessage = NumberPositiveZeroErrorMessage)]
        [RegularExpression(DigitOneToMaxFourDigitRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Display(Name = "Piece count")]
        public int? PieceCount { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Rough type")]
        public int RoughTypeId { get; set; }
    }
}