﻿using SD.Rough.Average.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughsViewModel
{
    public class MakeableEntryViewModel
    {
        public int Id { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), DecimalPositiveMinValue, WeightMaxValue, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Weight")]
        public decimal? Weight { get; set; }

        [Range(IntPositiveMinValue, PieceMaxValue, ErrorMessage = NumberPositiveZeroErrorMessage)]
        [RegularExpression(DigitOneToMaxFourDigitRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Piece(s)")]
        public int? PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), LowerLimitPolishedDiameter, UpparLimitMinPolishedDiameter, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Min Polished Diameter")]
        public decimal? MinPolishedDiameter { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), LowerLimitPolishedDiameter, UpparLimitTopsPolishedDiameter, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Tops Polished Diameter")]
        public decimal? TopsPolishedDiameter { get; set; }

        public IList<Loss> Losses { get; set; }
        public IList<Rejection> Rejections { get; set; }
        public IList<Loss> Damages { get; set; }

        //public IList<Loss> GalaxyLosses { get; set; }
        public IList<Loss> LaserLosses { get; set; }
        public IList<Loss> LasesDamages { get; set; }
    }
}