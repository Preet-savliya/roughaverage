﻿using System.Web.UI.WebControls;

namespace SD.Rough.Average.Web.ViewModels.SubRoughsViewModel
{
    public class SubRoughStickerViewModel
    {
        public int SubRoughId { get; set; }
        public string RoughType { get; set; }

        public decimal RoughWeight { get; set; }
        public int RoughPieces { get; set; }

        public decimal MakeableWeight { get; set; }
        public int MakeablePieces { get; set; }

        public int CutNo { get; set; }
        public string RoughSize { get; set; }
        public string ColorShade { get; set; }
        
        public string RoughPlanningContent
        {
            get
            {
                return CutNo > 0
                    ? $"{RoughWeight}({CutNo}), {RoughPieces}"
                    : $"{RoughWeight}, {RoughPieces}";
            }
        }
        public string MakeablePlanningContent
        {
            get
            {
                return MakeableWeight > 0
                    ? $"{MakeableWeight}, {MakeablePieces}"
                    : string.Empty;
            }
        }
        public string StickerPrintContent
        {
            get
            {
                var content = $"{SubRoughId}, {RoughPlanningContent}";

                if (MakeableWeight > 0)
                {
                    return $"{content}, {MakeablePlanningContent}";
                }
                return content;

                //if (!string.IsNullOrWhiteSpace(ColorShade))
                //{
                //    content = string.Concat(content, $" {ColorShade}");
                //}

                //if (RoughType != "Galaxy" && !string.IsNullOrWhiteSpace(RoughType))
                //{
                //    content = string.Concat(content, $" {RoughType}");
                //}

                //return content;
            }
        }
    }
}