﻿using System;
using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughsViewModel
{
    public class MakeableTopsEntryViewModel
    {
        public int Id { get; set; }

        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), DecimalPositiveMinValue, WeightMaxValue, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Weight")]
        public decimal? Weight { get; set; }

        [Range(IntPositiveMinValue, PieceMaxValue, ErrorMessage = NumberPositiveZeroErrorMessage)]
        [RegularExpression(DigitOneToMaxFourDigitRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Piece(s)")]
        public int? Pieces { get; set; }
    }
}