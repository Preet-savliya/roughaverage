﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SD.Rough.Average.Models;
//Static-References
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughsViewModel
{
    public class SubRoughViewModel : BaseViewModel
    {
        public SubRough SubRough { get; set; }

        public List<RoughCategory> RoughSubTypes { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Which SieveSize File")]
        public string SieveSizeFileAction { get; set; }

        public bool IsCombineReport { get; set; }
        public bool IsDisplayRate { get; set; }
        public bool IsDisplayLotWiseSizeProportion { get; set; }
        public bool IsSieveSizeFileSelected { get; set; }
        //public int LossCount { get; set; }

        public IList<Loss> Losses { get; set; }
        public IList<Rejection> Rejections { get; set; }
        public IList<Loss> Damages { get; set; }

        //public IList<Loss> GalaxyLosses { get; set; }
        public IList<Loss> LaserLosses { get; set; }
        public IList<Loss> LaserDamages { get; set; }
    }
}