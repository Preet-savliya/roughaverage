﻿using System;
using System.ComponentModel.DataAnnotations;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughsViewModel
{
    public class SubRoughSearchViewModel : BaseViewModel
    {
        #region Properties
        //[DisplayFormat(DataFormatString = DecimalFormatString)]
        //[Display(Name = "Weight")]
        //public decimal? RoughWeight { get; set; }

        //[DisplayFormat(DataFormatString = NumberFormatString)]
        //[Display(Name = "Piece count")]
        //public int? RoughPieceCount { get; set; }
        //public int? RoughTypeId { get; set; }

        //[DisplayFormat(DataFormatString = DecimalFormatString)]
        [Display(Name = "Weight")]
        public decimal? Weight { get; set; }

        //[DisplayFormat(DataFormatString = NumberFormatString)]
        [Display(Name = "Piece count")]
        public int? PieceCount { get; set; }
        public decimal? TopsPolishedDiameter { get; set; }
        public int? RoughTypeId { get; set; }
        public int? RoughColorShadeId { get; set; }
        public int? Number { get; set; }
        public int? RoughSizeId { get; set; }
        public int? ManagerId { get; set; }

        [DisplayFormat(DataFormatString = DateFormatString)]
        public DateTime? SubRoughDateFrom { get; set; }

        [DisplayFormat(DataFormatString = DateFormatString)]
        public DateTime? SubRoughDateTo { get; set; }
        public bool IsDisplayAll { get; set; } = true;
        public bool IsActive { get; set; } = false;
        #endregion
    }
}