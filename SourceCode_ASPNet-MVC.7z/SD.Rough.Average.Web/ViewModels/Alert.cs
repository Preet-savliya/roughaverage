﻿namespace SD.Rough.Average.Web.ViewModels
{
    public class Alert
    {
        #region Fields
        public const string TempDataKey = "TempDataAlerts";
        #endregion

        #region Properties
        public string AlertStyle { get; set; }
        public string Message { get; set; }
        public bool Dismissible { get; set; }
        #endregion
    }

    public static class AlertStyles
    {
        #region Fields
        public const string success = "success";
        public const string information = "info";
        public const string warning = "warning";
        public const string danger = "danger";
        #endregion
    }
}