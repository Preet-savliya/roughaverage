﻿using System.ComponentModel.DataAnnotations;

namespace SD.Rough.Average.Web.ViewModels
{
    public class LoginViewModel
    {
        #region Properties
        [Required(ErrorMessage = "User id is required")]
        [DataType(DataType.EmailAddress)]
        [Display(Name = "User Id")]
        public string LoginId { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }
        #endregion
    }
}