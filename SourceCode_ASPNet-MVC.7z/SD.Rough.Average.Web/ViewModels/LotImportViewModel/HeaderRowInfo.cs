﻿namespace SD.Rough.Average.Web.ViewModels.LotImportViewModel
{
    public class HeaderRowInfo
    {
        public string FilePath { get; set; }
        public string HeaderRow { get; set; }
        public int Count { get; set; }
        public bool IsFileWithColor { get; set; }
        public int PartCount { get; set; }
    }
}