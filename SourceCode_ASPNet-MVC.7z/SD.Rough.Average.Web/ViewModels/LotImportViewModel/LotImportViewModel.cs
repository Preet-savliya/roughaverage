﻿using System.Web;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SD.Rough.Average.Core;
using SD.Rough.Average.Services.DTO;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.LotImportViewModel
{
    public class LotImportViewModel : BaseViewModel
    {
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Sub Rough")]
        public int SubRoughId { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Sub Rough")]
        public string SubRoughName { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Sarin Activity")]
        public string SarinActivity { get; set; }

        [Display(Name = "Lot Type")]
        public bool? IsTopsLot { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Lot")]
        public int LotId { get; set; }

        [RegularExpression(NumericAndComaRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Non-Process Stone Number(s)")]
        public string NonMakeableStoneNumbers { get; set; }

        [RegularExpression(NumericAndComaRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Extra Stone Number(s)")]
        public string ExtraMakeableStoneNumbers { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Action")]
        public ImportAction Action { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "File")]
        public HttpPostedFileBase File { get; set; }
    }

    public class LotImportStonesDetailViewModel
    {
        public int LotId { get; set; }
        public int StoneNumber { get; set; }
        public IList<string> FileNames { get; set; }
        public int PolishedStoneCount { get; set; }
        public int TopsPolishedStoneCount { get; set; }
        public IList<string> PolishedStoneName { get; set; }
    }

    public class SieveSizeName
    {
        public string MinSieveSize { get; set; }
        public string MaxSieveSize { get; set; }
    }

    public class NonMakeableStoneDetailViewModel
    {
        public int StoneNumber { get; set; }
        public int PolishedStoneCount { get; set; }
    }

    public class ExtraMakeableStoneDetailViewModel
    {
        public int StoneNumber { get; set; }
        public int PolishedStoneCount { get; set; }
    }

    public class LotFileStone
    {
        public int StoneId { get; set; }
        public int LotFileId { get; set; }
        public string StoneNumber { get; set; }
        public string FileName { get; set; }
    }

    public class NewFileOperator
    {
        public string FileName { get; set; }
        public string Operator { get; set; }
    }

    public class UploadedFileOperator : NewFileOperator
    {
        public int LotFileId { get; set; }
    }

    public class FileOperatorSummary
    {
        public IList<NewFileOperator> UploadingFiles { get; set; }
        public IList<UploadedFileOperator> UploadedFiles { get; set; }
        //public IList<UploadedFileOperator> UploadedOtherFiles { get; set; }

        public IList<NewFileOperator> NewFiles { get; set; }
        /// <summary>
        /// Updating files which are already uploaded into the system but overwriting with new files data
        /// </summary>
        public IList<UploadedFileOperator> UpdatingFiles { get; set; }
    }

    public class InvalidStoneViewModel
    {
        public int StoneNumber { get; set; }
        public IList<string> FileNames { get; set; }
        public int FileMakeableStoneCount { get; set; }
    }

    public class MismatchStoneViewModel
    {
        public int StoneNumber { get; set; }

        public IList<string> FileNames { get; set; }

        public int RoughTotalPolStoneCount { get; set; }
        public int TopsPolishedStoneCount { get; set; }
        public int RoughMakeablePolStoneCount => RoughTotalPolStoneCount - TopsPolishedStoneCount;

        public int FileMakeableStoneCount { get; set; }
        public int NonMakeableStoneCount { get; set; }
        public int ExtraMakeableStoneCount { get; set; }

        public int MismatchStoneCount { get; set; }
    }

    public class StoneValidationErrorResult
    {
        public string Error { get; set; }
        public List<InvalidStoneViewModel> InvalidStones { get; set; }
        public IList<MismatchStoneViewModel> MisMatchStones { get; set; }
    }

    public class LotImportFailedResult
    {
        //public bool HasInvalidTops { get; set; }
        public int[] MissingStoneNumbers { get; set; }
        public IList<StoneDTO> StonesParseError { get; set; }
        public StoneValidationErrorResult StoneValidationError { get; set; }
    }
}