﻿using System.ComponentModel.DataAnnotations;

namespace SD.Rough.Average.Web.ViewModels.LotViewModel
{
    public class LotSearchViewModel : BaseViewModel
    {
        [Display(Name = "Weight")]
        public decimal? SubRoughWeight { get; set; }

        [Display(Name = "Piece count")]
        public int? SubRoughPieceCount { get; set; }

        public int? SubRoughTypeId { get; set; }
        public int? RoughSizeId { get; set; }
        public int? RoughColorShadeId { get; set; }

        [Display(Name = "Weight")]
        public decimal? LotWeight { get; set; }

        [Display(Name = "Piece count")]
        public int? LotPieceCount { get; set; }

        public int? AssignedTo { get; set; }

        [Display(Name = "Name")]
        public string Name { get; set; }

        public int? SarinActivityId { get; set; }
        public bool? IsTopsLot { get; set; }
        public int? ClarityId { get; set; }
    }
}