﻿using System;
using System.Web.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.LotViewModel
{
    public class LotViewModel : BaseViewModel
    {
        public LotViewModel() { }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Sub rough")]
        public int SubRoughId { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Sub rough")]
        public string SubRoughName { get; set; }

        public DateTime? SubRoughAssignedOn { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Range(IntPositiveMinValue, PieceMaxValue, ErrorMessage = NumberPositiveZeroErrorMessage)]
        [RegularExpression(DigitOneToMaxFourDigitRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Display(Name = "Piece(s)")]
        public int? PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), DecimalPositiveMinValue, WeightMaxValue, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Lot weight")]
        public decimal? Weight { get; set; }

        public bool IsLotBySize { get; set; }
        public int AssignedOperatorCount { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Sarin Activity")]
        public int SarinActivityId { get; set; }

        [Display(Name = "Lot Type")]
        public bool? IsTopsLot{ get; set; }

        public decimal MinPolishedDiameter { get; set; }

        [Display(Name = "Clarity")]
        public int? ClarityId { get; set; }

        [Display(Name = "Sign")]
        public string SizeSign { get; set; }

        [Display(Name = "Size")]
        public string SieveSize { get; set; }
        public int? SieveSizeId { get; set; }

        [Display(Name = "Assigned On")]
        [DisplayFormat(DataFormatString = DateTimeFormatString, ApplyFormatInEditMode = true)]
        public DateTime? AssignedOn { get; set; }

        [Display(Name = "Rough SubType")]
        public int? RoughCategoryId { get; set; }

        [Display(Name = "Color")]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        public int ColorShadeId { get; set; }

        [Display(Name = "Color Rate Version")]
        public int? ColorRateVersionId { get; set; }

        public bool IsDisplyRoughSubTypeDdl { get; set; }

        public bool IsRoughPlannning { get; set; }

        public List<SelectListItem> RoughSubTypes { get; set; } = new List<SelectListItem>();

        public IList<LotAssignViewModel> LotAssignDetail { get; set; }

        [Display(Name = "Custom Tops Configuration")]
        public bool? IsHaveCustomTopsConfiguration { get; set; }

        public IList<LotStoneTopsParameterViewModel> LotStoneTopsParameters { get; set; }
    }

    public class LotAssignViewModel
    {
        [Display(Name = "Assigned To")]
        public int? AssignedTo { get; set; }

        [Display(Name = "Assigned On")]
        [DisplayFormat(DataFormatString = DateTimeFormatString, ApplyFormatInEditMode = true)]
        public DateTime? AssignedOn { get; set; }
    }

    public class LotStoneTopsParameterViewModel
    {
        public int LotStoneTopsParameterId { get; set; }       

        [Display(Name = "Stone Number From")]
        [Range(IntPositiveMinValue, 1000000, ErrorMessage = NumberPositiveZeroErrorMessage)]
        public int? StoneNumberFrom { get; set; }

        [Display(Name = "Stone Number To")]
        [Range(IntPositiveMinValue, 1000000, ErrorMessage = NumberPositiveZeroErrorMessage)]
        public int? StoneNumberTo { get; set; }

        public IList<StoneTopsParameterViewModel> StoneTopsParameters { get; set; }
    }

    public class StoneTopsParameterViewModel
    {
        public int StoneTopsParameterId { get; set; }

        [Display(Name = "Clarity")]
        public int? ClarityId { get; set; }


        [Display(Name = "Tops Diameter")]
        [Range(typeof(decimal), LowerLimitPolishedDiameter, UpparLimitTopsPolishedDiameter, ErrorMessage = DecimalPositiveZeroErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        public decimal? TopsDiameter { get; set; }
    }
}