﻿namespace SD.Rough.Average.Web.ViewModels.Admin.MachineTypeViewModel
{
    using System.ComponentModel.DataAnnotations;

    public class MachineTypeSearchViewModel
    {
        #region Properties
        [Display(Name = "Name")]
        public string Name { get; set; }
        #endregion
    }
}