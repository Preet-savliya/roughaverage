﻿namespace SD.Rough.Average.Web.ViewModels.Admin.MachineTypeViewModel
{
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class MachineTypeViewModel
    {
        #region Properties
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(AlphaNumericWithSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }
        #endregion
    }
}