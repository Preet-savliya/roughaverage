﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughColorShadeViewModel
{
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class RoughColorShadeViewModel : BaseViewModel
    {
        #region Properties
        [RegularExpression(AlphaNumericWithHyphenPlusDotSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [RegularExpression(AlphaNumericWithHyphenPlusDotSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Group Name")]
        public string LotColorGroupName { get; set; }

        [RegularExpression(NumericRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Display Order")]
        public int? LotColorDisplayOrder { get; set; }

        [Display(Name = "Color")]
        public int? ColorId { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }
        #endregion
    }
}