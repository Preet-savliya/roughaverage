﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughColorShadeViewModel
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class RoughColorShadeSearchViewModel : BaseViewModel
    {
        [Display(Name = "Entry Status")]
        public bool? EntryStatus { get; set; } = true;
        public IList<SelectListItem> EntryStatusData { get; set; }


        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Group Name")]
        public string LotColorGroupName { get; set; }

        [Display(Name = "Color")]
        public int ColorId { get; set; }

        [Display(Name = "Display Order")]
        public string LotColorDisplayOrder { get; set; }
    }
}