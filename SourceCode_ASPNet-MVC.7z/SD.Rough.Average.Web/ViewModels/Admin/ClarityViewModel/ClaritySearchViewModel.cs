﻿namespace SD.Rough.Average.Web.ViewModels.Admin.ClarityViewModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class ClaritySearchViewModel
    {
        [Display(Name = "Entry Status")]
        public bool? EntryStatus { get; set; } = true;
        public IList<SelectListItem> EntryStatusData { get; set; }

        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Group Name")]
        public string GroupName { get; set; }

        [Display(Name = "Effective From")]
        [DisplayFormat(DataFormatString = DateFormatString)]
        public DateTime? EffectiveFromStartDate { get; set; }

        [Display(Name = "Effective To")]
        [DisplayFormat(DataFormatString = DateFormatString)]
        public DateTime? EffectiveFromEndDate { get; set; }
    }
}