﻿using System;
using System.ComponentModel.DataAnnotations;
// Static-References
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.Admin.ClarityViewModel
{
    public class ClarityViewModel
    {
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(AlphaNumericWithHyphenPlusDotSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Effective Date")]
        [DisplayFormat(DataFormatString = DateTimeFormatString, ApplyFormatInEditMode = true)]
        public DateTime EffectiveFrom { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(AlphaNumericWithHyphenPlusDotSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Group Name")]
        public string GroupName { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Display Order")]
        public int DisplayOrder { get; set; }
    }
}