﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughSizeSieveSizeViewModel
{
    using System.Web.Mvc;
    using System.Collections.Generic;

    public class RoughSizeSieveSizeSearchViewModel
    {
        public string Name { get; set; }

        public int? RoughSizeId { get; set; }

        public int? MinSieveSizeId { get; set; }
        public string MinSieveSize { get; set; }

        public int? MaxSieveSizeId { get; set; }
        public string MaxSieveSize { get; set; }

        public IList<SelectListItem> RoughSizes { get; set; }
    }
}