﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughSizeSieveSizeViewModel
{
    using System.Web.Mvc;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class RoughSizeSieveSizeViewModel
    {
        #region Properties
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(NumericWithHyphenPlusDotSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        public int? MinSieveSizeId { get; set; }
        [Display(Name = "Min Sieve Size")]
        public string MinSieveSize { get; set; }

        public int? MaxSieveSizeId { get; set; }
        [Display(Name = "Max Sieve Size")]
        public string MaxSieveSize { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Rough Size")]
        public int RoughSizeId { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(NumericRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Display Order")]
        public int? DisplayOrder { get; set; }

        public IList<SelectListItem> RoughSizes { get; set; }
        #endregion
    }
}