﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughTypeViewModel
{
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class RoughTypeViewModel
    {
        #region Properties
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(AlphaNumericWithHyphenPlusDotSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }
        #endregion
    }
}