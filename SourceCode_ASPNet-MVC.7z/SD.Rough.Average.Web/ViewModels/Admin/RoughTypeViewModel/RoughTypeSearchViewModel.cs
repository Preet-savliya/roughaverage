﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughTypeViewModel
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class RoughTypeSearchViewModel
    {
        [Display(Name = "Entry Status")]
        public bool? EntryStatus { get; set; } = true;
        public IList<SelectListItem> EntryStatusData { get; set; }


        [Display(Name = "Name")]
        public string Name { get; set; }
    }
}