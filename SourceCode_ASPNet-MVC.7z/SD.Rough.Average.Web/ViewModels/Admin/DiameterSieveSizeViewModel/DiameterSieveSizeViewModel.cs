﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Web;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.Admin.DiameterSieveSizeViewModel
{
    public class DiameterSieveSizeViewModel
    {
        #region Properties
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "File")]
        public HttpPostedFileBase File { get; set; }

        [Display(Name = "Effective From")]
        [DisplayFormat(DataFormatString = DateTimeFormatString, ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        public DateTime EffectiveFrom { get; set; }
        #endregion
    }

    public class DiameterSieveSizeXML
    {
        public int? SieveSizeFileImportId { get; set; }
        public int Id { get; set; }
        public decimal MinDiameter { get; set; }
        public decimal MaxDiameter { get; set; }
        public decimal? MinDiameterUpTo { get; set; }
        public string Name { get; set; }
        public string MinSize { get; set; }
    }
}