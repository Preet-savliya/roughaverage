﻿using System.Web.Mvc;
using System.Collections.Generic;

namespace SD.Rough.Average.Web.ViewModels.Admin.DiameterSieveSizeViewModel
{
    public class DiameterSieveSizeSearchViewModel
    {
        #region Properties
        public int SieveSizeFileImportId { get; set; }
        public int? SieveSizeId { get; set; }
        public decimal? Diameter { get; set; }
        public decimal? DiameterUpTo { get; set; }

        public IList<SelectListItem> SieveSizes { get; set; }

        // Navigation-Properties
        public DiameterSieveSizeXML DiameterSieveSizeViewModel { get; set; }
        #endregion

        #region Ctor
        public DiameterSieveSizeSearchViewModel()
        {
            DiameterSieveSizeViewModel = new DiameterSieveSizeXML();
        }
        #endregion

    }
}