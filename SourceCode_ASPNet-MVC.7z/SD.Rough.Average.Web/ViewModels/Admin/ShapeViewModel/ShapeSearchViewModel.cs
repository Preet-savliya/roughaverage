﻿namespace SD.Rough.Average.Web.ViewModels.Admin.ShapeViewModel
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class ShapeSearchViewModel
    {
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Entry Status")]
        public bool? EntryStatus { get; set; } = true;
        public IList<SelectListItem> EntryStatusData { get; set; }

        [Display(Name = "Measured By")]
        public string MeasurementBy { get; set; }
        public IList<SelectListItem> MeasurementParameters { get; set; }

    }
}