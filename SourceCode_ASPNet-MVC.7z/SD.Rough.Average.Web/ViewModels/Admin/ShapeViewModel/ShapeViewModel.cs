﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.Admin.ShapeViewModel
{
    public class ShapeViewModel
    {

        [RegularExpression(AlphaNumericWithSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        public IList<SelectListItem> MeasurementParameters { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Measured By")]
        public string MeasurementBy { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }
    }
}