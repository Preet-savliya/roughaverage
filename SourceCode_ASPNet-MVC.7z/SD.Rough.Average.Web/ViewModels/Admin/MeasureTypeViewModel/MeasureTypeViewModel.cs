﻿namespace SD.Rough.Average.Web.ViewModels.Admin.MeasureTypeViewModel
{
    using System.ComponentModel.DataAnnotations;
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class MeasureTypeViewModel
    {
        #region Properties
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(AlphaRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Code")]
        public string Code { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(AlphaNumericWithSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }
        
        [Display(Name ="Description")]
        public string Description { get; set; }
        #endregion
    }
}