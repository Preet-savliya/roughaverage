﻿namespace SD.Rough.Average.Web.ViewModels.Admin.MeasureTypeViewModel
{
    using System.ComponentModel.DataAnnotations;

    public class MeasureTypeSearchViewModel
    {
        #region Properties
        [Display(Name = "Code")]
        public string Code { get; set; }

        [Display(Name = "Name")]
        public string Name { get; set; }
        #endregion
    }
}