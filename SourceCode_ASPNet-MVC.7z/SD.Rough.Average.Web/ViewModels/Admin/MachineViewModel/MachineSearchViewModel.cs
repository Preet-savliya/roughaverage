﻿using System.ComponentModel.DataAnnotations;

namespace SD.Rough.Average.Web.ViewModels.Admin.MachineViewModel
{
    public class MachineSearchViewModel : MachineBaseViewModel
    {
        #region Properties
        [Display(Name = "Number")]
        public int? Number { get; set; }

        [Display(Name = "Machine Type")]
        public int? MachineTypeId { get; set; }
        #endregion
    }
}