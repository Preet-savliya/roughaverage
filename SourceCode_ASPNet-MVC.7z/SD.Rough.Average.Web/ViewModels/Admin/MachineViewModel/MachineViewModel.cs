﻿using SD.Rough.Average.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace SD.Rough.Average.Web.ViewModels.Admin.MachineViewModel
{
    public class MachineBaseViewModel
    {
        public IList<SelectListItem> MachineTypes { get; set; }
    }

    public class MachineViewModel : MachineBaseViewModel
    {
        public Machine Machine { get; set; }
    }
}