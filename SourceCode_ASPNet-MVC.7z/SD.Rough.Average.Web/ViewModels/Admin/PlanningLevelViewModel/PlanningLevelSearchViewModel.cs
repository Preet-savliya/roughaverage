﻿namespace SD.Rough.Average.Web.ViewModels.Admin.PlanningLevelViewModel
{
    using System.ComponentModel.DataAnnotations;

    public class PlanningLevelSearchViewModel
    {
        #region Properties
        [Display(Name = "Name")]
        public string Name { get; set; }
        #endregion
    }
}