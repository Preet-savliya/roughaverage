﻿using SD.Rough.Average.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace SD.Rough.Average.Web.ViewModels.Admin.EmployeeViewModel
{
    public class EmployeeBaseViewModel
    {
        public IList<SelectListItem> Desingations { get; set; }
    }

    public class EmployeeViewModel : EmployeeBaseViewModel
    {
        #region Properties
        public Employee Employee { get; set; }
        #endregion
    }
}


//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.Web.Mvc;
//using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

//namespace SD.Rough.Average.Web.ViewModels.Admin.EmployeeViewModel
//{
//    public class EmployeeBaseViewModel
//    {
//        public IList<SelectListItem> Desingations { get; set; }
//    }

//    public class EmployeeViewModel : EmployeeBaseViewModel
//    {
//        #region Properties
//        [Required(ErrorMessage = RequiredValidationErrorMessage)]
//        [Display(Name = "First Name")]
//        public string FirstName { get; set; }

//        [Required(ErrorMessage = RequiredValidationErrorMessage)]
//        [Display(Name = "Last Name")]
//        public string LastName { get; set; }

//        [Required(ErrorMessage = RequiredValidationErrorMessage)]
//        [Display(Name = "Designation")]
//        public int DesignationId { get; set; }

//        #endregion
//    }
//}