﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace SD.Rough.Average.Web.ViewModels.Admin.EmployeeViewModel
{
    public class EmployeeSearchViewModel : EmployeeBaseViewModel
    {
        [Display(Name = "Entry Status")]
        public bool? EntryStatus { get; set; } = true;
        public IList<SelectListItem> EntryStatusData { get; set; }

        [Display(Name = "Employee NO")]
        public string EmployeeNo { get; set; }

        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "Designation")]
        public int? DesignationId { get; set; }
    }
}