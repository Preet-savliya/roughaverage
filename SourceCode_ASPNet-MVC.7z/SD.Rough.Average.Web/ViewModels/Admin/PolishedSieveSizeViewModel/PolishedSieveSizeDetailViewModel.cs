﻿using System;
using static SD.Rough.Average.Core.AppGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.Admin.PolishedSieveSizeViewModel
{
    public class PolishedSieveSizeDetailViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public DateTime EffectiveFrom { get; set; }

        public string MinSieveSize { get; set; }

        public string MaxSieveSize { get; set; }

        public string ParentSize { get; set; }

        public bool IsPointerApply { get; set; }

        public bool IsActive { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedOn { get; set; }

        public string ModifiedBy { get; set; }

        public DateTime? ModifiedOn { get; set; }

        public string FormattedEffectiveDate => EffectiveFrom.ToString(DateFormat);
        public string CreatedDate => CreatedOn.ToString(DateTimeFormat);
        public string ModifiedDate => ModifiedOn?.ToString(DateTimeFormat);
    }
}