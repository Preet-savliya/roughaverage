﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughSizePolishedSieveSizeViewModel
{
    using System;
    using System.Web.Mvc;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class RoughSizePolishedSieveSizeViewModel
    {
        public int RoughSizeId { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Polished Sieve Size")]
        public int PolishedSieveSizeId { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [DisplayFormat(DataFormatString = DateFormatString, ApplyFormatInEditMode = true)]
        [Display(Name = "Effective From")]
        public DateTime EffectiveFrom { get; set; }

        public IList<SelectListItem> PloishedSieveSizes { get; set; }
    }
}