﻿namespace SD.Rough.Average.Web.ViewModels.Admin.LossTypeViewModel
{
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class LossTypeViewModel
    {
        [RegularExpression(AlphaRegEx, ErrorMessage = InValidErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Code")]
        public string Code { get; set; }

        [RegularExpression(AlphaNumericWithSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Type")]
        public string Type { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }
    }
}