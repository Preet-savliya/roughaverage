﻿namespace SD.Rough.Average.Web.ViewModels.Admin.LossTypeViewModel
{
    using System.ComponentModel.DataAnnotations;
   
    public class LossTypeSearchViewModel
    {
        #region Properties
        [Display(Name = "Code")]
        public string Code { get; set; }

        [Display(Name = "Type")]
        public string Type { get; set; }
        #endregion
    }
}