﻿namespace SD.Rough.Average.Web.ViewModels.Admin.ColorRateVersionViewModel
{
    using System;
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class ColorRateVersionViewModel : BaseViewModel
    {
        #region Properties
        [RegularExpression(AlphaNumericRegEx, ErrorMessage = InValidErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Color")]
        public int ColorId { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [DisplayFormat(DataFormatString = DateFormatString, ApplyFormatInEditMode = true)]
        [Display(Name = "Effective From")]
        public DateTime EffectiveFrom { get; set; }
        #endregion
    }
}