﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughCategoryRoughTypeViewModel
{
    using System.Web.Mvc;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class RoughCategoryRoughTypeViewModel
    {
        public int RoughTypeId { get; set; }

        [Display(Name = "Rough Category")]
        public int RoughCategoryId { get; set; }

        public bool? IsBehaveSeparately { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(NumericRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Display Order")]
        public int? DisplayOrder { get; set; }

        public IList<SelectListItem> RoughCategories { get; set; }
    }
}