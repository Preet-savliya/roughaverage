﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RateViewModel
{
    public class RateElementContent
    {
        public const string Properties = "Properties";
        public const string Property = "Property";
        public const string Item = "Item";
        public const string Name = "Name";
        public const string Id = "ID";
        public const string Shape = "Shape";
        public const string Range = "Range";
        public const string LowerBound = "LowerBound";
        public const string PriceUnits = "PriceUnits";
        public const string Prices = "Prices";
        public const string Clarity = "Clarity";
        public const string Color = "Color";
        public const string PriceUnitsSeparator = "#";
    }
}