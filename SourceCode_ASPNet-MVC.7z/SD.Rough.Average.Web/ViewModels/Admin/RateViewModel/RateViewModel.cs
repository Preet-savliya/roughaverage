﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RateViewModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web;
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class RateViewModel
    {
        public int ColorRateVersionId { get; set; }
        public bool IsFileImported { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "File")]
        public HttpPostedFileBase File { get; set; }
        public DateTime EffectiveFrom { get; set; }
    }

    public class ColorInfo
    {
        public int ColorRateVersionId { get; set; }
        public string Name { get; set; }
    }

    public class ClarityInfo
    {
        public int ClarityIdInFile { get; set; }
        public int ClarityId { get; set; }
        public string Name { get; set; }
    }

    public class ClarityRate
    {
        public int ClarityId { get; set; }
        public decimal UnitPrice { get; set; }

    }

    public class DiameterClarityRate
    {
        public decimal Diameter { get; set; }
        public IList<ClarityRate> ClarityRates { get; set; }
    }

    public class RateXML
    {
        public decimal Diameter { get; set; }

        public IList<PriceUnitDetail> PriceUnitDetails { get; set; }
    }

    public class PriceUnitDetail
    {
        public int ShapeId { get; set; }
        public int ColorRateVersionId { get; set; }
        public int ClarityId { get; set; }
        public decimal UnitPrice { get; set; }
    }

    public class RateDetail
    {
        public int ShapeId { get; set; }
        public int ColorId { get; set; }
        public int ClarityId { get; set; }
        public decimal Diameter { get; set; }
        public decimal UnitPrice { get; set; }
    }

    public static class DiameterClarityRateExtensions
    {
        public static IEnumerable<RateDetail> ToRateDetail(this List<DiameterClarityRate> diameterClarityRates, int colorId, int shapeId)
        {
            foreach (var diameterClarityRate in diameterClarityRates)
            {
                foreach (var clarityRate in diameterClarityRate.ClarityRates)
                {
                    yield return new RateDetail
                    {
                        ShapeId = shapeId,
                        ColorId = colorId,
                        ClarityId = clarityRate.ClarityId,
                        Diameter = diameterClarityRate.Diameter,
                        UnitPrice = clarityRate.UnitPrice
                    };
                }
            }
        }
    }
}