﻿using System;
using System.Web.Mvc;
using System.Collections.Generic;

namespace SD.Rough.Average.Web.ViewModels.Admin.RateViewModel
{
    public class RateSearchViewModel
    {
        public int ColorId { get; set; }
        public int ColorRateVersionId { get; set; }
        public int ShapeId { get; set; }
        public int? ClarityId { get; set; }
        public DateTime EffectiveFrom { get; set; }
        public decimal? Diameter { get; set; }

        public IList<SelectListItem> Shapes { get; set; }
        public IList<SelectListItem> Clarities { get; set; }

        // Navigation-Properties
        public RateViewModel RateViewModel { get; set; }

        public RateSearchViewModel()
        {
            RateViewModel = new RateViewModel();
        }
    }
}