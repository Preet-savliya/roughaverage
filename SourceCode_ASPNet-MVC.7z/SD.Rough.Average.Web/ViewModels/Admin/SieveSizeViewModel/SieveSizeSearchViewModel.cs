﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace SD.Rough.Average.Web.ViewModels.Admin.SieveSizeViewModel
{
    public class SieveSizeSearchViewModel
    {
        [Display(Name = "Name")]
        public string Name { get; set; }


        [Display(Name = "Entry Status")]
        public bool? EntryStatus { get; set; } = true;
        public IList<SelectListItem> EntryStatusData { get; set; }
    }
}