﻿using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.Admin.SieveSizeViewModel
{
    public class SieveSizeViewModel
    {
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = InValidErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }
       
    }
}