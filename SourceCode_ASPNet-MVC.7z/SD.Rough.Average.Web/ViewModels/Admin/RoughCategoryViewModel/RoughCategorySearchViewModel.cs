﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughCategoryViewModel
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Web.Mvc;

    public class RoughCategorySearchViewModel
    {
        [Display(Name = "Entry Status")]
        public bool? EntryStatus { get; set; } = true;
        public IList<SelectListItem> EntryStatusData { get; set; }


        [Display(Name = "Name")]
        public string Name { get; set; }
    }
}