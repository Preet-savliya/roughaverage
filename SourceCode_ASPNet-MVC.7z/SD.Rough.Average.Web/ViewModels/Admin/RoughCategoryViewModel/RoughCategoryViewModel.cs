﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughCategoryViewModel
{
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class RoughCategoryViewModel
    {
        #region Properties
        [RegularExpression(AlphaNumericWithHyphenPlusDotSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }
        #endregion
    }
}