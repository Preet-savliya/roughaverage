﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughSizeViewModel
{
    using System.ComponentModel.DataAnnotations;
    // Static-References
    using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

    public class RoughSizeViewModel
    {

        #region Properties
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(NumericWithHyphenPlusSlashRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(NumericWithHyphenPlusSpaceRegEx, ErrorMessage = InValidErrorMessage)]
        [Display(Name = "Display Name")]
        public string DisplayName { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(NumericRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Display(Name = "Display Order")]
        public int DisplayOrder { get; set; }

        [Display(Name = "Description")]
        public string Description { get; set; }
        #endregion
    }
}