﻿namespace SD.Rough.Average.Web.ViewModels.Admin.RoughSizeViewModel
{
    using System.ComponentModel.DataAnnotations;

    public class RoughSizeSearchViewModel
    {
        #region Properties
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Display(Name = "Display Name")]
        public string DisplayName { get; set; }
        #endregion
    }
}