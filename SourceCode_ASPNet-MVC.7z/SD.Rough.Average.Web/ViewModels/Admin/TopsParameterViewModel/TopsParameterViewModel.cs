﻿using System;
using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.Admin.TopsParameterViewModel
{
    public class TopsParameterViewModel
    {
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Effective Date")]
        [DisplayFormat(DataFormatString = DateTimeFormatString, ApplyFormatInEditMode = true)]
        public DateTime? EffectiveFrom { get; set; }

        public int? MinSieveSizeId { get; set; }
        [Display(Name = "Min Sieve Size")]
        public string MinSieveSize { get; set; }

        public int? MaxSieveSizeId { get; set; }
        [Display(Name = "Max Sieve Size")]
        public string MaxSieveSize { get; set; }
    }
}