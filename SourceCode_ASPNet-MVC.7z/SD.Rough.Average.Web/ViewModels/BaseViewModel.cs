﻿using System.Web.Mvc;
using System.Collections.Generic;

namespace SD.Rough.Average.Web.ViewModels
{
    public class BaseViewModel
    {
        #region Properties
        public IList<SelectListItem> RoughTypes { get; set; }
        public IList<SelectListItem> SubRoughTypes { get; set; }
        public IList<SelectListItem> SubRoughs { get; set; }
        public IList<SelectListItem> Lots { get; set; }
        public IEnumerable<SelectListItem> ActionTypes { get; set; }
        public IList<SelectListItem> Managers { get; set; }
        public IList<SelectListItem> Operators { get; set; }
        public IList<SelectListItem> RoughSizes { get; set; }
        public IList<SelectListItem> Sizes { get; set; }
        public IList<SelectListItem> RoughColorShades { get; set; }
        public IList<SelectListItem> LotColorShades { get; set; }
        public IList<SelectListItem> SarinActivities { get; set; }
        public IList<SelectListItem> Clarities { get; set; }
        public IList<SelectListItem> Colors { get; set; }
        public IList<SelectListItem> ColorRateVersions { get; set; } = new List<SelectListItem>();
        public IList<SelectListItem> LossTypes { get; set; }
        public IList<SelectListItem> SieveSizeFiles { get; set; } = new List<SelectListItem>();
        public IList<SelectListItem> SieveSizeFileActions { get; set; }
        public List<SelectListItem> SizeSymbols { get; set; } = new List<SelectListItem>();

        //public IList<SelectListItem> Roughs { get; set; }
        #endregion
    }
}