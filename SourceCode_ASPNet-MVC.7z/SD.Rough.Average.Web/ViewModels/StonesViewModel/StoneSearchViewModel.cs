﻿using System.ComponentModel.DataAnnotations;

namespace SD.Rough.Average.Web.ViewModels.StonesViewModel
{
    public class StoneSearchViewModel : BaseViewModel
    {
        #region Properties
        public int? SubRoughId { get; set; }
        public int? LotId { get; set; }

        [Display(Name = "Stone Number")]
        public string StoneNumber { get; set; }
        #endregion
    }
}