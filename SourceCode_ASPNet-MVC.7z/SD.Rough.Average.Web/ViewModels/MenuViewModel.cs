﻿using SD.Rough.Average.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SD.Rough.Average.Web.ViewModels
{
    public class MenuViewModel
    {
        #region Properties
        public IList<Menu> Menus { get; set; }
        public int? SelectedTopMenuId { get; set; }
        public int? SelectedLeftMenuId { get; set; }
        #endregion
    }
}