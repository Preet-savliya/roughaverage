﻿namespace SD.Rough.Average.Web.ViewModels.LotSizeReportViewModel
{
    using System.Collections.Generic;
    using SD.Rough.Average.Models;

    public class LotSizeColorClarityGroupViewModel
    {
        #region Ctor
        public LotSizeColorClarityGroupViewModel()
        {
            LotGroups = new List<LotSizeColorClarityGroupModel>();
            RoughPlanningLotGroups = new List<LotSizeColorClarityGroupModel>();
        }
        #endregion

        #region Properties
        public List<LotSizeColorClarityGroupModel> LotGroups { get; set; }
        public List<LotSizeColorClarityGroupModel> RoughPlanningLotGroups { get; set; }
        #endregion
    }
    public class LotSizeColorClarityGroupModel
    {
        #region Properties
        public string GroupName { get; set; }
        public IList<Lot> LotGroup { get; set; }
        #endregion
    }
}