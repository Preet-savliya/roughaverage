﻿using SD.Rough.Average.Core;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.LotSizeReportViewModel
{
    public class LotSizeReportViewModel
    {
        public IList<LotSizeStoneSummary> LotSummaries { get; set; }

        public string SarinActivity { get; set; }
        public bool IsMakeablePlanning { get; set; }
        public string PrintAction { get; set; }

        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
    }

    public class LotSizeStoneSummary
    {
        public LotSizeStoneSummary()
        {
            SizeSummaries = new List<SizeStoneSummary>();
        }

        public string Name { get; set; }
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        public string ColorShade { get; set; }
        public string Clarity { get; set; }

        public IList<SizeStoneSummary> SizeSummaries { get; set; }
        public SizeStoneReportSummary ReportSummary { get; set; }
    }

    public class SizeStoneSummary
    {
        #region Properties
        public string Name { get; set; }
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal RoughWeight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Percentage { get; set; }

        public decimal Pointer { get; set; }

        #endregion
    }

    public class SizeStoneReportSummary
    {
        #region Properties
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Average { get; set; }

        public decimal? Pointer { get; set; }

        #endregion
    }
}