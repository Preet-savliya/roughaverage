﻿using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Core;
using SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel;

namespace SD.Rough.Average.Web.ViewModels.LotSizeReportViewModel
{
    public class LotSizeColorViewModel : BaseViewModel
    {
        public LotSizeColorViewModel()
        {
            SizeAverageViewModel = new List<SizeAverageViewModel>();
        }

        public int SubRoughId { get; set; }
        public string SarinActivity { get; set; }
        public bool IsCombineReport { get; set; } = true;
        public bool IsMultipleColorAndClarity { get; set; }
        public bool IsMakeablePlanning { get; set; }
        public string PrintAction { get; set; }
        public SubRough SubRough { get; set; }
        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
        public IList<SizeAverageViewModel> SizeAverageViewModel { get; set; }
    }
}