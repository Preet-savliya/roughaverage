﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using SD.Rough.Average.Core;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel
{
    public class SubRoughAverageViewModel : BaseViewModel
    {
        public SubRoughAverageViewModel()
        {
            RoughSubTypesSubRoughAverage = new List<SubRoughAverageDetail>();
        }

        public IList<SubRoughAverageDetail> RoughSubTypesSubRoughAverage { get; set; }
        public SubRoughAverageSummary TotalSummary { get; set; }
        public ReportSummary WhitenerSummary { get; set; }
        public string SarinActivity { get; set; }
        public bool IsMakeablePlanning { get; set; }
        public bool IsDisplayTotalSummary { get; set; }
        public bool IsDisplayRate { get; set; }
        public decimal? MakeableWeight { get; set; }
        public string PrintAction { get; set; }
    }

    public class SubRoughAverageSummary : BaseViewModel
    {
        public ReportSummary RoughSummary { get; set; }
        public ReportSummary MfgPolishedSummary { get; set; }
        public ReportSummary MfgRoughSummary { get; set; }
        public ReportSummary MfgPolishedRoughSummary { get; set; }
        public ReportSummary TopsRoughSummary { get; set; }
        public ReportSummary TopsPolishedSummary { get; set; }
        public ReportSummary TopsPolishedRoughSummary { get; set; }
        public RateSummary RateSummary { get; set; }
        public IList<ReportSummary> TotalSizeSummaries { get; set; } = new List<ReportSummary>();
    }

    public class SubRoughAverageDetail : SubRoughAverageSummary
    {
        public SubRoughAverageDetail()
        {
            SizeSummaries = new List<ReportSummary>();
            SizeNames = new List<string>();
        }

        public IList<ReportSummary> SizeSummaries { get; set; }
        public IList<LotStoneSummary> LotSummary { get; set; }
        public List<string> SizeNames { get; set; }
        public int RoughCategoryCount { get; set; }
        public string RoughCategoryName { get; set; }
        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
        public int PendingLotImportCount { get; set; }
        public bool IsTopsTotalPolWeightGreaterThanZero { get; set; }
    }

    public class LotStoneSummary
    {
        public LotStoneSummary()
        {
            StoneSummaryData = new List<StoneSummary>();
        }

        public StoneSummary RoughStoneSummary { get; set; }
        public StoneSummary MfgPolStoneSummary { get; set; }
        public StoneSummary MfgRoughStoneSummary { get; set; }
        public StoneSummary TopsRoughStoneSummary { get; set; }
        public StoneSummary TopsPolishedStoneSummary { get; set; }
        public RateSummary StonesRateSummary { get; set; }

        public int Id { get; set; }
        public string Name { get; set; }
        public string ClarityName { get; set; }
        public string ColorShadeName { get; set; }
        public string RoughCategoryName { get; set; }
        public IList<StoneSummary> StoneSummaryData { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Percentage { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal TopsPercentage { get; set; }
    }

    public class StoneSummary
    {
        public string Name { get; set; }

        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal RoughWeight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Percentage { get; set; }

        public decimal Pointer { get; set; }
    }

    public class RateSummary
    {
        [DisplayFormat(DataFormatString = NumberFormatString)]
        public int Rate { get; set; }
    }

    public class ReportSummary
    {
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        //[DisplayFormat(DataFormatString = DecimalFormatString)]
        //public decimal RoughWeight { get; set; }
        public string Name { get; set; }
        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Average { get; set; }
        public decimal? Pointer { get; set; }
    }
}