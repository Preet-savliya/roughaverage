﻿using System.Web.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SD.Rough.Average.Models;
using SD.Rough.Average.Core;
// Static-References
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel
{
    public class SizeClarityAverageViewModel : SizeClarityStoneSummary
    {
        #region Ctor
        public SizeClarityAverageViewModel()
        {
            SizeClarityStoneDetail = new List<SizeClarityStoneDetail>();
            ClarityReportsSummary = new List<ClarityReportsSummary>();
            SizeReportsSummary = new List<SizeReportsSummary>();
        }
        #endregion

        #region Properties
        public int SubRoughId { get; set; }
        public string SarinActivity { get; set; }
        public string LotGroup { get; set; }
        public IList<SelectListItem> LotGroups { get; set; }
        public IList<SizeClarityStoneDetail> SizeClarityStoneDetail { get; set; }
        public IList<ClarityReportsSummary> ClarityReportsSummary { get; set; }
        public IList<SizeReportsSummary> SizeReportsSummary { get; set; }
        public string SizeClarityData { get; set; }
        public string PrintAction { get; set; }
        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
        #endregion
    }

    public abstract class SizeClarityStoneSummary : BaseViewModel
    {
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }
        public int Rate { get; set; }

        [DisplayFormat(DataFormatString = TwoDecimalFormatString)]
        public decimal Average { get; set; }
    }

    public class SizeClarityStoneDetail : SizeClarityStoneSummary
    {
        #region Properties
        public int? ClarityId { get; set; }
        public Clarity Clarity { get; set; }
        public string GroupName { get; set; }
        public int? PolishedSieveSizeId { get; set; }
        public PolishedSieveSize PolishedSieveSize { get; set; }
        #endregion
    }

    public class ClarityReportsSummary : SizeClarityStoneSummary
    {
        #region Properties
        public Clarity Clarity { get; set; }
        #endregion
    }

    public class SizeReportsSummary : SizeClarityStoneSummary
    {
        #region Properties
        public PolishedSieveSize PolishedSieveSize { get; set; }
        #endregion
    }
}