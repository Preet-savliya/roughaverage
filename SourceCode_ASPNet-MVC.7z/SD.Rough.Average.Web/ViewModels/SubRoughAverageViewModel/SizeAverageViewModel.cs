﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using SD.Rough.Average.Core;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel
{
    public class SizeAverageViewModel : BaseViewModel
    {
        public SizeAverageViewModel()
        {
            StoneSizeSummary = new List<StoneSizeSummary>();
        }

        public string SarinActivity { get; set; }
        public string PrintAction { get; set; }
        public IList<StoneSizeSummary> StoneSizeSummary { get; set; }
        public SizeReportSummary SizeRoughSummary { get; set; }
        public SizeReportSummary SizePolishedSummary { get; set; }
        public SizeReportSummary SizeAverageSummary { get; set; }
        public LotDetail LotDetailSummary { get; set; }

        public SubRoughLossDamagedSummaryViewModel SubRoughAverageSummary { get; set; }
        public SubRoughAverageMakeableSummaryViewModel SubRoughAverageWithClaritySummary { get; set; }
        public SubRoughSizeSummaryViewModel SubRoughSizeSummary { get; set; }
        public SubRoughTopsSummaryViewModel SubRoughTopsSummary { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Percentage { get; set; }
        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }

        public bool IsSizeExists { get; set; }
        public bool IsPolishedStoneExists { get; set; }
    }

    public class StoneSizeSummary
    {
        public StoneSizeSummary()
        {
            ChildSizeSummary = new List<StoneSizeSummary>();
        }

        public int SizeId { get; set; }
        public string Size { get; set; }
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal PolishedWeight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal RoughWeight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal RoughCutApprox { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal PolishedApprox { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal PolishedCutApprox { get; set; }
        public decimal? Pointer { get; set; }
        public decimal? MinSize { get; set; }

        public decimal RoughPlanningPolishedWeight { get; set; }
        public int RoughPlanningRate { get; set; }
        public int Rate { get; set; }
        public int RateDifference => Rate - RoughPlanningRate;
        public IList<StoneSizeSummary> ChildSizeSummary { get; set; }
    }

    public class SizeReportSummary
    {
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal RoughPlanningWeight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Average { get; set; }

        public int RoughPlanningRate { get; set; }
        public int Rate { get; set; }
        public int RateDifference => Rate - RoughPlanningRate;

        public int RoughTotalAverage => RoughPlanningWeight == 0 
            ? 0 : Convert.ToInt32(Math.Round(RoughPlanningRate / RoughPlanningWeight, MidpointRounding.AwayFromZero));
        public int TotalAverage => Weight == 0 
            ? 0 : Convert.ToInt32(Math.Round(Rate / Weight, MidpointRounding.AwayFromZero));
        public int TotalAverageDiff => TotalAverage - RoughTotalAverage;
    }

    public class LotDetail
    {
        public string Name { get; set; }
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }
        public string ColorOrRoughSubType { get; set; }
        public string Clarity { get; set; }
        public int RoughSubTypeCount { get; set; }
    }
}