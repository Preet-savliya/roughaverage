﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using SD.Rough.Average.Core;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel
{
    public class ClarityAverageViewModel : BaseViewModel
    {
        #region Ctor
        public ClarityAverageViewModel()
        {
            ClaritySummary = new List<ClarityStoneSummary>();
        }
        #endregion

        #region Properties
        public IList<ClarityStoneSummary> ClaritySummary { get; set; }
        public ClarityReportSummary RoughSummary { get; set; }
        public ClarityReportSummary PolishedSummary { get; set; }
        public ClarityReportSummary AverageSummary { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Percentage { get; set; }
        public string PrintAction { get; set; }
        public string SarinActivity { get; set; }
        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
        #endregion
    }

    public class ClarityStoneSummary
    {
        #region Properties
        public string Name { get; set; }
        public string GroupName { get; set; }
        public StoneDetail RoughStoneSummary { get; set; }
        public StoneDetail PolishedStoneSummary { get; set; }
        #endregion
    }

    public class StoneDetail
    {
        #region Properties
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal PolishedApprox { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal PolishedCutApprox { get; set; }
        #endregion
    }

    public class ClarityReportSummary
    {
        #region Properties
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Average { get; set; }

        #endregion
    }
}