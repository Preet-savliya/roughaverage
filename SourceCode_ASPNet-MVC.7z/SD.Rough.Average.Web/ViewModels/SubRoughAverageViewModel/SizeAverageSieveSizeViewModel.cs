﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

using SD.Rough.Average.Core;

using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel
{
    public class SizeAverageSieveSizeViewModel : BaseViewModel
    {
        public SizeAverageSieveSizeViewModel()
        {
            StoneSizeSummary = new List<SieveSizeStoneSizeSummary>();
        }

        public string SarinActivity { get; set; }
        public string PrintAction { get; set; }
        public IList<SieveSizeStoneSizeSummary> StoneSizeSummary { get; set; }
        public SieveSizeReportSummary SizeRoughSummary { get; set; }
        public SieveSizeReportSummary SizePolishedSummary { get; set; }
        public SieveSizeReportSummary SizeAverageSummary { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Percentage { get; set; }
        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
    }

    public class SieveSizeStoneSizeSummary
    {
        public SieveSizeStoneSizeSummary()
        {
            ChildSizeSummary = new List<SieveSizeStoneSizeSummary>();
        }

        public string Size { get; set; }
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal PolishedWeight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal RoughWeight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal RoughCutApprox { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal PolishedApprox { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal PolishedCutApprox { get; set; }
        public decimal? Pointer { get; set; }
        public decimal? MinSize { get; set; }

        public decimal RoughPlanningPolishedWeight { get; set; }
        public int RoughPlanningRate { get; set; }        
        public int Rate { get; set; }
        public int RateDifference => Rate - RoughPlanningRate;
        public IList<SieveSizeStoneSizeSummary> ChildSizeSummary { get; set; }
    }
    public class SieveSizeReportSummary
    {
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal RoughPlanningWeight { get; set; }


        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Average { get; set; }

        public int RoughPlanningRate { get; set; }
        public int Rate { get; set; }
        public int RateDifference => Rate - RoughPlanningRate;

        public int RoughTotalAverage => RoughPlanningWeight == 0
            ? 0 : Convert.ToInt32(Math.Round(RoughPlanningRate / RoughPlanningWeight, MidpointRounding.AwayFromZero));
        public int TotalAverage => Weight == 0
            ? 0 : Convert.ToInt32(Math.Round(Rate / Weight, MidpointRounding.AwayFromZero));
        public int TotalAverageDiff => TotalAverage - RoughTotalAverage;
    }
}