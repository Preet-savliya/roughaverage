﻿using System.Collections.Generic;
using SD.Rough.Average.Core;

namespace SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel
{
    public class PolishedStoneCountSummaryViewModel
    {
        public IList<PolishedStoneCountSummary> PolishedStoneCountSummary { get; set; }
        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
    }

    public class PolishedStoneCountSummary
    {
        public int PolishedStoneCountKey { get; set; }
        public int StoneCount { get; set; }
    }
}