﻿using System.ComponentModel.DataAnnotations;

namespace SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel
{
    using System.Collections.Generic;
    using SD.Rough.Average.Core;
    // Static-References
    using static Core.Validation.ValidationGlobalSettings;

    public class SubRoughAverageSummaryViewModel
    {
        #region Ctor
        public SubRoughAverageSummaryViewModel()
        {
            SubRoughSizeSummaries = new List<SubRoughSizeSummaryViewModel>();
        }
        #endregion
        public SubRoughLossDamagedSummaryViewModel SubRoughLossDamagedSummary { get; set; }
        public SubRoughAverageMakeableSummaryViewModel SubRoughAverageMakeableSummary { get; set; }
        public IList<SubRoughSizeSummaryViewModel> SubRoughSizeSummaries { get; set; }
        public SubRoughTopsSummaryViewModel SubRoughTopsSummary { get; set; }

        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
    }

    public class SubRoughLossDamagedSummaryViewModel
    {
        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal SubRoughWeight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal GalaxyLossWeight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal LaserLossWeight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal LaserLossPercentage { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal LaserDamagedWeight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal TopsWeight { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal TopsPercentage { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal TotalWeight { get; set; }
    }

    public class SubRoughAverageMakeableSummaryViewModel
    {
        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }

        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Approx { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal VVS { get; set; }

        public string Variation { get; set; }
    }

    public class SubRoughSizeSummaryViewModel
    {
        #region Ctor
        public SubRoughSizeSummaryViewModel()
        {
            RoughPlanning = new SizeStoneSummary();
            MakeablePlanning = new SizeStoneSummary();
        }
        #endregion
        public string Name { get; set; }
        public SizeStoneSummary RoughPlanning { get; set; }
        public SizeStoneSummary MakeablePlanning { get; set; }
    }

    public class SubRoughTopsSummaryViewModel
    {
        public SizeStoneSummary RoughPlanning { get; set; }
        public SizeStoneSummary MakeablePlanning { get; set; }
    }

    public class SizeStoneSummary
    {
        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }
        public int PieceCount { get; set; }

        public decimal Pointer { get; set; }

        [DisplayFormat(DataFormatString = PercentageDisplayString)]
        public decimal Percentage { get; set; }
    }
}