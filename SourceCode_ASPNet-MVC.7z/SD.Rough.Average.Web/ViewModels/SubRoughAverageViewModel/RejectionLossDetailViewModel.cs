﻿using SD.Rough.Average.Core;
using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Web.ViewModels.SubRoughAverageViewModel
{
    public class RejectionLossDetailViewModel
    {
        public RejectionLoss Rejection { get; set; }
        public RejectionLoss Loss { get; set; }
        public RejectionLoss Damaged { get; set; }
        public ProgressStatus LotStatus { get; set; }
        public ProgressStatus LotImportStatus { get; set; }
    }

    public class RejectionLoss
    {
        public string Type { get; set; }
        public int PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString)]
        public decimal Weight { get; set; }
        public string Description { get; set; }
    }
}