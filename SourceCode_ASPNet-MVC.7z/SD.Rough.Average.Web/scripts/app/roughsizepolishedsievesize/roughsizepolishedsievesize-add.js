﻿$(document).ready(function () {
    $('#PolishedSieveSizeId').focus(function () {
        var isValid = true;

        var effectiveFrom = $("#EffectiveFrom").val();
        if (effectiveFrom === '') {
            $('#EffectiveFrom').addClass('control-empty');
            $('#effectiveDateInputError').html('Effective Date is required');
            isValid = false;
        }
        else {
            $('#EffectiveFrom').removeClass('control-empty');
            $('#effectiveDateInputError').html('');
            isValid = true;

            //Autocomplete of Name
            sendRequest("GET", appendURL("PolishedSieveSize/GetPolishedSieveSizeByEffectiveFrom"),
                {
                    effectiveFrom: $('#EffectiveFrom').val(),
                    entryStatus: 'Active'
                }, "application/json; charset=utf-8", "json", bindPolishedSieveSizeListData);
        }
    });

});

function bindPolishedSieveSizeListData(data) {
    var ddlPolishedSieveSize = $('#PolishedSieveSizeId');

    ddlPolishedSieveSize.empty();
    $('<option>', { value: "", text: "Select" }).html("Select").appendTo(ddlPolishedSieveSize);

    if (data === undefined) {
        return;
    }

    if (data === '') {
        return;
    }

    $.each(data, function (i, datas) {
        $('<option>', { value: datas.Value, text: datas.Text }).html(datas.Text).appendTo(ddlPolishedSieveSize);
    });
}