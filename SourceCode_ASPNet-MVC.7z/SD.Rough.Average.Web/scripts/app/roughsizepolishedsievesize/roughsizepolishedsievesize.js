﻿$(document).ready(function () {
    setControlVisibility(false);
    getRoughSizePolishedSieveSizeData();
});

function getRoughSizePolishedSieveSizeData(sortColumn, sortDirection) {

    sendRequest("GET", appendURL("RoughSizePolishedSieveSize/GetRoughSizePolishedSieveSizeDetails"),
        {
            roughSizeId: $('#Id').val()
        }, "application/json; charset=utf-8", "json", bindRoughSizePolishedSieveSizeData);
}

function bindRoughSizePolishedSieveSizeData(data) {
    if (data !== null && data !== "Error") {
        var roughSizeId = $('#Id').val();
        var dt = $('#roughSizePolishedSieveSizeTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '40vh',
            "columnDefs": [
                {
                    targets: [0, 1, 3, 5],
                    className: 'dt-body-right'
                },
                {
                    targets: [6],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.roughSizepolishedSieveSizeDetails,
            "aoColumns": [
                {
                    "mData": "PolishedSieveSize"
                },
                {
                    "mData": "EffectiveFrom",
                    "render": function (id, type, full, meta) {
                        return full.EffectiveFrom !== null ? full.EffectiveFrom : "-";
                    }
                },
                {
                    "mData": "CreatedBy",
                    "render": function (id, type, full, meta) {
                        return full.CreatedBy !== null ? full.CreatedBy : "-";
                    }
                },
                {
                    "mData": "CreatedOn",
                    "render": function (id, type, full, meta) {
                        return full.CreatedOn !== null ? full.CreatedOn : "-";
                    }
                },
                {
                    "mData": "ModifiedBy",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedBy !== null ? full.ModifiedBy : "-";
                    }
                },
                {
                    "mData": "ModifiedOn",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedOn !== null ? full.ModifiedOn : "-";
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="../RoughSizePolishedSieveSize/Delete?roughSizePolishedSieveSizeId=' + full.Id + '&roughSizeId=' + roughSizeId + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate") + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            (deleteActivate === "Delete" ? '<span class="glyphicon glyphicon-trash"></span></a>' : '<span class="glyphicon glyphicon-ok"></span>') +
                            '</a>';
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}