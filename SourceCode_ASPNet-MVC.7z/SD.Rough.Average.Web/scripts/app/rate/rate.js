﻿$(document).ready(function () {
    setControlVisibility(false);
    getRateData();

    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            getRateData();
            e.preventDefault();
        }
        else { null; }
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        setControlVisibility();
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getRateData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });

    $('#ShapeId').change(function () {
        setControlVisibility();
        getRateData();
    });

    $('#ClarityId').change(function () {
        setControlVisibility();
        getRateData();
    });

    //Autocomplete of Diameter
    $('#Diameter').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetRateDiameters",
                type: "GET",
                dataType: "json",
                data: {
                    diameter: request.term,
                    shapeId: $('#ShapeId').val(),
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Diameter.toFixed(2) };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getRateData();
            }
        }
    });
});

function getRateData(sortColumn, sortDirection) {
    var diameter = $('#Diameter').val();
    var shapeId = $('#ShapeId').val();
    var clarityId = $('#ClarityId').val();
    var colorRateVersionId = $('#ColorRateVersionId').val();
    var effectiveFrom = $('#EffectiveFrom').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }
    sendRequest("GET", "GetRateDetails",
        {
            Diameter: diameter,
            ShapeId: shapeId,
            ClarityId: clarityId,
            ColorRateVersionId: colorRateVersionId,
            EffectiveFrom: effectiveFrom,
            SortColumn: sortColumn,
            SortDirection: sortDirection,
            PageSize: pageSize,
            PageNumber: pageNumber
        }, "application/json; charset=utf-8", "json", bindRateData);
}

function bindRateData(data) {
    if (data !== null && data !== "Error") {
        totalPages = data.totalPages;
        totalRecords = data.totalRecords;
        var dt = $('#rateTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '51vh',
            "columnDefs": [
                {
                    targets: [1, 2, 4, 6],
                    className: 'dt-body-right'
                }
            ],
            "aaData": data.rateDetails,
            "aoColumns": [
                {
                    "mData": "ClarityName"
                },
                {
                    "mData": "Diameter",
                    "render": function (id, type, full, meta) {
                        return full.Diameter.toFixed(2);
                    }
                },
                {
                    "mData": "UnitPrice"
                },
                {
                    "mData": "CreatedBy"
                },
                {
                    "mData": "CreatedOn"
                },
                {
                    "mData": "ModifiedBy",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedBy !== null ? full.ModifiedBy : "-";
                    }
                },
                {
                    "mData": "ModifiedOn",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedOn !== null ? full.ModifiedOn : "-";
                    }
                }
            ]
        });

        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}

function importRateFile() {
    document.getElementById('ColorRateVersionId').value = $('#ColorRateVersionId').val();
    document.getElementById('EffectiveFrom').value = $('#EffectiveFrom').val();
    document.getElementById('IsFileImported').value = true;

    document.getElementById('labelName').innerText = "Overwrite Rate File:";

    $("#addRateDetail").modal("show");
}