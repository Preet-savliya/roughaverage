﻿$(document).ready(function () {

    $('#buttonRateSave').attr("disabled", true);

    $('#File').on('click', function (e) {
        $('#File').val('');
        $('#buttonRateSave').attr("disabled", true);
    });

    $('#File').on('change', function (e) {
        if ($('#File').val() !== "") {
            $('#File').css({
                "border": "",
                "background": ""
            });
            $('#emptyRateFileld').html('');
            $('#buttonRateSave').removeAttr("disabled", true);
        }
        else {
            $('#buttonRateSave').attr("disabled", true);
        }
    });
});