﻿var files = null;
var data = null;
var isSuccess = false;
var message = null;
var numericAndComaRegEx = "^[0-9\\,]*$";

$(document).ready(function () {
    var sarinActivity = null;

    $('#SarinActivity[name=SarinActivity]').on('change', function (e) {
        sarinActivity = $(this).val();

        if (sarinActivity === "Rough Planning") {
            hideElement('#nonMakeableStoneNumbersDiv');
            hideElement('#extraMakeableStoneNumbersDiv');

            hideElement('#makeableOrTopsLotDiv');
        }
        else {
            showElement('#makeableOrTopsLotDiv');

            showElement('#nonMakeableStoneNumbersDiv');
            showElement('#extraMakeableStoneNumbersDiv');
        }
        bindLots();
    });

    $('#IsTopsLot[name=IsTopsLot]').on('change', function (e) {
        $('#lotTypeValidationMessage').html('');

        $(this).css({
            "border": "",
            "background": ""
        });

        //const selectedLotTypeValue = getSelectedLotTypeValue();
        //if (selectedLotTypeValue === null || selectedLotTypeValue === '') {
        //    $('#lotTypeValidationMessage').html('Select which type of lot is this?');
        //}       
        
        bindLots();
    });

    $('#LotId').on('change', function (e) {
        $('#NonMakeableStoneNumbers').val('');
        $('#ExtraMakeableStoneNumbers').val('');

        hideElement('#messgeAlert');
        hideElement('#failedResultData');

        $('#emptyLotField').html('');

        $(this).css({
            "border": "",
            "background": ""
        });

        var lotId = parseInt($('#LotId').val());

        if (lotId > 0 && sarinActivity === "Makeable Planning") {
            const lotTypeSelection = getSelectedValueOfRadioControl('IsTopsLot');

            sendRequest("GET", "GetNonMakeableStones",
                {
                    LotId: lotId
                }, "application/json; charset=utf-8", "json", bindNonMakeableStoneNOsTxtbox);

            sendRequest("GET", "GetExtraMakeableStones",
                {
                    LotId: lotId
                }, "application/json; charset=utf-8", "json", bindExtraMakeableStoneNOsTxtbox);
        }
    });

    $('#NonMakeableStoneNumbers').keyup(function () {
        $('#nonMakeableStoneNumbersError').html('');
        $(this).css({
            "border": "",
            "background": ""
        });
    });

    $('#ExtraMakeableStoneNumbers').keyup(function () {
        $('#extraMakeableStoneNumbersError').html('');
        $(this).css({
            "border": "",
            "background": ""
        });
    });

    $('#Action').on('change', function (e) {
        hideElement('#messgeAlert');
        hideElement('#failedResultData');

        $('#emptyActionField').html('');

        $(this).css({
            "border": "",
            "background": ""
        });
    });

    $('#File').on('change', function (e) {
        hideElement('#messgeAlert');
        hideElement('#failedResultData');

        data = new FormData();
        files = $("#File").get(0).files;

        if (files.length > 0) {
            for (var index = 0; index < files.length; index++) {
                data.append("file", files[index]);
            }
        }

        $('#emptyFileField').html('');
        $('.field-validation-error').html('');
        $(this).css({
            "border": "",
            "background": ""
        });
    });

    $('#btnImport').click(function () {
        hideElement('#messgeAlert');

        hideElement('#parseErrorStonesContainer');
        hideElement('#missingStonesContainer');
        hideElement('#misMatchAndInvalidStonesContainer');
        hideElement('#failedResultData');

        if (validateImportLot()) {
            showElement('.loadingDiv');

            var subRoughId = parseInt($('#SubRoughId').val());
            var lotId = parseInt($('#LotId').val());

            var actionId = parseInt($('#Action').val());
            var sarinAcrivity = $('#SarinActivity:checked').val();
            const isTopsLot = getSelectedValueOfRadioControl('IsTopsLot') === "True";

            var nonMakeableStoneNumbers = $('#NonMakeableStoneNumbers').val();
            var extraMakeableStoneNumbers = $('#ExtraMakeableStoneNumbers').val();

            if (subRoughId) {
                sendRequest("POST", "ImportLotFile?SubRoughId=" + subRoughId
                    + "&LotId=" + lotId + "&ActionId=" + actionId
                    + "&SarinActivity=" + sarinAcrivity + "&IstopsLot=" + isTopsLot
                    + "&NonMakeableStoneNumbers=" + nonMakeableStoneNumbers
                    + "&ExtraMakeableStoneNumbers=" + extraMakeableStoneNumbers,
                    data,
                    false, "json", handleImportLotResult, false);
            }
        } else {
            hideElement('.loadingDiv');
        }
    });

    $('#invalidMisMatchTabsRoot a').click(function (e) {
        e.preventDefault();
        $(this).tab('show');
    });
});

function bindLots() {
    hideElement('#messgeAlert');
    hideElement('#failedResultData');

    var subRoughId = parseInt($('#SubRoughId').val());
    var sarinActivity = $('#SarinActivity:checked').val();
    let isTopsLot = false;
    let shouldFetchLotData = false;

    if (subRoughId && subRoughId > 0 && sarinActivity) {
        if (sarinActivity === "Rough Planning") {
            $('#NonMakeableStoneNumbers').val('');
            $('#ExtraMakeableStoneNumbers').val('');

            shouldFetchLotData = true;
        } else {
            isTopsLot = getSelectedValueOfRadioControl('IsTopsLot');
            shouldFetchLotData = isTopsLot !== null && isTopsLot !== '';

            //if (isTopsLot === null || isTopsLot === '') {
            //    $('#lotTypeValidationMessage').html('Select which type of lot is this?');
            //} else {
            //    shouldFetchLotData = true;
            //}
        }
    }

    if (shouldFetchLotData) {
        showElement('.loadingDiv');

        sendRequest("GET", "GetLotDropDownList",
            {
                SubRoughId: subRoughId,
                sarinActivity: sarinActivity,
                isTopsLot: isTopsLot
            }, "application/json; charset=utf-8", "json", bindLotDdl);
    } else {
        bindLotDdl({ ddlLotDetail: [] });
    }

    $('#emptySubRoughField').html('');
    $('#SubRoughName').css({
        "border": "",
        "background": ""
    });
}

function bindNonMakeableStoneNOsTxtbox(data) {
    $('#NonMakeableStoneNumbers').val(data);
}

function bindExtraMakeableStoneNOsTxtbox(data) {
    $('#ExtraMakeableStoneNumbers').val(data);
}

function validateImportLot() {
    var isValid = true;

    $('#SubRoughName,#LotId,#Action,#File').each(function () {
        if ($(this).val() === '' || $(this).val() === '0') {
            hideElement('.loadingDiv');

            isValid = false;
            $(this).css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
        }
        else {
            showElement('.loadingDiv');

            $(this).css({
                "border": "",
                "background": ""
            });

            $('#emptySubRoughField,#emptyLotField,#emptyActionField,#emptyFileField').html('');
        }
    });

    if ($('#SubRoughId').val() === '' || $('#SubRoughId').val() === '0') {
        $('#emptySubRoughField').html('SubRough is Required');
    }

    if ($('#LotId').val() === '' || $('#LotId').val() === '0') {
        $('#emptyLotField').html('Lot is Required');
    }

    if ($('#Action').val() === '' || $('#Action').val() === '0') {
        $('#emptyActionField').html('Action is Required');
    }

    if ($('#File').val() === '' || $('#File').val() === '0') {
        $('#emptyFileField').html('File is Required');
    }

    if ($('#NonMakeableStoneNumbers').val() !== null) {
        var nonMakeableStoneNumbers = $('#NonMakeableStoneNumbers').val();
        var regEx = new RegExp(numericAndComaRegEx);

        if (!regEx.test(nonMakeableStoneNumbers)) {
            $('#nonMakeableStoneNumbersError').html('Non-Process Stone Number(s) is invalid');

            hideElement('.loadingDiv');

            isValid = false;
            $('#NonMakeableStoneNumbers').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
        }
        else {
            showElement('.loadingDiv');

            $('#NonMakeableStoneNumbers').css({
                "border": "",
                "background": ""
            });
            $('#nonMakeableStoneNumbersError').html('');
        }
    }

    if ($('#ExtraMakeableStoneNumbers').val() !== null) {

        var extraMakeableStoneNumbers = $('#ExtraMakeableStoneNumbers').val();
        var regExForExtraStone = new RegExp(numericAndComaRegEx);

        if (!regExForExtraStone.test(extraMakeableStoneNumbers)) {
            $('#extraMakeableStoneNumbersError').html('Additional Stone Number(s) is invalid');

            hideElement('.loadingDiv');

            isValid = false;
            $('#ExtraMakeableStoneNumbers').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
        }
        else {
            showElement('.loadingDiv');

            $('#ExtraMakeableStoneNumbers').css({
                "border": "",
                "background": ""
            });
            $('#extraMakeableStoneNumbersError').html('');
        }
    }

    return isValid;
}

function generatePartTableHeader() {
    var tableHeader = $('<thead></thead>');
    var headerRow = $('<tr class="childTableHeaderRow"></tr>');

    headerRow.append($('<th></th>').text('Result Part Wt'));
    headerRow.append($('<th></th>').text('Polish Wt'));
    headerRow.append($('<th></th>').text('Color (Rate Ver.)'));
    headerRow.append($('<th></th>').text('Clarity'));
    headerRow.append($('<th></th>').text('Shape'));
    headerRow.append($('<th></th>').text('Measure (Diam/Length) Val.'));
    headerRow.append($('<th></th>').text('Sieve Size'));
    headerRow.append($('<th></th>').text('Rate'));
    headerRow.append($('<th></th>').text('Errors'));

    tableHeader.append(headerRow);
    return tableHeader;
}

function generatePartTableRow(stonePart) {
    var resultPartWeight = stonePart.ResultPartWeight
        ? stonePart.ResultPartWeight.IsValid
            ? stonePart.ResultPartWeight.ParsedValue.toFixed(3)
            : stonePart.ResultPartWeight.FileValue
        : '';

    var polWeight = stonePart.PolishWeight
        ? stonePart.PolishWeight.IsValid
            ? stonePart.PolishWeight.ParsedValue.toFixed(3)
            : stonePart.PolishWeight.FileValue
        : '';

    var color = stonePart.Color
        ? stonePart.Color.IsValid
            ? stonePart.Color.ParsedValue.Name
            : stonePart.Color.FileValue
        : '';

    var clarity = stonePart.Clarity
        ? stonePart.Clarity.IsValid
            ? stonePart.Clarity.ParsedValue.Name
            : stonePart.Clarity.FileValue
        : '';

    var shape = stonePart.Shape
        ? stonePart.Shape.IsValid
            ? stonePart.Shape.ParsedValue.Name
            : stonePart.Shape.FileValue
        : '';

    var measurementValue = stonePart.MeasurementValue
        ? stonePart.MeasurementValue.IsValid
            ? stonePart.MeasurementValue.ParsedValue.toFixed(3)
            : stonePart.MeasurementValue.FileValue
        : '';

    var sieveSize = stonePart.SieveSize
        ? stonePart.SieveSize.IsValid
            ? stonePart.SieveSize.ParsedValue.Name
            : stonePart.SieveSize.FileValue
        : '';

    var rate = stonePart.Rate
        ? stonePart.Rate.IsValid
            ? stonePart.Rate.ParsedValue.Rate
            : stonePart.Rate.FileValue
        : '';

    var tableRow = $('<tr></tr>');
    tableRow.append(generateTableTextNodeCell(resultPartWeight, stonePart.ResultPartWeight.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell(polWeight, stonePart.PolishWeight.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell(color, stonePart.Color.IsValid ? [] : ['text-danger']));
    tableRow.append(generateTableTextNodeCell(clarity, stonePart.Clarity.IsValid ? [] : ['text-danger']));
    tableRow.append(generateTableTextNodeCell(shape, stonePart.Shape.IsValid ? [] : ['text-danger']));
    tableRow.append(generateTableTextNodeCell(measurementValue, stonePart.MeasurementValue.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell(sieveSize, stonePart.SieveSize.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell(rate, stonePart.Rate.IsValid ? ['text-right'] : ['text-right', 'text-danger']));

    stonePart.HasError
        ? tableRow.append(generateTableHtmlNodeCell(generateListNode(stonePart.Errors), ['text-danger']))
        : tableRow.append(generateTableTextNodeCell('', []));

    return tableRow;
}

function generatePartTable(stoneParts) {
    var partTable = $('<table class="table-bordered table-hover table-responsive cellTable m-block-1r"></table>');
    partTable.append(generatePartTableHeader());

    var tableBody = $('<tbody></tbody>');
    $.each(stoneParts, function (_, stonePart) {
        tableBody.append(generatePartTableRow(stonePart));
    });

    partTable.append(tableBody);
    return partTable;
}

function generateStoneTableRow(index, stone) {
    var measureDate = stone.MeasureDate
        ? stone.MeasureDate.IsValid
            ? moment(stone.MeasureDate.ParsedValue).format("DD-M-YYYY")
            : stone.MeasureDate.FileValue
        : '';

    var measureTime = stone.MeasureTime
        ? stone.MeasureTime.IsValid
            ? stone.MeasureTime.ParsedValue.toString("hh:mm")
            : stone.MeasureTime.FileValue
        : '';

    var operator = stone.Operator
        ? stone.Operator.IsValid
            ? stone.Operator.ParsedValue.Code + ' - ' + stone.Operator.ParsedValue.Name
            : stone.Operator.FileValue
        : '';

    var stoneNumber = stone.StoneNumber
        ? stone.StoneNumber.IsValid
            ? stone.StoneNumber.ParsedValue.StoneNumber
            : stone.StoneNumber.FileValue
        : '';

    var machineNumber = stone.MachineNumber
        ? stone.MachineNumber.IsValid
            ? stone.MachineNumber.ParsedValue.MachineNumber
            : stone.MachineNumber.FileValue
        : '';

    var measureType = stone.MeasureType
        ? stone.MeasureType.IsValid
            ? stone.MeasureType.ParsedValue.Code
            : stone.MeasureType.FileValue
        : '';

    var planningLevel = stone.PlanningLevel
        ? stone.PlanningLevel.IsValid
            ? stone.PlanningLevel.ParsedValue.Name
            : stone.PlanningLevel.FileValue
        : '';

    var roughWeight = stone.RoughWeight
        ? stone.RoughWeight.IsValid
            ? stone.RoughWeight.ParsedValue.toFixed(3)
            : stone.RoughWeight.FileValue
        : '';

    var tableRow = $('<tr></tr>');
    tableRow.append(generateTableTextNodeCell(index + 1, ['text-right']));
    tableRow.append(generateTableTextNodeCell(measureDate, stone.MeasureDate.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell(measureTime, stone.MeasureTime.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell(stoneNumber, stone.StoneNumber.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell(operator, stone.Operator.IsValid ? [] : ['text-danger']));
    tableRow.append(generateTableTextNodeCell(machineNumber, stone.MachineNumber.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell(measureType, stone.MeasureType.IsValid ? [] : ['text-danger']));
    tableRow.append(generateTableTextNodeCell(planningLevel, stone.PlanningLevel.IsValid ? [] : ['text-danger']));
    tableRow.append(generateTableTextNodeCell(roughWeight, stone.RoughWeight.IsValid ? ['text-right'] : ['text-right', 'text-danger']));
    tableRow.append(generateTableTextNodeCell((stone && stone.FileName) ? stone.FileName : '', []));

    stone.HasError
        ? tableRow.append(generateTableHtmlNodeCell(generateListNode(stone.Errors), ['text-danger']))
        : tableRow.append(generateTableTextNodeCell('', []));

    return tableRow;
}

function bindParseErrorStonesData(stonesData) {
    showElement('#failedResultData');
    showElement('#parseErrorStonesContainer');

    var parseErrorsStonesTableBody = $("#parseErrorStonesDataTable tbody");
    parseErrorsStonesTableBody.empty();

    if (stonesData.length > 0) {
        $.each(stonesData, function (index, stone) {
            var stoneAttributesRow = generateStoneTableRow(index, stone, hasPartsError);
            parseErrorsStonesTableBody.append(stoneAttributesRow);

            var hasPartsError = !stone.HasMisMatchInPartsCount && stone.PolishStones.some(x => x.HasError);
            if (hasPartsError) {
                var stonePartsWithError = stone.PolishStones.filter(x => x.HasError);
                var partsTable = generatePartTable(stonePartsWithError);

                var partsRow = $('<tr></tr>');
                partsRow.append($('<td></td>').addClass('border-inline-end-0').addClass('border-block-0'));
                partsRow.append($('<td></td>').attr('colspan', 10)
                    .addClass('p-0').addClass('border-inline-start-0').addClass('border-block-0')
                    .append(partsTable));

                parseErrorsStonesTableBody.append(partsRow);
            }
        });
    }
}

function bindMissingStoneData(missingStones) {
    showElement('#failedResultData');
    showElement('#missingStonesContainer');

    var listRoot = $('#missingStoneNumbers');
    $.each(missingStones, function (_, stoneNumber) {
        listRoot.append($("<li></li>").text(stoneNumber));
    });
}
function bindInvalidMakeableData(invalidMakeableStones) {
    var invalidMakeableStonesDataTableBody = $("#invalidMakeableStonesDataTable tbody");
    invalidMakeableStonesDataTableBody.empty();

    if (invalidMakeableStones.length > 0) {
        $.each(invalidMakeableStones, function (index, invalidStoneEntry) {
            var tableRow = $('<tr></tr>');

            tableRow.append(generateTableTextNodeCell(index + 1, ['text-right']));
            tableRow.append(generateTableTextNodeCell(invalidStoneEntry.StoneNumber, ['text-right']));

            if (invalidStoneEntry.FileNames.length > 1) {
                var fileNamesList = generateListNode(invalidStoneEntry.FileNames, ['cell-ul']);
                tableRow.append(generateTableHtmlNodeCell(fileNamesList, ['p-block-p25r']));
            } else {
                var fileName = invalidStoneEntry.FileNames.length === 1
                    ? invalidStoneEntry.FileNames[0]
                    : '-';
                tableRow.append(generateTableTextNodeCell(fileName, []));
            }

            tableRow.append(generateTableTextNodeCell(invalidStoneEntry.FileMakeableStoneCount, []));

            invalidMakeableStonesDataTableBody.append(tableRow);
        });
    }
    else {
        var emptyRow = $('<tr></tr>').append($('<td></td>')
            .attr('colspan', 4)
            .append('No invalid makeable stone(s).'));

        invalidMakeableStonesDataTableBody.append(emptyRow);
    }
}
function bindMismatchStoneDetail(mismatchStones) {
    var misMatchStonesDataTableBody = $("#misMatchStonesDataTable tbody");
    misMatchStonesDataTableBody.empty();

    if (mismatchStones.length > 0) {
        $.each(mismatchStones, function (index, misMatchStoneEntry) {
            var tableRow = $('<tr></tr>');

            tableRow.append(generateTableTextNodeCell(index + 1, ['text-right']));
            tableRow.append(generateTableTextNodeCell(misMatchStoneEntry.StoneNumber, ['text-right']));

            tableRow.append(generateTableTextNodeCell(misMatchStoneEntry.RoughTotalPolStoneCount, ['text-right']));
            tableRow.append(generateTableTextNodeCell(misMatchStoneEntry.RoughMakeablePolStoneCount, ['text-right']));
            tableRow.append(generateTableTextNodeCell(misMatchStoneEntry.TopsPolishedStoneCount, ['text-right']));

            tableRow.append(generateTableTextNodeCell(misMatchStoneEntry.FileMakeableStoneCount, ['text-right']));
            tableRow.append(generateTableTextNodeCell(misMatchStoneEntry.NonMakeableStoneCount, ['text-right']));
            tableRow.append(generateTableTextNodeCell(misMatchStoneEntry.ExtraMakeableStoneCount, ['text-right']));

            if (misMatchStoneEntry.FileNames) {
                if (misMatchStoneEntry.FileNames.length > 1) {
                    var fileNamesList = generateListNode(misMatchStoneEntry.FileNames, ['cell-ul']);
                    tableRow.append(generateTableHtmlNodeCell(fileNamesList, ['p-block-p25r']));
                } else {
                    var fileName = misMatchStoneEntry.FileNames.length === 1
                        ? misMatchStoneEntry.FileNames[0]
                        : '';
                    tableRow.append(generateTableTextNodeCell(fileName, []));
                }
            } else {
                tableRow.append(generateTableTextNodeCell('', []));
            }

            var stoneDiffText = Math.abs(misMatchStoneEntry.MismatchStoneCount).toString()
                + ' - '
                + (misMatchStoneEntry.MismatchStoneCount > 0 ? 'Missing' : 'Extra' + ' Stone(s)');
            tableRow.append(generateTableTextNodeCell(stoneDiffText, ['text-danger']));

            misMatchStonesDataTableBody.append(tableRow);
        });
    }
    else {
        var emptyRow = $('<tr></tr>')
            .append($('<td></td>')
                .attr('colspan', 10)
                .append('No mis-match makeable stone(s).'));

        misMatchStonesDataTableBody.append(emptyRow);
    }
}
function bindStoneValidationErrorData(stoneValidationErrorResult) {
    showElement('#failedResultData');
    showElement('#misMatchAndInvalidStonesContainer');

    showElement('#invalidOrMisMatchTabsContainer');

    $('a[href="#mismatchStones"]').tab('show');

    if (stoneValidationErrorResult.InvalidStones) {
        bindInvalidMakeableData(stoneValidationErrorResult.InvalidStones);
    }

    if (stoneValidationErrorResult.MisMatchStones) {
        bindMismatchStoneDetail(stoneValidationErrorResult.MisMatchStones);
    }

    $('#mismatchStonesBadge').html(stoneValidationErrorResult.MisMatchStones ? stoneValidationErrorResult.MisMatchStones.length : 0);
    $('#invalidMakeableStonesBadge').html(stoneValidationErrorResult.InvalidStones ? stoneValidationErrorResult.InvalidStones.length : 0);
}

function handleImportLotResult(result) {
    if (result) {
        if (result.isSuccess) {
            displayAlert('alert-success', result.message);

            hideElement('#failedResultData');

            $('#emptyLotField').html('');
            $('#emptyActionField').html('');
            $('#emptyFileField').html('');
            $('#nonMakeableStoneNumbersError').html('');
        } else {
            if (result.errorResult) {
                if (result.errorResult.StonesParseError) {
                    bindParseErrorStonesData(result.errorResult.StonesParseError);
                }

                if (result.errorResult.MissingStoneNumbers) {
                    bindMissingStoneData(result.errorResult.MissingStoneNumbers);
                }

                if (result.errorResult.StoneValidationError
                    && (result.errorResult.StoneValidationError.InvalidStones
                        || result.errorResult.StoneValidationError.MisMatchStones)) {
                    bindStoneValidationErrorData(result.errorResult.StoneValidationError);
                }
            } else {
                displayAlert('alert-danger', result.message);
            }
        }
    } else {
        displayAlert('alert-danger', 'Lot import result is not available, so the lot file(s) might not be imported successfully, first verify that the lot file(s) are imported or not.');
    }
    hideElement('.loadingDiv');
}

function resetForm() {
    hideElement('#messgeAlert');
    hideElement('#failedResultData');

    $('#LotId,#SubRoughName,#Action,#File,#NonMakeableStoneNumbers,#ExtraMakeableStoneNumbers').css({
        "border": "",
        "background": ""
    });

    $('#emptyLotField').html('');
    $('#emptyActionField').html('');
    $('#emptyFileField').html('');
    $('#emptySubRoughField').html('');
    $('#nonMakeableStoneNumbersError').html('');
}

function displayAlert(alertClass, message) {
    $('#messgeAlert').html(
        '<div class="alert ' + alertClass + '">' +
        '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> ' + message + ' </div>');

    showElement('#messgeAlert');
}

function generateTableTextNodeCell(cellContent, cssClasses) {
    var tableCell = $('<td></td>').addClass(cssClasses.join(' '));
    tableCell.text(cellContent);

    return tableCell;
    /*return `<td class="${cssClasses.join(' ')}">${cellContent}</td>`;*/
}

function generateTableHtmlNodeCell(cellContent, cssClasses) {
    var tableCell = $('<td></td>').addClass(cssClasses.join(' '));
    tableCell.html(cellContent);

    return tableCell;
}

function generateListNode(listData, cssClasses) {
    if (listData && listData.length > 0) {
        var listRoot = $("<ul></ul>");
        if (cssClasses) {
            $.each(cssClasses, function (_, cls) {
                listRoot.addClass(cls);
            });
        }

        $.each(listData, function (_, item) {
            var listItem = $("<li></li>").text(item);
            listRoot.append(listItem);
        });
        return listRoot;
    }
    return "";
}
