﻿var subRoughId = 0;
var groupName = '';
var sarinActivity = null;
var sizeClarityData = null;
var hideSizeClarityData = null;

$(document).ready(function () {

    subRoughId = $('#SubRoughId').val();
    if (sarinActivity !== undefined) {
        sarinActivity = $('#RoughPlanning').attr('name');
        getSizeClarityAverageData(subRoughId, groupName, sarinActivity);
    }

    $('#LotGroup').change(function () {
        sizeClarityData = $('#SizeClarityData').val();

        groupName = $(this).val();

        getSizeClarityAverageData(subRoughId, groupName, sarinActivity);
    });


    $("#RoughPlanning").click(function () {
        sarinActivity = $('#RoughPlanning').attr('name');
        $('#LotGroup').val('');
        groupName = "";

        getSizeClarityAverageData(subRoughId, groupName, sarinActivity);
    });

    $("#MakeablePlanning").click(function () {
        sarinActivity = $('#MakeablePlanning').attr('name');
        $('#LotGroup').val('');
        groupName = "";

        getSizeClarityAverageData(subRoughId, groupName, sarinActivity);
    });

});

function getSizeClarityAverageData(subRoughId, groupName, sarinActivity) {
    $.get(appendURL('SizeClarity/GetSizeClarityAverageDetails?subRoughId=' + subRoughId + '&sarinActivity='
        + sarinActivity + '&groupName=' + groupName), function (data) {

            var a = data;
            $('#roughPlanningSizeClarity').html(data);
            $('#roughPlanningSizeClarity').fadeIn('fast');
        });
}