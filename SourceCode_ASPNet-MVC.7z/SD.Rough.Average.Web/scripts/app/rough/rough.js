﻿$(document).ready(function () {
    // Send request to server for get all the details in grid view when Rough page loads
    sendRequest("GET", "/Rough/GetRoughDetails", "{}", "application/json; charset=utf-8", "json", BindRoughData);

    // Input type Enter keypress in search
    $('.inputRoughSearch').keypress(function (e) {
        e.which === 13 ? SendRoughData() : null;
    });

    // Btn RoughSearch on click
    $('#btnRoughSearch').click(function () {
        SendRoughData();
    });

    // Sorting Column
    $('.sortingColumn').click(function (evt) {
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];

        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        SendRoughData(sortColumn, sortDirection);
    });

});

// function for search and sort Data
function SendRoughData(sortColumn, sortDirection) {
    var searchWeight = $('#Weight').val();
    var searchPieceCount = $('#PieceCount').val();
    var ddlRoughTypeId = $('#RoughTypeId').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();
    var createdOnDateFrom = $('#CreatedOnDateFrom').val();
    var createdOnDateTo = $('#CreatedOnDateTo').val();

    sendRequest("GET", "/Rough/GetRoughDetails",
        {
            Weight: searchWeight,
            PieceCount: searchPieceCount,
            RoughTypeId: ddlRoughTypeId,
            CreatedOnDateFrom: createdOnDateFrom,
            CreatedOnDateTo: createdOnDateTo,
            SortingColumn: sortColumn,
            SortDirection: sortDirection,
            PageSize : pageSize,
            PageNumber: pageNumber
        }, "application/json; charset=utf-8", "json", BindRoughData);
}

// Function for binding grid data
function BindRoughData(data) {
    if (data !== null && data !== "Error") {
        //Assign values to paging variables
        totalPages = data.totalPages;
        totalRecords = data.totalRecords;
        // For DataTable
        var dt = $('#roughTable').DataTable({
            "destroy": true,
            "searching": false,
            "paging": false,
            "info": false,
            "aaData": data.roughDetails,
            "aoColumns": [ // All Columns 

                        //{
                        //    "class": "details-control",
                        //    "data": null,
                        //    "defaultContent": "",
                        //    "sTitle": "View",
                        //    "mdata": "Id",
                        //    "orderable": false,
                        //    "searchable": false,
                        //    "render": function (id, type, full, meta) {
                        //        $('.gridHeaderView').removeClass('sorting_asc');
                        //        return null
                        //    }
                        //},
                        {
                            "sTitle": "Edit",
                            "mdata": "Id",
                            "orderable": false,
                            "searchable": false,
                            "render": function (id, type, full, meta) {
                                $('.gridHeaderEdit').removeClass('sorting_asc');
                                return '<a href="Edit?id=' + full.Id + '" class="linkEdit">Edit</a>';
                            }
                        },
                        {
                            "sTitle": "Delete",
                            "mdata": "Id",
                            "orderable": false,
                            "searchable": false,
                            "render": function (id, type, full, meta) {
                                var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                                return '<a href="Delete?id=' + full.Id + '"  onclick = "return confirm(\'Are you sure you want to '
                                    + deleteActivate + ' this rough entry\');">'
                                    + deleteActivate + '</a>';
                            }
                        },
                        {
                            // "sTitle": "Rough Weight",
                            "mData": "Weight",
                            "orderable": false,
                            "searchable": false,
                            "sClass": "text-right"
                        },
                        {
                            // "sTitle": "Piece Count",
                            "mData": "PieceCount",
                            "orderable": false,
                            "searchable": false,
                            "sClass": "text-right"
                        },
                        {
                            // "sTitle": "Type Name",
                            "mData": "RoughType",
                            "orderable": false,
                            "searchable": false,
                            "sClass": "text-left"
                        },
                        {
                            // "sTitle": "Type Name",
                            "mData": "CreatedOn",
                            "orderable": false,
                            "searchable": false,
                            "sClass": "text-left"
                        }
            ],
            // For Background if Entry is Deleted
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });

        // For View Information collapse

        //$('#roughTable tbody').on('click', 'tr td.details-control', function () {
        //    var tr = $(this).closest('tr');
        //    var row = dt.row(tr);
        //    if (row.child.isShown()) {
        //        tr.removeClass('details');
        //        row.child.hide();
        //    }
        //    else {
        //        tr.addClass('details');
        //        row.child(FormatView(row.data())).show();
        //    }
        //});

        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.minPageIndex + (data.totalRecords > 0) ? 1 : 0);
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);
    }
}

// Function for formatting data
//function FormatView(d) {
//    var formatTableData =
//        '<table class="table-bordered tableViewinfo">' +
//            '<tr>' +
//                '<th class="ViewTD">' + 'Rough weight' + '</th>' +
//                '<td class="ViewTD">' + d.Weight + '</td>' +
//            '</tr>' +
//            '<tr>' +
//                '<th class="ViewTD">' + 'Piece count' + '</th>' +
//                '<td class="ViewTD">' + d.PieceCount + '</td>' +
//            '</tr>' +
//            '<tr>' +
//                '<th class="ViewTD">' + 'Rough type' + '</th>' +
//                '<td class="ViewTD">' + d.RoughType + '</td>' +
//            '</tr>' +
//         '</table>'
//    return formatTableData;
//}
