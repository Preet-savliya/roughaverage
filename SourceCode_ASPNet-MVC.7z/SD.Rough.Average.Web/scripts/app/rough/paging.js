﻿var pageIndex = 1;
var totalPages = 1;
var totalRecords = 0;
var currentPage = 0;

$(document).ready(function () {
    // Input textbox Paging 
    $('.inputPaging').keypress(function (e) {
        if (e.which === 13) {
            currentPage = parseInt($('#pageNumber').val());
            pageIndex = currentPage > totalPages ? totalPages : currentPage;
            $('#pageNumber').val(pageIndex);
            SendRoughData();
        }
    });

    // Button FirstPage click
    $('#btnFirstPage').click(function (e) {
        pageIndex = 1;
        $('#pageNumber').val(pageIndex);
        SendRoughData();
    });

    // Button previousPage click
    $('#btnPreviousPage').click(function (e) {
        currentPage = parseInt($('#pageNumber').val());
        pageIndex = currentPage > 1 ? currentPage - 1 : 1;
        $('#pageNumber').val(pageIndex);
        SendRoughData();
    });

    // Button nextPage click
    $('#btnNextPage').click(function (e) {
        currentPage = parseInt($('#pageNumber').val());
        pageIndex = currentPage < totalPages ? currentPage + 1 : totalPages;
        $('#pageNumber').val(pageIndex);
        SendRoughData();
    });

    // Button LastPage click
    $('#btnLastPage').click(function (e) {
        $('#pageNumber').val(totalPages);
        SendRoughData();
    });

    $("#ddlPageSize").change(function () {
        SendRoughData();
    });
});