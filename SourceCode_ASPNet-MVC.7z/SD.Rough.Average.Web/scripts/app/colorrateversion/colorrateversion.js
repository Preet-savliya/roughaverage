﻿var currentColorId;
var dateFormat = "DD-MMM-YYYY";

$(document).ready(function () {
    setControlVisibility(false);
    getColorRateVersionData();
});

function getColorRateVersionData() {

    currentColorId = $('#Id').val();
    sendRequest("GET", appendURL("ColorRateVersion/GetColorRateVersionDetails"),
        { colorId: $('#Id').val() }, "application/json; charset=utf-8", "json", bindColorData);
}

function bindColorData(data) {
    if (data !== null && data !== "Error") {
        var dt = $('#colorRateVersionTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '38vh',
            "columnDefs": [
                {
                    targets: [2, 4, 6],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 1, 7, 8],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.colorRateVersionDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="' + appendURL("ColorRateVersion/Edit") + '?colorRateVersionId=' + full.Id + '" title="Edit" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="glyphicon glyphicon-edit"></span>' +
                            '</a>';
                    }
                },
                {
                    "mData": "Name",
                    "sClass": "text-left",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return full.IsFileImported ? '<a href="' + appendURL("Rate/Index") + '?colorRateVersionId=' + full.Id + '&effectiveFrom=' +
                            full.EffectiveFrom + '" title="Rate Detail" class="loadingProcess linkEdit"> ' +
                            full.Name + '</a>' : full.Name;
                    }
                },
                {
                    "mData": "EffectiveFrom"
                },
                {
                    "mData": "CreatedBy"
                },
                {
                    "mData": "CreatedOn"
                },
                {
                    "mData": "ModifiedBy",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedBy !== null ? full.ModifiedBy : "-";
                    }
                },
                {
                    "mData": "ModifiedOn",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedOn !== null ? full.ModifiedOn : "-";
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a onclick="return importRateFile(' + full.Id + ',`' + moment(full.EffectiveFrom).format(dateFormat) + '`,' + full.IsFileImported + ');" ' +
                            ' title="Import Rate File" class="btn-edit linkEdit ' + (full.IsFileImported ? 'disable' : '') + '">' +
                            '<span class="glyphicon glyphicon-import"></span>' +
                            '</a>';
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="' + appendURL("ColorRateVersion/Delete") + '?colorRateVersionId=' + full.Id + "&colorId=" + currentColorId + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate") + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            (deleteActivate === "Delete" ? '<span class="glyphicon glyphicon-trash"></span></a>' : '<span class="glyphicon glyphicon-ok"></span>') +
                            '</a>';
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });
        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}

function importRateFile(colorRateVersionId, effectiveFrom, isFileImported) {
    document.getElementById('ColorRateVersionId').value = colorRateVersionId;
    document.getElementById('EffectiveFrom').value = effectiveFrom;
    document.getElementById('IsFileImported').value = isFileImported;

    document.getElementById('labelName').innerText = "Add Rate File:";

    $("#addRateDetail").modal("show");
}