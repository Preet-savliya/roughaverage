﻿var ddlSubRough = parseInt(0);
var ddlLot = parseInt(0);
var stoneNumber = null;

$(document).ready(function () {

    // Function for On key press enter in input search
    $(".inputSearch").keypress(function (e) {
        if (e.which === 13) {
            e.preventDefault();
            if (ddlSubRough > 0 && ddlLot > 0) {
                getStoneData();
            }
        }
    });

    // Btn Search on click
    $('#btnSearch').click(function () {
        if (ddlSubRough > 0 && ddlLot > 0) {
            getStoneData();
        }
    });

    // Sorting Column
    $('.sortingColumn').click(function (evt) {
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getStoneData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });

    //Autocomplete of SubRoughWeight
    $('#StoneNumber').autocomplete({
        autoFocus: true,
        scroll:true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("Stone/GetStoneNumber"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    LotId : parseInt($('#LotId').val())
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.StoneNumber };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                getStoneData();
            }
        }
    });
});

// function for sendData to server
function getStoneData(sortColumn, sortDirection) {
    showElement('.loadingDiv');
    ddlSubRough = parseInt($('#SubRoughId').val());
    ddlLot = parseInt($('#LotId').val());
    stoneNumber = $('#StoneNumber').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }

    sendRequest("GET", appendURL("Stone/GetStoneDetails"),
        {
            SubRoughId : ddlSubRough,
            LotId: ddlLot,
            StoneNumber: stoneNumber,
            PageSize: pageSize,
            PageNumber: pageNumber,
            SortingColumn: sortColumn,
            SortDirection: sortDirection
        }, "application/json; charset=utf-8", "json", bindStoneData);
}

// function for Bind data in Grid
function bindStoneData(data) {
    if (data !== null && data !== "Error") {
        //Assign values to paging variables
        totalPages = data.totalPages;
        totalRecords = data.totalRecords;
        // For DataTable
        var dt = $('#stoneTable').DataTable({
            "destroy": true,
            "searching": false,
            "paging": false,
            "info": false,
            "aaData": data.stoneDetails,
            "aoColumns": [
                            {
                                "sTitle": "Delete",
                                "mdata": "Id",
                                "orderable": false,
                                "searchable": false,
                                "render": function (id, type, full, meta) {
                                    $('.stoneGridHeaderDelete').removeClass('sorting_asc');
                                    return '<a href="Delete?id=' + full.Id + '" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">Delete</a>';
                                }
                            },
                            {
                                "mData": "Date",
                                "orderable": false,
                                "searchable": false,
                                "sClass": "text-left"
                            },
                            {
                                "mData": "Time",
                                "orderable": false,
                                "searchable": false,
                                "sClass": "text-left"
                            },
                            {
                                "mData": "Operator",
                                "orderable": false,
                                "searchable": false,
                                "sClass": "text-left"
                            },
                            {
                                "mData": "StoneNumber",
                                "orderable": false,
                                "searchable": false,
                                "sClass": "text-left"
                            },
                            {
                                "mData": "MachineNumber",
                                "orderable": false,
                                "searchable": false,
                                "sClass": "text-right"
                            },
                            {
                                "mData": "MeasureType",
                                "orderable": false,
                                "searchable": false,
                                "sClass": "text-left"
                            },
                            {
                                "mData": "PlanningLevel",
                                "orderable": false,
                                "searchable": false,
                                "sClass": "text-left"
                            },
                            {
                                "mData": "Weight",
                                "orderable": false,
                                "searchable": false,
                                "sClass": "text-right",
                                "render": function (id, type, full, meta) {
                                    return full.Weight.toFixed(3);
                                }
                            }
                        ]
        });
        $(".stoneGridTable tbody td.dataTables_empty").attr('colspan', 9);
        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);
        showElement('.stoneGridData');

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}

// function for Bind DDL 
function ddlSubRoughOnChanged() {
    showElement('.loadingDiv');
    var ddlSubRoughId = $('#SubRoughId').val();
    hideElement('.stoneGridData');
    sendRequest("GET", appendURL("Stone/GetLotDropDownList"),
        {
            SubRoughId: ddlSubRoughId
        }, "application/json; charset=utf-8", "json", bindLotDdl);
}
