﻿$(document).ready(function () {
    setControlVisibility(false);
    getRoughSizeData();

    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            getRoughSizeData();

            e.preventDefault();
        }
        else { null; }
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        setControlVisibility();
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getRoughSizeData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });


    //Autocomplete of Minimum Size
    $('#Name').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("RoughSize/GetRoughSizeNames"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Name };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getRoughSizeData();
            }
        }
    });

    //Autocomplete of Maximum Size
    $('#DisplayName').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("RoughSize/GetRoughSizeDisplayNames"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.DisplayName };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getRoughSizeData();
            }
        }
    });
});

function getRoughSizeData(sortColumn, sortDirection) {
    var name = $('#Name').val();
    var displayName = $('#DisplayName').val();

    sendRequest("GET", "GetRoughSizeDetails",
        {
            Name: name,
            DisplayName: displayName,
            SortColumn: sortColumn,
            SortDirection: sortDirection
        }, "application/json; charset=utf-8", "json", bindRoughSizeData);
}

function bindRoughSizeData(data) {
    if (data !== null && data !== "Error") {
        var dt = $('#roughSizeTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '45vh',
            "columnDefs": [
                {
                    targets: [2, 3, 4, 5, 7, 9],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 1, 10],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.roughSizeDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="Edit?roughSizeId=' + full.Id + '" title="Edit" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="glyphicon glyphicon-edit"></span>' +
                            '</a>';
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="Detail?roughSizeId=' + full.Id + '" title="Detail" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="fa fa-eye"></span>' +
                            '</a>';
                    }
                },
                {
                    "mData": "Name"
                },
                {
                    "mData": "DisplayName"
                },
                {
                    "mData": "DisplayOrder"
                },
                {
                    "mData": "Description",
                    "render": function (id, type, full, meta) {
                        return full.Description !== null ? full.Description : "-";
                    }
                },
                {
                    "mData": "CreatedBy",
                    "render": function (id, type, full, meta) {
                        return full.CreatedBy !== null ? full.CreatedBy : "-";
                    }
                },
                {
                    "mData": "CreatedOn",
                    "render": function (id, type, full, meta) {
                        return full.CreatedOn !== null ? full.CreatedOn : "-";
                    }
                },
                {
                    "mData": "ModifiedBy",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedBy !== null ? full.ModifiedBy : "-";
                    }
                },
                {
                    "mData": "ModifiedOn",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedOn !== null ? full.ModifiedOn : "-";
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="Delete?roughSizeId=' + full.Id + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate") + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            (deleteActivate === "Delete" ? '<span class="glyphicon glyphicon-trash"></span></a>' : '<span class="glyphicon glyphicon-ok"></span>') +
                            '</a>';
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}