﻿let clarityId = 0;

let roughColorShadeId = 0;
let colorRateVersionId = 0;

let roughSubType = "";
let isDisplayRoughSubTypeDdl = "";

let rowIndex = parseInt($('#tblAssignedDetail tbody tr').length);
let lotAssignIndex = parseInt($('#tblAssignedDetail tbody tr').length) - 1;

var sarinActivity = "";
let isRoughPlanning = "";
const roughPlanning = "Rough Planning";
const makeablePlanning = "Makeable Planning";

let clarities = [];

let isHaveCustomTopsConfiguration;
const customTopsQuestionControlQuery = 'input[type="radio"][name="IsHaveCustomTopsConfiguration"]';
const customTopsQuestionCheckedQuery = customTopsQuestionControlQuery + ':checked';

$(function () {
    bindIsLotBySize();
    bindAssignDetailDBValue();

    isRoughPlanning = $('#IsRoughPlannning').val();
    sarinActivity = $('#SarinActivityId :selected').text();

    if (sarinActivity === makeablePlanning) {
        showElement('#clarityDiv');
        showElement('#makeableOrTopsLotDiv');

        hideElement('#colorRateVersionDiv');
    }
    else if (sarinActivity === roughPlanning || sarinActivity === "Select") {
        $('#ClarityId').val('');
        hideElement('#clarityDiv');
        hideElement('#makeableOrTopsLotDiv');

        if (sarinActivity === roughPlanning) {

            if (isDisplayRoughSubTypeDdl === "False" && isRoughPlanning === "False"
                && $('#RoughCategoryId option').length > 1) {
                showElement('#roughSubTypeDiv');
            }

            if (roughColorShadeId !== null) {
                showElement('#colorRateVersionDiv');
            }
        }
    }

    manageCustomTopsSectionVisibility();

    isDisplayRoughSubTypeDdl = $('#IsDisplyRoughSubTypeDdl').val();
    if (isDisplayRoughSubTypeDdl === "True")
        showElement('#roughSubTypeDiv');

    roughColorShadeId = $('#ColorShadeId').val();

    $('#IsTopsLot[name=IsTopsLot]').on('change', function (e) {
        $('#lotTypeValidationMessage').html('');
        $(this).css({
            "border": "",
            "background": ""
        });
    });

    $('#ClarityId').on('change', function (e) {
        $('#validationMessage').html('');
        $(this).css({
            "border": "",
            "background": ""
        });
    });

    $('#ColorRateVersionId').on('change', function (e) {
        $('#validationMsgColorRateVersion').html('');
        $(this).css({
            "border": "",
            "background": ""
        });
    });

    $('#ColorShadeId').on('change', function (e) {
        if (sarinActivity === roughPlanning) {

            sendRequest("GET", appendURL("ColorRateVersion/GetColorRateVersionByRoughColorShadeAndColor"),
                {
                    colorShadeId: $(this).val(),
                    EntryStatus: 'Active'
                }, "application/json; charset=utf-8", "json", bindColorRateVersionListData);

            showElement('#colorRateVersionDiv');
        }
    });

    $('#btnSaveLot').on("click", function () {
        clarityId = $("#ClarityId").val();
        colorRateVersionId = $("#ColorRateVersionId").val();
        sarinActivity = $('#SarinActivityId :selected').text();

        if (sarinActivity === makeablePlanning) {
            const lotTypeSelection = getSelectedValueOfRadioControl('IsTopsLot');
            if (lotTypeSelection === null) {
                hideElement('.loadingDiv');

                //$('#lotTypeControlDiv').css({
                //    "border": "1px solid #ff0000",
                //    "background": "#fee"
                //});
                $('#lotTypeValidationMessage').html('Select which type of lot is this?');
                return false;
            }
            //else {
            //    $('#lotTypeControlDiv').css({
            //        "border": "",
            //        "background": ""
            //    });
            //}

            if (clarityId === '0' || clarityId === '') {
                hideElement('.loadingDiv');
                $('#ClarityId').css({
                    "border": "1px solid #ff0000",
                    "background": "#fee"
                });
                $('#validationMessage').html('Clarity is Required');
                return false;
            }
            else {
                $('#ClarityId').css({
                    "border": "",
                    "background": ""
                });
            }
        }

        if (sarinActivity === roughPlanning) {
            if (colorRateVersionId === '0' || colorRateVersionId === '') {
                hideElement('.loadingDiv');

                $('#ColorRateVersionId').css({
                    "border": "1px solid #ff0000",
                    "background": "#fee"
                });

                $('#validationMsgColorRateVersion').html('Color Rate Version is Required');

                return false;
            } else {
                $('#ColorRateVersionId').css({
                    "border": "",
                    "background": ""
                });
            }

            var isValidConfiguration = validateTopsConfiguration();
            // PENDING: if Invalid, then bind/display errors
        }


        if ($('#validationError').text() === "Sieve size is invalid") {
            hideElement('.loadingDiv');
            return false;
        }

        if ($('#PieceCount').hasClass('input-validation-error'))
            hideElement('.loadingDiv');

        if ($('#SubRoughId').val() === '' || $('#SubRoughId').val() === '0')
            hideElement('.loadingDiv');

        if ($('#Weight').val() === '' || $('#Weight').val() === '0')
            hideElement('.loadingDiv');

        if ($('#PieceCount').val() === '' || $('#PieceCount').val() === '0')
            hideElement('.loadingDiv');

        if ($('#SizeSign').val() === '' || $('#SizeSign').val() === '0')
            hideElement('.loadingDiv');

        if ($('#SieveSize').val() === '' || $('#SieveSize').val() === '0')
            hideElement('.loadingDiv');

        if ($('#SieveSizeId').val() === '' || $('#SieveSizeId').val() === '0')
            hideElement('.loadingDiv');

        if (!validateRoughSubType()) {
            hideElement('.loadingDiv');
            return false;
        }
    });

    var previousSarintActivityId;
    $('#SarinActivityId').on('focus', function () {
        previousSarintActivityId = this.value;
    }).on("change", function () {
        $('#lotTypeValidationMessage').html('');
        uncheckLotTypeSelection();

        /*$('#SarinActivityId').on('change', function (e) {*/
        if (sarinActivity === roughPlanning) {
            var result = confirm("All the Tops Parameters will be deleted on Save, if you switch from the Rough to Makeable Planning.");
            if (!result) {
                $('#SarinActivityId').val(previousSarintActivityId);
                return false;
            }
        }

        sarinActivity = $('#SarinActivityId :selected').text();
        if (sarinActivity === makeablePlanning) {
            showElement('#clarityDiv');
            showElement('#makeableOrTopsLotDiv');

            hideElement('#colorRateVersionDiv');
            $('#ColorRateVersionId').val('');
        }
        else if (sarinActivity === roughPlanning || sarinActivity === "Select") {
            $('#ClarityId').val('');
            hideElement('#clarityDiv');
            hideElement('#makeableOrTopsLotDiv');

            if ($('#ColorShadeId').val() !== null) {
                showElement('#colorRateVersionDiv');
            }
        }

        roughSubType = $('#roughSubTypeDropdown').val();
        isRoughPlanning = $('#IsRoughPlannning').val();
        isDisplayRoughSubTypeDdl = $('#IsDisplyRoughSubTypeDdl').val();

        if (roughSubType === "true")
            showElement('#roughSubTypeDiv');

        if (isDisplayRoughSubTypeDdl === "True")
            showElement('#roughSubTypeDiv');

        //if (isDisplayRoughSubTypeDdl === "False" && isRoughPlanning === "True")
        //    showElement('#roughSubTypeDiv');

        if (sarinActivity === roughPlanning && isDisplayRoughSubTypeDdl === "False"
            && isRoughPlanning === "False" && $('#RoughCategoryId option').length > 1)
            showElement('#roughSubTypeDiv');

        manageCustomTopsSectionVisibility();
    });

    $('#SieveSize').on("click", function () {
        $(this).val('');
        $('#SieveSizeId').val('0');
    });

    $('#SieveSize').autocomplete({
        autoFocus: true,
        selectFirst: true,
        source: function (request, response) {
            $.ajax({
                url: "GetSieveSize",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "Active"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { id: item.Id, value: item.Name };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1) {
                $("#SieveSizeId").val('0');
                return false;
            }
            else {
                if (ui.item.val === -1) {
                    $("#SieveSizeId").val('0');
                }
                else {
                    $(this).val(ui.item.value);
                    $("#SieveSizeId").val(ui.item.id);
                }
                if ($('#SieveSizeId').val() === '0' || $('#SieveSizeId').val() === '') {
                    $('#validationError').html("Sieve size is invalid");
                    $(this).css({
                        "border": "1px solid #ff0000",
                        "background": "#fee"
                    });
                    return false;
                }
                else {
                    $('#validationError').html("");
                    $(this).css({
                        "border": "",
                        "background": ""
                    });
                }
            }
        }
    });

    $('#RoughCategoryId').on('change', function (e) {
        $('#RoughCategoryId').css({
            "border": "",
            "background": ""
        });
        $('#validationMsgRoughSType').html('');

    });

    $('.LotAssignDetail_0__AssignedOn').datetimepicker({
        format: 'DD-MMM-YYYY HH:mm',
        //ignoreReadonly: true,
        minDate: moment("02-Sep-2016", "DD-MMM-YYYY")
    });

    $(document).on("click", "div", function () {
        $('.LotAssignDetail_0__AssignedOn').datetimepicker({
            format: 'DD-MMM-YYYY HH:mm',
            //ignoreReadonly: true,
            minDate: moment("02-Sep-2016", "DD-MMM-YYYY")
        });
    });

    $('#btnAddAssign').on("click", function () {
        bindAssignControl(++rowIndex, ++lotAssignIndex);
    });


    $(customTopsQuestionControlQuery).on("change", function () {
        manageStoneTopsDataSectionVisibility();
    });

    // PENDING: On "Add Stone Range Configuration" button click, Add new Section for the Tops Configuration
    //              If any section is with empty values then disable the "Add Stone Range Tops Section" button

    // PENDING: Allow to Delete "Stone Range Configuration Section"

    // PENDING: Validate values Immediately, on leaving "Text Box" or after the Clarity Selection

});

function uncheckLotTypeSelection() {
    const radioControls = document.getElementsByName('IsTopsLot');

    for (let i = 0; i < radioControls.length; i++) {
        if (radioControls[i].checked) {
            radioControls[i].checked = false;
            break;
        }
    }
}

function fetchClarities() {
    clarities = [];

    let clarityDiv = document.getElementById('clarityDiv');
    if (clarityDiv) {
        var dropDownOptions = clarityDiv.querySelector('select[name="ClarityId"]');
        for (let i = 1; i < dropDownOptions.length; i++) {
            clarities.push({ value: dropDownOptions[i].value, text: dropDownOptions[i].text });
        }
    } else {
        let assignedOnElement = document.getElementById('SubRoughAssignedOn');
        if (assignedOnElement && assignedOnElement.value) {
            const assignedOnDate = new Date(document.getElementById('SubRoughAssignedOn').value);
            const asOnDate = `${assignedOnDate.getFullYear()}-${assignedOnDate.getMonth() + 1}-${assignedOnDate.getDate()}`;

            sendRequest("GET", appendURL("Clarity/GetClaritiesAsOnDate"),
                {
                    asOnDate: asOnDate
                }, "application/json; charset=utf-8", "json", (data) => {
                    clarities = [...data.map(c => ({ value: c.Value, text: c.Text }))];
                });
        }
    }
}

function manageCustomTopsSectionVisibility() {

    if (sarinActivity === roughPlanning) {
        showElement('#lotCustomTopsConfiguration');
    }
    else {
        hideElement('#lotCustomTopsConfiguration');
    }

    manageStoneTopsDataSectionVisibility();
}

function manageStoneTopsDataSectionVisibility() {
    if (sarinActivity === roughPlanning) {
        isHaveCustomTopsConfiguration = document.querySelector(customTopsQuestionCheckedQuery)?.value

        if (isHaveCustomTopsConfiguration && isHaveCustomTopsConfiguration === 'True') {
            showElement('#lotStonesTopsConfiguration');
        }
        else {
            hideElement('#lotStonesTopsConfiguration');
        }
    }
}

function validateTopsConfiguration() {
    var topsValidationResult = true;

    // PENDING: Validate the Lots Stones Tops Configurations
    //customTopsQuestionControl = document.querySelector(customTopsQuestionControlQuery);
    //if (customTopsQuestionControl === undefined || customTopsQuestionControl === null) {
    //    topsValidationResult = false;

    //    //changeControlStateToInValid($('#RoughCategoryId'), $('#validationMsgRoughSType'), 'Rough Sub Type is Required');
    //}

    //  1. Does lot has Custom Tops Configuration question is Must be Answered
    //  If Yes then do further validations
    //      a. At least one configuration must be available/specified
    //      b. For the exact Stone Numbers Range, there could not be more than one section for the configuration
    //      c. Stone Number From must be less than Stone Number To in all the entries
    //      d. For a Specific Stone (even it is in different Stone Range) and Clarity,
    //         there must be only Zero or One Tops Cnfiguration (not more than 1)
    //      e. Tops Diameter value could not be less than the Min-Polished Diameter value
    //          But only when the Both values are > 0
    //          And if Min Polished Diam > 0 but the input Tops Diameter Value = 0 then it's valid

    return topsValidationResult;
}

function validateRoughSubType() {
    var IsSelected = false;

    var ddlCount = $('#RoughCategoryId').children('option').length;
    var selectedValue = $('#RoughCategoryId :selected').val();

    if (ddlCount > 1 && (selectedValue === "Select" || selectedValue === "")) {
        changeControlStateToInValid($('#RoughCategoryId'), $('#validationMsgRoughSType'), 'Rough Sub Type is Required');
    }
    else {
        changeControlStateToValid($('#RoughCategoryId'), $('#validationMsgRoughSType'));
        IsSelected = true;
    }
    return IsSelected;

}

function bindAssignControl(rowIndex, lotAssignIndex) {
    var tblAssignedDetail = document.getElementById("tblAssignedDetail");
    var trAssignedDetail = tblAssignedDetail.insertRow(rowIndex);
    var cellAssignedTo = trAssignedDetail.insertCell(0);
    var cellAssignedOn = trAssignedDetail.insertCell(1);
    //attr({ title: "Test", alt: "Test2" });

    cellAssignedTo.innerHTML = $("#AssignedToField")
        .last()
        .clone()
        .find('select').attr({ id: 'LotAssignDetail_' + lotAssignIndex + '__AssignedTo', name: 'LotAssignDetail[' + lotAssignIndex + '].AssignedTo' })
        .parent()
        .find('span').attr('data-valmsg-for', 'LotAssignDetail[' + lotAssignIndex + '].AssignedTo')
        .parent()
        .html();

    cellAssignedOn.innerHTML = $("#AssignedOnField")
        .last().clone()
        .find('input')
        .attr({ id: 'LotAssignDetail_' + lotAssignIndex + '__AssignedOn', name: 'LotAssignDetail[' + lotAssignIndex + '].AssignedOn', value: '' })
        .parent()
        .parent()
        .find('span').attr('data-valmsg-for', 'LotAssignDetail[' + lotAssignIndex + '].AssignedOn')
        .parent()
        .html();
}

function bindIsLotBySize() {
    var isLotBySize = $('#IsLotBySize').val();
    var subRoughId = parseInt($('#SubRoughId').val());

    if (subRoughId > 0 && isLotBySize === "True") {
        showElement("#lotSize");
    }
    else if (subRoughId > 0 && isLotBySize === "False") {
        hideElement("#lotSize");
        $("#btnAddAssign").removeAttr("disabled");
    }
}

function bindColorRateVersionListData(data) {
    var ddlColorRateVersionSelect = $('#ColorRateVersionId');
    ddlColorRateVersionSelect.empty();
    $('<option>', { value: "", text: "Select" }).html("Select").appendTo(ddlColorRateVersionSelect);

    if (data === undefined) {
        return;
    }

    if (data.colorRateVersionData === '') {
        return;
    }

    $.each(data.colorRateVersionData, function (i, data) {
        $('<option>', { value: data.Value, text: data.Text }).html(data.Text).appendTo(ddlColorRateVersionSelect);
    });
}

function bindAssignDetailDBValue() {
    var assignedOperatorCount = parseInt($('#AssignedOperatorCount').val());

    if (assignedOperatorCount > 0) {
        for (var i = 0; i < assignedOperatorCount; i++) {
            var assignedTo = $('#lotAssignedTo_' + i).val();
            var assignedOn = $('#lotAssignedOn_' + i).val();

            $('select#LotAssignDetail_' + i + '__AssignedTo').val(assignedTo);
            $('select#LotAssignDetail_' + i + '__AssignedOn').val(assignedOn);
        }
    }
}

function addStoneRangeTopsSection(elem) {
    var query = `div[id=lotStonesTopsConfiguration]`;
    const lotStoneTopsTableBody = $(elem).closest(query).find('tbody');

    const stoneRangeRows = lotStoneTopsTableBody.find('tr');

    const nextRowIndex = stoneRangeRows.length;
    const idPrefix = `LotStoneTopsParameters_${nextRowIndex}__`;
    const namePrefix = `LotStoneTopsParameters[${nextRowIndex}].`;

    const clonedRow = stoneRangeRows
        .last()
        .clone();

    const stoneRangeNumberCellContent = clonedRow
        .find('td').first()
        .find('input[id$="__LotStoneTopsParameterId"]')
        .attr({ value: 0, id: idPrefix + 'LotStoneTopsParameterId', name: namePrefix + 'LotStoneTopsParameterId' })
        .parent()
        .find('label[for$="StoneNumberFrom"]')
        .attr('for', idPrefix + 'StoneNumberFrom')
        .parent()
        .find('input[id$="StoneNumberFrom"]')
        .attr({ value: '', id: idPrefix + 'StoneNumberFrom', name: namePrefix + 'StoneNumberFrom' })
        .parent()
        .find('label[for$="StoneNumberTo"]')
        .attr('for', idPrefix + 'StoneNumberTo')
        .parent()
        .find('input[id$="StoneNumberTo"]')
        .attr({ value: '', id: idPrefix + 'StoneNumberTo', name: namePrefix + 'StoneNumberTo' })
        .parent()
        .find('button[id^="removeSection_"]')
        .attr({ id: 'removeSection_' + nextRowIndex, onclick: `removeStoneRangeSection(this, ${nextRowIndex})` })
        .parent()
        .find('span[data-valmsg-for$="StoneNumberFrom"]')
        .attr('data-valmsg-for', namePrefix + 'StoneNumberFrom')
        .parent().parent()
        .find('span[data-valmsg-for$="StoneNumberTo"]')
        .attr('data-valmsg-for', namePrefix + 'StoneNumberTo')
        .parent().parent().parent()
        .html();

    clonedRow
        .find('td').last()
        .find('div.stone-tops-control-row')
        .not(':first').remove();

    const stoneTopsParameterCell = clonedRow
        .find('td').last()
        .find('input[id^="addTopsParametersRow_"]')
        .attr({ id: 'addTopsParametersRow_' + nextRowIndex, onclick: `addTopsParametersRow(this, ${nextRowIndex})` })
        .parent().parent()
        .find(`div[id^="stoneRange_Section_"]`)
        .attr({ id: `stoneRange_Section_${nextRowIndex}_TopsData` })
        .parent().parent();

    const topsParameterRow = stoneTopsParameterCell
        .find('div.stone-tops-control-row');

    const topsParameterCellContent = generateTopsParametersRow(topsParameterRow, nextRowIndex, 0)
        .parent().parent().parent()
        .parent().parent().parent()
        .html();

    const newStoneRangeTableRow = $('#tblLotStonesTopsDetail tbody')[0].insertRow();
    var stoneRangeTableCell = newStoneRangeTableRow.insertCell(0);
    stoneRangeTableCell.classList.add('col-sm-6', 'p-0');

    var topsParametersTableCell = newStoneRangeTableRow.insertCell(1);
    topsParametersTableCell.classList.add(['pt-p5r']);

    stoneRangeTableCell.innerHTML = stoneRangeNumberCellContent;
    topsParametersTableCell.innerHTML = topsParameterCellContent;
}

function removeStoneRangeSection(elem, stoneRangeIndex) {
    const closestTableBody = elem.closest('tbody');

    const totalRows = $(closestTableBody).find('tr').length;
    if (totalRows > 0) {
        if (totalRows === 1) {
            alert("Can't remove all the sections. At least one Stone Range section with one Tops parameter row must be there.");
            return;
        }

        $(closestTableBody).find('tr')[stoneRangeIndex].remove();

        shuffleStoneRangeIndexes(closestTableBody);
    }
}
function shuffleStoneRangeIndexes(tableBody) {
    $(tableBody).find('tr').each(function (newIndex) {

        const idPrefix = `LotStoneTopsParameters_${newIndex}__`;
        const namePrefix = `LotStoneTopsParameters[${newIndex}].`;

        $(this)
            .find('td').first()
            .find('input[id$="__LotStoneTopsParameterId"]')
            .attr({ id: idPrefix + 'LotStoneTopsParameterId', name: namePrefix + 'LotStoneTopsParameterId' })
            .parent()
            .find('label[for$="StoneNumberFrom"]')
            .attr('for', idPrefix + 'StoneNumberFrom')
            .parent()
            .find('input[id$="StoneNumberFrom"]')
            .attr({ id: idPrefix + 'StoneNumberFrom', name: namePrefix + 'StoneNumberFrom' })
            .parent()
            .find('label[for$="StoneNumberTo"]')
            .attr('for', idPrefix + 'StoneNumberTo')
            .parent()
            .find('input[id$="StoneNumberTo"]')
            .attr({ id: idPrefix + 'StoneNumberTo', name: namePrefix + 'StoneNumberTo' })
            .parent()
            .find('button[id^="removeSection_"]')
            .attr({ id: 'removeSection_' + newIndex, onclick: `removeStoneRangeSection(this, ${newIndex})` })
            .parent()
            .find('span[data-valmsg-for$="StoneNumberFrom"]')
            .attr('data-valmsg-for', namePrefix + 'StoneNumberFrom')
            .parent().parent()
            .find('span[data-valmsg-for$="StoneNumberTo"]')
            .attr('data-valmsg-for', namePrefix + 'StoneNumberTo');

        $(this)
            .find('td').last()
            .find('input[id^="addTopsParametersRow_"]')
            .attr({ id: 'addTopsParametersRow_' + newIndex, onclick: `addTopsParametersRow(this, ${newIndex})` })
            .parent().parent()
            .find(`div[id^="stoneRange_Section_"]`)
            .attr({ id: `stoneRange_Section_${newIndex}_TopsData` });

        const topsDataSection = $(this)
            .find('td').last()
            .find(`div[id^="stoneRange_Section_"]`);

        shuffleTopsInputRowsIndex(topsDataSection, newIndex, -1);
    });
}

function addTopsParametersRow(elem, stoneRangeIndex) {
    var query = `div[id=stoneRange_Section_${stoneRangeIndex}_TopsData]`;
    const stoneRangeDiv = $(elem).closest('div.stone-tops-row').find(query);

    const stoneTopsControlRowDivs = stoneRangeDiv.find('.stone-tops-control-row');

    const nextDivIndex = stoneTopsControlRowDivs.length;
    if (nextDivIndex > 0) {
        const clarityControls = stoneTopsControlRowDivs.find('select[id$="ClarityId"]')
        if (clarityControls && clarityControls.length > 0) {

            var clarityControl = clarityControls[0];
            const noOfClarities = clarityControl.options.length;

            if (stoneTopsControlRowDivs.length >= noOfClarities) {
                alert(`Total Number of Clarities are: ${noOfClarities}, and for one specific stone range, there could not be more Tops Diameter specifications than the available number of Clarities.`);
                return;
            }
        }
    }

    const topsControlRow = stoneTopsControlRowDivs.last().clone();
    const newTopsControlRowDivContent = generateTopsParametersRow(topsControlRow, stoneRangeIndex, nextDivIndex)
        .parent().parent().parent()
        .html();

    const newTopsControlRowDiv = createDivElement(['stone-tops-control-row']);
    newTopsControlRowDiv.innerHTML = newTopsControlRowDivContent;
    //newTopsControlRowDiv.dataset.id = 0;

    $(query).append(newTopsControlRowDiv);
}

function generateTopsParametersRow(topsControlRow, stoneRangeIndex, nextDivIndex) {
    const idPrefix = `LotStoneTopsParameters_${stoneRangeIndex}__StoneTopsParameters_${nextDivIndex}__`;
    const namePrefix = `LotStoneTopsParameters[${stoneRangeIndex}].StoneTopsParameters[${nextDivIndex}].`;

    return topsControlRow
        /*.attr('data-id', 0)*/
        .find('input[id$="__StoneTopsParameterId"]')
        .attr({ value: 0, id: idPrefix + 'StoneTopsParameterId', name: namePrefix + 'StoneTopsParameterId' })
        .parent()
        .find('select')
        .attr({ id: idPrefix + 'ClarityId', name: namePrefix + 'ClarityId', ariaDescribedby: idPrefix + 'ClarityId-error' })
        .find('option:selected').removeAttr('selected').end()
        .parent().parent()
        .find('input[id$="__TopsDiameter"]')
        .attr({ id: idPrefix + 'TopsDiameter', name: namePrefix + 'TopsDiameter', value: '' })
        .parent().parent()
        .find('button[id^="removeRow_"]')
        .attr({ id: 'removeRow_' + nextDivIndex, onclick: `removeTopsInputRow(this, ${stoneRangeIndex}, ${nextDivIndex})` })
        .parent()
        .find('span[data-valmsg-for$="ClarityId"]')
        .attr('data-valmsg-for', namePrefix + 'ClarityId')
        .parent().parent()
        .find('span[data-valmsg-for$="TopsDiameter"]')
        .attr('data-valmsg-for', namePrefix + 'TopsDiameter');
}

function removeTopsInputRow(elem, stoneRangeIndex, currentRowIndex) {
    const closestTopsDataSection = elem
        .closest('div[id^="stoneRange_Section_"]');

    const totalAvailableRows = $(closestTopsDataSection).find('div.stone-tops-control-row').length;
    if (totalAvailableRows > 0) {
        if (totalAvailableRows === 1) {
            alert("Can't remove all the rows. At least one, Tops parameter row must be there.");
            return;
        }

        $(closestTopsDataSection).find('div.stone-tops-control-row')[currentRowIndex].remove();

        shuffleTopsInputRowsIndex(closestTopsDataSection, stoneRangeIndex);
    }
}

function shuffleTopsInputRowsIndex(topsDataSection, stoneRangeIndex) {

    $(topsDataSection).find('div.stone-tops-control-row').each(function (newIndex) {
        const idPrefix = `LotStoneTopsParameters_${stoneRangeIndex}__StoneTopsParameters_${newIndex}__`;
        const namePrefix = `LotStoneTopsParameters[${stoneRangeIndex}].StoneTopsParameters[${newIndex}].`;

        $(this)
            .find('input[id$="__StoneTopsParameterId"]')
            .attr({ id: idPrefix + 'StoneTopsParameterId', name: namePrefix + 'StoneTopsParameterId' })
            .parent()
            .find('select')
            .attr({ id: idPrefix + 'ClarityId', name: namePrefix + 'ClarityId', ariaDescribedby: idPrefix + 'ClarityId-error' })
            .parent().parent()
            .find('input[id$="__TopsDiameter"]')
            .attr({ id: idPrefix + 'TopsDiameter', name: namePrefix + 'TopsDiameter' })
            .parent().parent()
            .find('button[id^="removeRow_"]')
            .attr({ id: 'removeRow_' + newIndex, onclick: `removeTopsInputRow(this,${stoneRangeIndex}, ${newIndex})` })
            .parent()
            .find('span[data-valmsg-for$="ClarityId"]')
            .attr('data-valmsg-for', namePrefix + 'ClarityId')
            .parent().parent()
            .find('span[data-valmsg-for$="TopsDiameter"]')
            .attr('data-valmsg-for', namePrefix + 'TopsDiameter');
    });
}

function createDivElement(classList) {
    let divElement = document.createElement('div');
    divElement.classList.add(...classList);
    return divElement;
}

