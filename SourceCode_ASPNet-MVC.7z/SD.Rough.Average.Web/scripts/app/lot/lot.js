﻿$(document).ready(function () {
    setControlVisibility(false);
    getLotData();
    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            getLotData();
        }
        else { null; }
    });

    // Btn Search on click
    $('#btnSearch').click(function () {
        setControlVisibility();
        getLotData();
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        setControlVisibility();
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getLotData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });

    $('#RoughColorShadeId').change(function () {
        setControlVisibility();
        getLotData();
    });

    $('#SubRoughTypeId').change(function () {
        setControlVisibility();
        getLotData();
    });

    $('#RoughSizeId').change(function () {
        setControlVisibility();
        getLotData();
    });

    $('#AssignedTo').change(function () {
        setControlVisibility();
        getLotData();
    });

    $('#SarinActivityId').change(function () {
        setControlVisibility();
        getLotData();
    });

    //Autocomplete of SubRoughPieceCount
    $('#SubRoughPieceCount').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SubRough/GetSubRoughPieceCount"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                    //SubRoughWeight: $('#SubRoughWeight').val(),
                    //SubRoughTypeId: $('#SubRoughTypeId').val(),
                    //RoughSizeId: $('#RoughSizeId').val(),
                    //lotWeight: $('#LotWeight').val(),
                    //lotPieceCount: $('#LotPieceCount').val(),
                    //Name: $('#Name').val()
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.PieceCount };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getLotData();
            }
        }
    });

    //Autocomplete of SubRoughWeight
    $('#SubRoughWeight').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SubRough/GetSubRoughWeight"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                    //SubRoughPieceCount: $('#SubRoughPieceCount').val(),
                    //SubRoughTypeId: $('#SubRoughTypeId').val(),
                    //RoughSizeId: $('#RoughSizeId').val(),
                    //lotWeight: $('#LotWeight').val(),
                    //lotPieceCount: $('#LotPieceCount').val(),
                    //Name: $('#Name').val()
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Weight.toFixed(3) };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getLotData();
            }
        }
    });

    //Autocomplete of LotPieceCount
    $('#LotPieceCount').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetLotPieceCount",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                    //SubRoughWeight: $('#SubRoughWeight').val(),
                    //SubRoughPieceCount: $('#SubRoughPieceCount').val(),
                    //SubRoughTypeId: $('#SubRoughTypeId').val(),
                    //RoughSizeId: $('#RoughSizeId').val(),
                    //lotWeight: $('#LotWeight').val(),
                    //Name: $('#Name').val()
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.PieceCount };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getLotData();
            }
        }
    });

    //Autocomplete of LotWeight
    $('#LotWeight').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetLotWeight",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                    //SubRoughWeight: $('#SubRoughWeight').val(),
                    //SubRoughPieceCount: $('#SubRoughPieceCount').val(),
                    //SubRoughTypeId: $('#SubRoughTypeId').val(),
                    //RoughSizeId: $('#RoughSizeId').val(),
                    //lotPieceCount: $('#LotPieceCount').val(),
                    //Name: $('#Name').val()
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Weight.toFixed(3) };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getLotData();
            }
        }
    });

    //Autocomplete of LotName
    $('#Name').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetLotName",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "Active"
                    //SubRoughWeight: $('#SubRoughWeight').val(),
                    //SubRoughPieceCount: $('#SubRoughPieceCount').val(),
                    //SubRoughTypeId: $('#SubRoughTypeId').val(),
                    //RoughSizeId: $('#RoughSizeId').val(),
                    //lotPieceCount: $('#LotPieceCount').val(),
                    //lotWeight: $('#LotWeight').val()
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: '' + item.SizeSign + '' + item.Name + '' };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getLotData();
            }
        }
    });
});

// Function for search and sort Data
function getLotData(sortColumn, sortDirection) {
    var subRoughWeight = $('#SubRoughWeight').val();
    var subRoughPieceCount = $('#SubRoughPieceCount').val();
    var typeId = $('#SubRoughTypeId').val();
    var sizeId = $('#RoughSizeId').val();
    var colorShadeId = $('#RoughColorShadeId').val();
    var lotWeight = $('#LotWeight').val();
    var lotPieceCount = $('#LotPieceCount').val();
    var name = $('#Name').val();
    var sarinActivityId = $('#SarinActivityId').val();
    var clarityId = $('#ClarityId').val();
    var assignedTo = $('#AssignedTo').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }

    sendRequest("GET", "GetLotDetails",
        {
            SubRoughWeight: subRoughWeight,
            SubRoughPieceCount: subRoughPieceCount,
            SubRoughTypeId: typeId,
            RoughSizeId: sizeId,
            RoughColorShadeId: colorShadeId,
            lotWeight: lotWeight,
            lotPieceCount: lotPieceCount,
            Name: name,
            SarinActivityId: sarinActivityId,
            ClarityId: clarityId,
            AssignedTo: assignedTo,
            SortingColumn: sortColumn,
            SortDirection: sortDirection,
            PageSize: pageSize,
            PageNumber: pageNumber
        }, "application/json; charset=utf-8", "json", bindLotData);
}

// Function for Bind lot data 
function bindLotData(data) {
    if (data !== null && data !== "Error") {
        //Assign values to paging variables
        totalPages = data.totalPages;
        totalRecords = data.totalRecords;
        // For DataTable
        var dt = $('#lotTable').DataTable({
            "destroy": true,
            "searching": false,
            "ordering": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '70vh',
            "columnDefs": [
                {
                    targets: [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 1],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.lotDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.lotGridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="Edit?id=' + full.Id + '" title="Edit" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="glyphicon glyphicon-edit"></span></a>';
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="Delete?id=' + full.Id + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate")
                            + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">'
                            + (deleteActivate === "Delete"
                                ? '<span class="glyphicon glyphicon-trash"></span></a>'
                                : '<span class="glyphicon glyphicon-ok"></span>')
                            + '</a>';
                    }
                },
                {
                    "mData": "SubRoughType",
                    "render": function (id, type, full, meta) {
                        return full.SubRoughType !== null ? full.SubRoughType : "-";
                    }
                },
                {
                    "mData": "SubRoughColorShade",
                    "render": function (id, type, full, meta) {
                        return full.SubRoughColorShade !== null ? full.SubRoughColorShade : "-";
                    }
                },
                {
                    "mData": "SubRoughNumber",
                    "render": function (id, type, full, meta) {
                        return full.SubRoughNumber !== null ? full.SubRoughNumber : "-";
                    }
                },
                {
                    "mData": "SubRoughSize",
                    "render": function (id, type, full, meta) {
                        return full.SubRoughSize !== null ? full.SubRoughSize : "-";
                    }
                },
                {
                    "mData": "SubRoughPieceCount"
                },
                {
                    "mData": "SubRoughWeight",
                    "render": function (id, type, full, meta) {
                        return full.SubRoughWeight.toFixed(3);
                    }
                },
                {
                    "mData": "MakeablePieceCount",
                    "render": function (id, type, full, meta) {
                        return full.MakeablePieceCount !== null ? full.MakeablePieceCount : "-";
                    }
                },
                {
                    "mData": "MakeableWeight",
                    "render": function (id, type, full, meta) {
                        return full.MakeableWeight !== null ? full.MakeableWeight.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "MakeableTopsPieces",
                    "render": function (id, type, full, meta) {
                        return full.MakeableTopsPieces !== null ? full.MakeableTopsPieces : "-";
                    }
                },
                {
                    "mData": "MakeableTopsWeight",
                    "render": function (id, type, full, meta) {
                        return full.MakeableTopsWeight !== null ? full.MakeableTopsWeight.toFixed(3) : "-";
                    }
                },               
                {
                    "mData": "LotName",
                    "render": function (id, type, full, meta) {
                        return full.LotName !== null ? full.LotName : "-";
                    }
                },
                {
                    "mData": "LotPieceCount"
                },
                {
                    "mData": "LotWeight",
                    "render": function (id, type, full, meta) {
                        return full.LotWeight.toFixed(3);
                    }
                },
                {
                    "mData": "ColorShade",
                    "render": function (id, type, full, meta) {
                        return full.ColorShade !== null ? full.ColorShade +
                            (full.ColorRateVersion !== null ? "(" + full.ColorRateVersion + ")" : "") : "-";
                    }
                },
                {
                    "mData": "SarinActivity",
                    "render": function (id, type, full, meta) {
                        return full.IsTopsLot ? full.SarinActivity + '(Tops)' : full.SarinActivity;
                    }
                },
                {
                    "mData": "Clarity",
                    "render": function (id, type, full, meta) {
                        return full.Clarity !== null ? full.Clarity : "-";
                    }
                },
                {
                    "mData": "RoughSubType",
                    "render": function (id, type, full, meta) {
                        return full.RoughSubType !== null ? full.RoughSubType : "-";
                    }
                },
                {
                    "mData": "AssignedTo",
                    "render": function (id, type, full, meta) {
                        var startul = "<ul>";
                        var closeul = "</ul>";
                        var startli = "<li>";
                        var closeli = "</li>";
                        var assignedTo = "";
                        if (full.AssignedTo !== null) {
                            for (var i = 0; i < full.AssignedTo.length; i++) {

                                assignedTo = assignedTo + startli + full.AssignedTo[i] + closeli;
                            }
                        }
                        else
                            assignedTo = startli + "-" + closeli;

                        return startul + assignedTo + closeul;
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });

        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}