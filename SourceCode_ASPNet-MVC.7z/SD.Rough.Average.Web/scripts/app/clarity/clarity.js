﻿$(document).ready(function () {
    setControlVisibility(false);
    getClarityData();

    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            getClarityData();

            e.preventDefault();
        }
        else { null; }
    });

    $('#EntryStatus').on('change', function (e) {
        setControlVisibility();
        getClarityData();
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        setControlVisibility();
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getClarityData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });

    // Btn Search on click
    $('#btnSearch').click(function () {
        setControlVisibility();
        getClarityData();
    });

    //Autocomplete of Name
    $('#Name').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("Clarity/GetClarityNames"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Name };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getClarityData();
            }
        }
    });

    //Autocomplete of Group Name
    $('#GroupName').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("Clarity/GetClarityGroupNames"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.GroupName };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getClarityData();
            }
        }
    });
});

function getClarityData(sortColumn, sortDirection) {
    var name = $('#Name').val();
    var groupName = $('#GroupName').val();
    var entryStatus = $('#EntryStatus :selected').val();
    var dateFrom = $('#EffectiveFromStartDate').val();
    var dateTo = $('#EffectiveFromEndDate').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }
    sendRequest("GET", "GetClarityDetails",
        {
            Name: name,
            GroupName: groupName,
            EntryStatus: entryStatus,
            EffectiveFromStartDate: dateFrom,
            EffectiveFromEndDate: dateTo,
            SortColumn: sortColumn,
            SortDirection: sortDirection,
            PageSize: pageSize,
            PageNumber: pageNumber
        }, "application/json; charset=utf-8", "json", bindClarityData);
}

function bindClarityData(data) {
    if (data !== null && data !== "Error") {

        totalPages = data.totalPages;
        totalRecords = data.totalRecords;

        var dt = $('#clarityTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '51vh',
            "columnDefs": [
                {
                    targets: [3, 4, 6, 8],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 9],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.clarityDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="Edit?clarityId=' + full.Id + '" title="Edit" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="glyphicon glyphicon-edit"></span>' +
                            '</a>';
                    }
                },
                {
                    "mData": "Name"
                },
                {
                    "mData": "GroupName"
                },
                {
                    "mData": "DisplayOrder"
                },
                {
                    "mData": "EffectiveFrom"
                },
                {
                    "mData": "CreatedBy"
                },
                {
                    "mData": "CreatedOn"
                },
                {
                    "mData": "ModifiedBy",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedBy !== null ? full.ModifiedBy : "-";
                    }
                },
                {
                    "mData": "ModifiedOn",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedOn !== null ? full.ModifiedOn : "-";
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="Delete?clarityId=' + full.Id + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate") + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            (deleteActivate === "Delete" ? '<span class="glyphicon glyphicon-trash"></span></a>' : '<span class="glyphicon glyphicon-ok"></span>') +
                            '</a>';
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });
        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}