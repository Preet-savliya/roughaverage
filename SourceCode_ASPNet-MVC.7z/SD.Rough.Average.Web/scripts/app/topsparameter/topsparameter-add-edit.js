﻿$(document).ready(function () {
    $('#MinSieveSize').change(function () {
        if ($(this).val() === '') {
            $('#MinSieveSizeId').val('');
        }
    });

    $('#MaxSieveSize').change(function () {
        if ($(this).val() === '') {
            $('#MaxSieveSizeId').val('');
        }
    });

    $('#ParentSize').change(function () {
        if ($(this).val() === '') {
            $('#ParentId').val('');
        }
    });

    //Autocomplete of Min Sieve Size
    $('#MinSieveSize').autocomplete({
        autoFocus: true,
        selectFirst: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SieveSize/GetSieveSizeName"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "Active"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { id: item.Id, value: item.Name };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1) {
                $("#MinSieveSizeId").val('');
                return false;
            }
            else {
                if (ui.item.val === -1) {
                    $("#MinSieveSizeId").val('');
                }
                else {
                    $(this).val(ui.item.value);
                    $("#MinSieveSizeId").val(ui.item.id);
                }
            }
        }
    });

    //Autocomplete of Max Sieve Size
    $('#MaxSieveSize').autocomplete({
        autoFocus: true,
        selectFirst: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SieveSize/GetSieveSizeName"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "Active"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { id: item.Id, value: item.Name };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1) {
                $("#MaxSieveSizeId").val('');
                return false;
            }
            else {
                if (ui.item.val === -1) {
                    $("#MaxSieveSizeId").val('');
                }
                else {
                    $(this).val(ui.item.value);
                    $("#MaxSieveSizeId").val(ui.item.id);
                }
            }
        }
    });

    $('#ParentSize').focus(function () {
        var isValid = true;

        var effectiveFrom = $("#EffectiveFrom").val();
        if (effectiveFrom === '') {
            $('#EffectiveFrom').addClass('control-empty');
            $('#effectiveDateInputError').html('Effective Date is required');
            isValid = false;
        }
        else {
            $('#EffectiveFrom').removeClass('control-empty');
            $('#effectiveDateInputError').html('');
            isValid = true;

            //Autocomplete of Name
            $('#ParentSize').autocomplete({
                autoFocus: true,
                selectFirst: true,
                source: function (request, response) {
                    $.ajax({
                        url: "GetTopsSizeNames",
                        type: "GET",
                        dataType: "json",
                        data: {
                            prefix: request.term,
                            asOnDate: effectiveFrom,
                        },
                        contentType: "application/json; charset=utf-8",
                        success: function (data) {
                            if (data.length > 0) {
                                response($.map(data, function (item) {
                                    return { id: item.Id, value: item.Name };
                                }));
                            }
                            else
                                response([{ label: noResultFoundText, val: -1 }]);
                        },
                        error: function (props, errorThrown) {
                            ajaxError(props, errorThrown);
                        }
                    });
                },
                select: function (event, ui) {
                    if (ui.item.val === -1) {
                        $("#ParentId").val('');
                        return false;
                    }
                    else {
                        if (ui.item.val === -1) {
                            $("#ParentId").val('');
                        }
                        else {
                            $(this).val(ui.item.value);
                            $("#ParentId").val(ui.item.id);
                        }
                    }
                }
            });
        }
    });
});