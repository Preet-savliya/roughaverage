﻿$(document).ready(function () {
    // Click event for loading 
    $('.loadingProcess').click(function () {
        showElement('.loadingDiv');
    });

});