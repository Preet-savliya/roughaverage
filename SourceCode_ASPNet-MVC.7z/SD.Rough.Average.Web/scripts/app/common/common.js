﻿var sarinActivity = null;
var isDisplayRate = false;
var noResultFoundText = 'No result(s) found.';
var baseUrl = '';

$(function () {

    // DatePicker
    $(function () {
        $('.datepicker').datepicker({
            dateFormat: "dd-M-yy",
            changeMonth: true,
            changeYear: true,
            //minDate: "02-Sep-2016",
            maxDate: new Date()
        });
    });

    //AssignedOn date and time picker of SubRough
    $(function () {
        $('#SubRough_AssignedOn').datetimepicker({
            format: 'DD-MMM-YYYY HH:mm',
            //ignoreReadonly: true,
            minDate: moment("02-Sep-2016", "DD-MMM-YYYY")
        });
    });

    $(function () {
        $('#EffectiveFrom').datetimepicker({
            format: 'DD-MMM-YYYY',
            //ignoreReadonly: true,
            minDate: moment("02-Sep-2016", "DD-MMM-YYYY")
        });
    });

    //Radio Button for RoughCategory Rough Type Add/Edit
    $(function () {
        var behaveSeparately = $('.BehaveSeparately').attr('checked');

        $('.BehaveSeparately').click(function () {
            if (behaveSeparately) {
                $(this).removeAttr('checked');
            }
            behaveSeparately = $(this).prop('checked');
        });

        var notBehaveSeparately = $('.NotBehaveSeparately').attr('checked');

        $('.NotBehaveSeparately').click(function () {
            if (notBehaveSeparately) {
                $(this).removeAttr('checked');
            }
            notBehaveSeparately = $(this).prop('checked');
        });
    });
});

function appendURL(url) {
    let applicationName = (!appName || appName === "") ? "" : ("/" + appName);

    if (!baseUrl || baseUrl === '') {
        baseUrl = document.location.origin + applicationName + "/";
    }

    return baseUrl + url;
}

// Function for blink text effect 
function blinkText(selector) {
    $(selector).fadeOut('slow', function () {
        $(this).fadeIn('slow', function () {
            blinkText(this);
        }).delay(300);
    });
}

function showElement(element) {
    $(element).show();
}

function hideElement(element) {
    $(element).hide();
}

function changeControlStateToValid(htmlControl, errorMessageControl) {
    errorMessageControl.html('');

    htmlControl.css({
        "border": "",
        "background": ""
    });
}

function changeControlStateToInValid(htmlControl, errorMessageControl, errorMessage) {
    errorMessageControl.html(errorMessage);

    htmlControl.css({
        "border": "1px solid #ff0000",
        "background": "#fee"
    });
}

function setControlVisibility(hideAlert = true) {
    if (hideAlert) {
        hideElement('.alertDetail');
    }
    showElement('.loadingDiv');
}

function sendRequest(type, url, data, contentType, dataType, callBackFunction, processData) {
    $.ajax({
        type: type,
        url: url,
        data: data,
        contentType: contentType,
        dataType: dataType,
        processData: processData,
        success: function (data) {
            callBackFunction(data);
        }
        , error: function (props, errorThrown) {
            ajaxError(props, errorThrown);
        }
    });
}

function getSelectedValueOfRadioControl(elementName) {
    let selectedValue = null;
    const radioControls = document.getElementsByName(elementName);

    for (let i = 0; i < radioControls.length; i++) {
        if (radioControls[i].checked) {
            selectedValue = radioControls[i].value;
            break;
        }
    }
    return selectedValue;
}

// Function for Bind lot dropdown list
function bindLotDdl(data) {
    var ddlLotSelect = $('#LotId');
    ddlLotSelect.empty();
    $('<option>', { value: "0", text: "Select" }).html("Select").appendTo(ddlLotSelect);

    if (data && data.ddlLotDetail && data.ddlLotDetail.length > 0) {
        $.each(data.ddlLotDetail, function (i, data) {
            $('<option>', { value: data.Value, text: data.Text }).html(data.Text).appendTo(ddlLotSelect);
        });
    }
    hideElement('.loadingDiv');
}

// Function for Manage paging button visibility
function managePagingButtonsVisibility(totalRecord, totalPages) {
    currentPage = parseInt($('#pageNumber').val());
    if (isNaN(currentPage) || currentPage === 0) {
        currentPage = 1;
        $('#pageNumber').val(currentPage);
    }
    $('#btnFirstPage').addClass('disable');
    $('#btnPreviousPage').addClass('disable');
    $('#btnNextPage').addClass('disable');
    $('#btnLastPage').addClass('disable');

    if (totalRecord > 0) {
        if (currentPage > 1) {
            $('#btnFirstPage').removeClass('disable');
            $('#btnPreviousPage').removeClass('disable');
        }
        if (currentPage < totalPages) {
            $('#btnNextPage').removeClass('disable');
            $('#btnLastPage').removeClass('disable');
        }
    }
}

// Function for sorting (ascending or descending)
function setGridSortingStyles(control, th, sortDirection) {
    //Remove css class
    control.removeClass(sortDirection === "Ascending" ? "Ascending" : "Descending");

    var regEx = new RegExp("(sort_asc|sort_desc)");
    th.siblings().removeClass(function (index, css) {
        return (css.match(regEx) || []).join(' ');
    });
    th.removeClass("sort_asc sort_desc");

    //Add css class
    sortDirection = sortDirection === "Ascending" ? "Descending" : "Ascending";
    control.addClass(sortDirection);
    th.addClass(sortDirection === "Ascending" ? "sort_desc" : "sort_asc");
}

// Function for confirm delete
function confirmDeleteActivate(isDelete) {
    var message = "Are you sure, you want to" + (isDelete ? " delete " : " activate ") + "this entry" + "?";
    var result = confirm(message);

    if (result) {
        showElement('.loadingDiv');
    }
    return result;
}

// Function for PrintAverage Both
function printAverage(id) {
    var printActionURL = null;
    sarinActivity = $('.tab-content .mainTab.active').attr('name');
    isDisplayRate = $('#IsDisplayRate').is(':checked');
    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "Print?id=" + id + "&sarinActivity=" + sarinActivity + "&isDisplayRate=" + isDisplayRate;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "Print?id=" + id + "&sarinActivity=" + sarinActivity + "&isDisplayRate=" + isDisplayRate;

    window.open(printActionURL, '_blank');
}

// Function for Print RoughPlanning average
function printRoughAverage(id) {
    var printActionURL = null;
    sarinActivity = $('.tab-content').find('.active').attr('name');
    isDisplayRate = $('#IsDisplayRate').is(':checked');

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintRough?id=" + id + "&sarinActivity=" + sarinActivity + "&isDisplayRate=" + isDisplayRate;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintRough?id=" + id + "&sarinActivity=" + sarinActivity + "&isDisplayRate=" + isDisplayRate;

    window.open(printActionURL, '_blank');
}

// Function for Print MakeablePlanning average
function printMakeableAverage(id) {
    var printActionURL = null;
    sarinActivity = $('.tab-content').find('.active').attr('name');
    isDisplayRate = $('#IsDisplayRate').is(':checked');

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintMakeable?id=" + id + "&sarinActivity=" + sarinActivity + "&isDisplayRate=" + isDisplayRate;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintMakeable?id=" + id + "&sarinActivity=" + sarinActivity + "&isDisplayRate=" + isDisplayRate;

    window.open(printActionURL, '_blank');
}

// Function for Print Rough Clarity average
function printClarityRoughAverage(id, isPrintSubRoughDetail) {
    var printActionURL = null;
    sarinActivity = $('.tab-content .mainTab.active').attr('name');
    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintClarityRough?id=" + id + "&isPrintSubRoughDetail=" + isPrintSubRoughDetail + "&sarinActivity=" + sarinActivity;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintClarityRough?id=" + id + "&isPrintSubRoughDetail=" + isPrintSubRoughDetail + "&sarinActivity=" + sarinActivity;

    window.open(printActionURL, '_blank');
}

// Function for Print Makeable Clarity average
function printClarityMakeableAverage(id, isPrintSubRoughDetail) {
    var printActionURL = null;
    sarinActivity = $('.tab-content .mainTab.active').attr('name');

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintClarityMakeable?id=" + id + "&isPrintSubRoughDetail=" + isPrintSubRoughDetail + "&sarinActivity=" + sarinActivity;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintClarityMakeable?id=" + id + "&isPrintSubRoughDetail=" + isPrintSubRoughDetail + "&sarinActivity=" + sarinActivity;

    window.open(printActionURL, '_blank');
}

// Function for Print Size Rough average
function printSizeRoughAverage(id) {
    var printActionURL = null;
    sarinActivity = $('.tab-content').find('.active').attr('name');

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintSizeRough?id=" + id + "&sarinActivity=" + sarinActivity;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintSizeRough?id=" + id + "&sarinActivity=" + sarinActivity;

    window.open(printActionURL, '_blank');
}

// Function for Print Size Makeable average
function printSizeMakeableAverage(id) {
    var printActionURL = null;
    sarinActivity = $('.tab-content').find('.active').attr('name');

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintSizeMakeable?id=" + id + "&sarinActivity=" + sarinActivity;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintSizeMakeable?id=" + id + "&sarinActivity=" + sarinActivity;

    window.open(printActionURL, '_blank');
}

// Function for Print Size and Clarity Rough average
function printSizeClarityRoughAverage(id) {
    var printActionURL = null;
    sarinActivity = $('.tab-content').find('.active').attr('name');

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintSizeClarityRough?id=" + id + "&sarinActivity=" + sarinActivity + "&groupName=" + groupName;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintSizeClarityRough?id=" + id + "&sarinActivity=" + sarinActivity + "&groupName=" + groupName;

    window.open(printActionURL, '_blank');
}

// Function for Print Size and Clarity Makeable average
function printSizeClarityMakeableAverage(id, sarinActivity, groupName) {
    var printActionURL = null;

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintSizeClarityMakeable?id=" + id + "&sarinActivity=" + sarinActivity + "&groupName=" + groupName;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintSizeClarityMakeable?id=" + id + "&sarinActivity=" + sarinActivity + "&groupName=" + groupName;

    window.open(printActionURL, '_blank');
}

// Function for Print Lot Size Rough average
function printLotSizeRoughAverage(id, isCombineReport, sarinActivity) {
    var printActionURL = null;

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintLotSizeRough?id=" + id + "&isCombineReport=" + isCombineReport + "&sarinActivity=" + sarinActivity;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintLotSizeRough?id=" + id + "&isCombineReport=" + isCombineReport + "&sarinActivity=" + sarinActivity;

    window.open(printActionURL, '_blank');
}

// Function for Print Lot Size Makeable average
function printLotSizeMakeableAverage(id, isCombineReport, sarinActivity) {
    var printActionURL = null;

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintLotSizeMakeable?id=" + id + "&sarinActivity=" + sarinActivity + "&isCombineReport=" + isCombineReport;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintLotSizeMakeable?id=" + id + "&sarinActivity=" + sarinActivity + "&isCombineReport=" + isCombineReport;

    window.open(printActionURL, '_blank');
}

// Function for Print Tops Size Rough average
function printTopsReport(id) {
    var printActionURL = null;
    sarinActivity = $('.tab-content').find('.active').attr('name');

    if (window.location.pathname.endsWith("Details")) {
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintTopsSize?id=" + id + "&sarinActivity=" + sarinActivity;
    }
    else if (window.location.pathname.endsWith("Index")) {
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintTopsSize?id=" + id + "&sarinActivity=" + sarinActivity;
    }

    window.open(printActionURL, '_blank');
}

function printSticker(id) {
    var printActionURL = null;

    if (window.location.pathname.endsWith("Details"))
        printActionURL = window.location.origin + window.location.pathname.split('Details')[0] + "PrintSticker?id=" + id;
    else if (window.location.pathname.endsWith("Index"))
        printActionURL = window.location.origin + window.location.pathname.split('Index')[0] + "PrintSticker?id=" + id;

    window.open(printActionURL, '_blank');
}

