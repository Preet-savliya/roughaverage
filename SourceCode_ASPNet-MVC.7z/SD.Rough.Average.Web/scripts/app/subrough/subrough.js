﻿$(document).ready(function () {
    setControlVisibility(false);
    getSubRoughData();

    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            getSubRoughData();
        }
        else { null; }
    });

    // Btn Search on click
    $('#btnSearch').click(function () {
        setControlVisibility();
        getSubRoughData();
    });

    $('#RoughSizeId').change(function () {
        setControlVisibility();
        getSubRoughData();
    });

    $('#RoughColorShadeId').change(function () {
        setControlVisibility();
        getSubRoughData();
    });

    $('#RoughTypeId').change(function () {
        setControlVisibility();
        getSubRoughData();
    });

    $('#ManagerId').change(function () {
        setControlVisibility();
        getSubRoughData();
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        setControlVisibility();
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getSubRoughData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });

    //Autocomplete of SubRoughWeight
    $('#Weight').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetSubRoughWeight",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                    /*    PieceCount: $('#PieceCount').val(),
                        RoughTypeId: $('#RoughTypeId').val(),
                        RoughColorShadeId: $('#RoughColorShadeId').val(),
                        Number: $('#Number').val(),
                        RoughSizeId: $('#RoughSizeId').val(),
                        ManagerId: $('#ManagerId').val(),
                        SubRoughDateFrom: $('#SubRoughDateFrom').val(),
                        SubRoughDateTo: $('#SubRoughDateTo').val()*/
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Weight.toFixed(3) };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getSubRoughData();
            }
        }
    });

    //Autocomplete of SubRoughPieceCount
    $('#PieceCount').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetSubRoughPieceCount",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                    /*  Weight: $('#Weight').val(),
                      RoughTypeId: $('#RoughTypeId').val(),
                      RoughColorShadeId: $('#RoughColorShadeId').val(),
                      Number: $('#Number').val(),
                      RoughSizeId: $('#RoughSizeId').val(),
                      ManagerId: $('#ManagerId').val(),
                      SubRoughDateFrom: $('#SubRoughDateFrom').val(),
                      SubRoughDateTo: $('#SubRoughDateTo').val()*/
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.PieceCount };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getSubRoughData();
            }
        }
    });

    //Autocomplete of CutNumber
    $('#Number').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetCutNumber",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                    /* Weight: $('#Weight').val(),
                     PieceCount: $('#PieceCount').val(),
                     RoughTypeId: $('#RoughTypeId').val(),
                     RoughColorShadeId: $('#RoughColorShadeId').val(),
                     RoughSizeId: $('#RoughSizeId').val(),
                     ManagerId: $('#ManagerId').val(),
                     SubRoughDateFrom: $('#SubRoughDateFrom').val(),
                     SubRoughDateTo: $('#SubRoughDateTo').val()*/
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Number };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getSubRoughData();
            }
        }
    });

    //Autocomplete of Tops
    $('#TopsPolishedDiameter').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetTopsPolishedDiameter",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.TopsPolishedDiameter.toFixed(3) };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getSubRoughData();
            }
        }
    });
});

function getSubRoughData(sortColumn, sortDirection) {
    var weight = $('#Weight').val();
    var pieceCount = $('#PieceCount').val();
    var topsPolishedDiameter = $('#TopsPolishedDiameter').val();
    var roughTypeId = $('#RoughTypeId').val();
    var roughColorShadeId = $('#RoughColorShadeId').val();
    var number = $('#Number').val();
    var roughSizeId = $('#RoughSizeId').val();
    var managerId = $('#ManagerId').val();
    var dateFrom = $('#SubRoughDateFrom').val();
    var dateTo = $('#SubRoughDateTo').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }

    sendRequest("GET", "GetSubRoughDetails",
        {
            Weight: weight,
            PieceCount: pieceCount,
            TopsPolishedDiameter: topsPolishedDiameter,
            RoughTypeId: roughTypeId,
            RoughColorShadeId: roughColorShadeId,
            Number: number,
            RoughSizeId: roughSizeId,
            ManagerId: managerId,
            SubRoughDateFrom: dateFrom,
            SubRoughDateTo: dateTo,
            SortColumn: sortColumn,
            SortDirection: sortDirection,
            PageSize: pageSize,
            PageNumber: pageNumber
        }, "application/json; charset=utf-8", "json", bindSubRoughData);
}

function bindSubRoughData(data) {
    if (data !== null && data !== "Error") {
        totalPages = data.totalPages;
        totalRecords = data.totalRecords;

        var dt = $('#subRoughTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '65vh',
            "columnDefs": [
                {
                    targets: [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 1, 2, 3, 18],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.subRoughDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="Edit?id=' + full.Id + '" title="Edit" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="glyphicon glyphicon-edit"></span>' +
                            '</a>';
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="Delete?id=' + full.Id + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate") + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            (deleteActivate === "Delete" ? '<span class="glyphicon glyphicon-trash"></span></a>' : '<span class="glyphicon glyphicon-ok"></span>') +
                            '</a>';
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        const disabledCssClass = full.MakeablePieceCount != null && full.MakeableWeight != null
                            ? ' disabled-control' : '';

                        return '<a href="AddMakeableEntry?subRoughId=' + full.Id
                            + '" title="Add Makeable Entry" class="loadingProcess btn-edit' + disabledCssClass + '">'
                            + '<span class="glyphicon glyphicon-plus"></span></a>';
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        const disabledCssClass = full.MakeableTopsPieces != null && full.MakeableTopsWeight != null
                            ? ' disabled-control' : '';

                        return '<a href="AddMakeableTopsEntry?subRoughId='
                            + full.Id
                            + '" title="Add Tops Entry" class="loadingProcess btn-edit' + disabledCssClass +'">'
                            + '<span class="glyphicon glyphicon-triangle-top"></span></a>';
                    }
                },
                {
                    "mData": "RoughType"
                },
                {
                    "mData": "RoughColorShade",
                    "render": function (id, type, full, meta) {
                        return full.RoughColorShade !== null ? full.RoughColorShade : "-";
                    }
                },
                {
                    "mData": "Number",
                    "render": function (id, type, full, meta) {
                        return full.Number !== null ? full.Number : "-";
                    }
                },
                {
                    "mData": "RoughSize",
                    "render": function (id, type, full, meta) {
                        return full.RoughSize !== null ? full.RoughSize : "-";
                    }
                },
                {
                    "mData": "PieceCount"
                },
                {
                    "mData": "Weight",
                    "render": function (id, type, full, meta) {
                        return full.Weight.toFixed(3);
                    }
                },
                {
                    "mData": "MakeablePieceCount",
                    "render": function (id, type, full, meta) {
                        return full.MakeablePieceCount !== null ? full.MakeablePieceCount : "-";
                    }
                },
                {
                    "mData": "MakeableWeight",
                    "render": function (id, type, full, meta) {
                        return full.MakeableWeight !== null ? full.MakeableWeight.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "MakeableTopsPieces",
                    "render": function (id, type, full, meta) {
                        return full.MakeableTopsPieces !== null ? full.MakeableTopsPieces : "-";
                    }
                },
                {
                    "mData": "MakeableTopsWeight",
                    "render": function (id, type, full, meta) {
                        return full.MakeableTopsWeight !== null ? full.MakeableTopsWeight.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "RoughTopsPolishedDiameter",
                    "render": function (id, type, full, meta) {
                        return full.RoughTopsPolishedDiameter.toFixed(3);
                    }
                },
                {
                    "mData": "RoughMinPolishedDiameter",
                    "render": function (id, type, full, meta) {
                        return full.RoughMinPolishedDiameter.toFixed(3);
                    }
                },
                {
                    "mData": "MakeableTopsPolishedDiameter",
                    "render": function (id, type, full, meta) {
                        return full.MakeableTopsPolishedDiameter !== null ? full.MakeableTopsPolishedDiameter.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "MakeableMinPolishedDiameter",
                    "render": function (id, type, full, meta) {
                        return full.MakeableMinPolishedDiameter !== null ? full.MakeableMinPolishedDiameter.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "IsLotBySize",
                    "render": function (id, type, full, meta) {
                        var isLotBySize = null;
                        if (full.IsLotBySize) {
                            isLotBySize = "<span class=\"glyphicon glyphicon-ok\"></span>"
                        }
                        else {
                            isLotBySize = ""
                        }
                        return isLotBySize;
                    }
                },
                {
                    "mData": "AssignedOn",
                    "render": function (id, type, full, meta) {
                        return full.AssignedOn;
                    }
                },
                {
                    "mData": "Manager"
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });
        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}