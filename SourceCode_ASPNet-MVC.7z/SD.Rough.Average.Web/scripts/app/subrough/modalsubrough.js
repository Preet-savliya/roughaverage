﻿$(document).ready(function () {

    //Call the function for blink text in SubRough Modal
    blinkText('#blinkText');

    // On Modal open clear Paging info
    $('.modal').on('show.bs.modal', function () {
        $('#ddlPageSize').val('10');
        $('#btnFirstPage').addClass('disable');
        $('#btnPreviousPage').addClass('disable');
        $('#btnNextPage').addClass('disable');
        $('#btnLastPage').addClass('disable');
        $('#totalPages').html('1');
        $('#minPageIndex').html('0');
        $('#maxPageIndex').html('0');
        $('#totalRecords').html('0');
    });

    // On modal close clear all the value
    $('.modal').on('hidden.bs.modal', function () {
        $("#SubRoughPieceCount").val('');
        $("#SubRoughWeight").val('');
        $("#TopsPolishedDiameter").val('');
        $("#RoughTypeId").val('');
        $("#RoughColorShadeId").val('');
        $("#RoughSizeId").val('');
        $("#ManagerId").val('');
        $("#Number").val('');
        $('#modalSubRough tbody tr').remove();
    });

    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            getSubRoughData();
            return false;
        }
        return null;
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getSubRoughData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('#SubRoughPieceCount,#SubRoughWeight,#Number,#TopsPolishedDiameter').click(function () {
        $(this).val('');
    });

    //On change event of RoughType
    $('#RoughTypeId').on('change', function (e) {
        getSubRoughData();
    });

    //On change event of RoughColorShade
    $('#RoughColorShadeId').on('change', function (e) {
        getSubRoughData();
    });

    //On change event of RoughSize
    $('#RoughSizeId').on('change', function (e) {
        getSubRoughData();
    });

    //On change event of Manager
    $('#ManagerId').on('change', function (e) {
        getSubRoughData();
    });

    //Autocomplete of SubRoughWeight
    $('#SubRoughWeight').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SubRough/GetSubRoughWeight"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "Active"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Weight.toFixed(3) };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                getSubRoughData();
            }
        }
    });

    //Autocomplete of SubRoughPieceCount
    $('#SubRoughPieceCount').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SubRough/GetSubRoughPieceCount"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "Active"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.PieceCount };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                getSubRoughData();
            }
        }
    });

    //Autocomplete of CutNumber
    $('#Number').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SubRough/GetCutNumber"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "Active"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Number };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                getSubRoughData();
            }
        }
    });

    //Autocomplete of Tops
    $('#TopsPolishedDiameter').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SubRough/GetTopsPolishedDiameter"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "Active"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.TopsPolishedDiameter.toFixed(3) };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                getSubRoughData();
            }
        }
    });
});

function getSubRoughData(sortColumn, sortDirection) {
    showElement('.loadingDiv');
    var weight = $('#SubRoughWeight').val();
    var pieceCount = $('#SubRoughPieceCount').val();
    var topsPolishedDiameter = $('#TopsPolishedDiameter').val();
    var roughTypeId = $('#RoughTypeId').val();
    var roughColorShadeId = $('#RoughColorShadeId').val();
    var number = $('#Number').val();
    var roughSizeId = $('#RoughSizeId').val();
    var managerId = $('#ManagerId').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    sendRequest("GET", appendURL("SubRough/GetSubRoughDetails"),
        {
            Weight: weight,
            PieceCount: pieceCount,
            TopsPolishedDiameter: topsPolishedDiameter,
            RoughTypeId: roughTypeId,
            RoughColorShadeId: roughColorShadeId,
            Number: number,
            RoughSizeId: roughSizeId,
            ManagerId: managerId,
            SortColumn: sortColumn,
            SortDirection: sortDirection,
            PageSize: pageSize,
            PageNumber: pageNumber,
            IsDisplayAll: false,
            IsActive: true
        }, "application/json; charset=utf-8", "json", bindSubRoughData);
}

function bindSubRoughData(data) {
    if (data !== null && data !== "Error" && data.subRoughDetails.length > 0) {

        totalPages = data.totalPages;
        totalRecords = data.totalRecords;

        var dt = $('#modalSubRough').DataTable({
            "destroy": true,
            "searching": false,
            "ordering": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": "43vh",
            "columnDefs": [
                {
                    targets: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13],
                    className: 'dt-body-right'
                }
            ],
            "aaData": data.subRoughDetails,
            "aoColumns": [
                {
                    "mData": "RoughType"
                },
                {
                    "mData": "RoughColorShade",
                    "render": function (id, type, full, meta) {
                        return full.RoughColorShade !== null ? full.RoughColorShade : "-";
                    }
                },
                {
                    "mData": "Number",
                    "render": function (id, type, full, meta) {
                        return full.Number !== null ? full.Number : "-";
                    }
                },
                {
                    "mData": "RoughSize",
                    "render": function (id, type, full, meta) {
                        return full.RoughSize !== null ? full.RoughSize : "-";
                    }
                },
                {
                    "mData": "PieceCount"
                },
                {
                    "mData": "Weight",
                    "render": function (id, type, full, meta) {
                        return full.Weight.toFixed(3);
                    }
                },
                {
                    "mData": "MakeablePieceCount",
                    "render": function (id, type, full, meta) {
                        return full.MakeablePieceCount !== null ? full.MakeablePieceCount : "-";
                    }
                },
                {
                    "mData": "MakeableWeight",
                    "render": function (id, type, full, meta) {
                        return full.MakeableWeight !== null ? full.MakeableWeight.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "MakeableTopsPieces",
                    "render": function (id, type, full, meta) {
                        return full.MakeableTopsPieces !== null ? full.MakeableTopsPieces : "-";
                    }
                },
                {
                    "mData": "MakeableTopsWeight",
                    "render": function (id, type, full, meta) {
                        return full.MakeableTopsWeight !== null ? full.MakeableTopsWeight.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "RoughTopsPolishedDiameter",
                    "render": function (id, type, full, meta) {
                        return full.RoughTopsPolishedDiameter.toFixed(3); //!== null ? full.Tops.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "RoughMinPolishedDiameter",
                    "render": function (id, type, full, meta) {
                        return full.RoughMinPolishedDiameter.toFixed(3);
                    }
                },
                {
                    "mData": "MakeableTopsPolishedDiameter",
                    "render": function (id, type, full, meta) {
                        return full.MakeableTopsPolishedDiameter !== null ? full.MakeableTopsPolishedDiameter.toFixed(3) : "-"; //!== null ? full.Tops.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "MakeableMinPolishedDiameter",
                    "render": function (id, type, full, meta) {
                        return full.MakeableMinPolishedDiameter !== null ? full.MakeableMinPolishedDiameter.toFixed(3) : "-";
                    }
                },
                {
                    "mData": "AssignedOn"
                },
                {
                    "mData": "Manager"
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                $(nRow).addClass('cursor');
                $(nRow).click(function () {
                    $('#SubRoughId').val(aData.Id);
                    $('#SubRoughName').val(aData.Name);

                    if ($('#SubRoughAssignedOn') !== undefined && $('#SubRoughAssignedOn') !== null) {
                        $('#SubRoughAssignedOn').val(aData.AssignedOn);
                    }

                    $('#btnModalSubRough').modal('hide');
                    if (aData.RoughSubTypes.length > 0) {
                        bindRoughSubTypeDdl(aData.RoughSubTypes);
                        $('#roughSubTypeDropdown').val(true);
                        var sarinActivity = $('#SarinActivityId :selected').text();
                        $('#IsDisplyRoughSubTypeDdl').val(true);
                        showElement('#roughSubTypeDiv');
                    }
                    else {
                        $('#RoughCategoryId').empty();
                        $('#roughSubTypeDropdown').val(false);
                        $('#IsDisplyRoughSubTypeDdl').val(false);
                        hideElement('#roughSubTypeDiv');
                    }
                    if (aData.IsLotBySize) {
                        $("#IsLotBySize").val(true);
                        $("#SizeSign").val("");
                        $("#SieveSizeId").val("");
                        $("#SieveSize").val("");
                        showElement('#lotSize');
                    }
                    else {
                        hideElement('#lotSize');
                        $("#SizeSign").val("");
                        $("#SieveSizeId").val("");
                        $("#SieveSize").val("");
                    }

                    getClaritiesAsOnDate(aData.AssignedOnWithoutFormat);

                    //if (aData.IsLotBySize) {
                    //    $('#tblAssignedDetail tbody').find("tr:gt(0)").remove()
                    //    $("#DisplayMultipleAssignFields").val(false);
                    //    $("#IsLotBySize").val(true);
                    //    $("#btnAddAssign").attr("disabled");
                    //    showElement('#lotSize');
                    //}
                    //else {
                    //    $('#tblAssignedDetail tbody').find("tr:gt(0)").remove()
                    //    $("#DisplayMultipleAssignFields").val(true);
                    //    rowIndex = 2;
                    //    $("#btnAddAssign").removeAttr("disabled");
                    //    hideElement('#lotSize');
                    //    BindAssignedDetail();
                    //}
                });
            }
        });
        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);
    }
    else {
        $('#modalSubRough tbody tr').remove();
    }
    hideElement('.loadingDiv');
}

function getClaritiesAsOnDate(assignedOn) {
    if (assignedOn !== '' && assignedOn !== undefined) {
        sendRequest("GET", appendURL("Clarity/GetClaritiesAsOnDate"),
            {
                asOnDate: assignedOn
            }, "application/json; charset=utf-8", "json", bindClarities);
    }
}

function bindClarities(clarities) {
    var ddlClarities = $('#ClarityId');

    ddlClarities.empty();
    $('<option>', { value: "", text: "Select" }).html("Select").appendTo(ddlClarities);

    $.each(clarities, function (i, data) {
        $('<option>', { value: data.Value, text: data.Text }).html(data.Name).appendTo(ddlClarities);
    });

}

// Function for binding rough subtypes dropdownlist
function bindRoughSubTypeDdl(roughSubTypes) {

    var ddlRoughSubType = $('#RoughCategoryId');
    //showElement('#roughSubTypeDiv');

    ddlRoughSubType.empty();
    $('<option>', { value: "", text: "Select" }).html("Select").appendTo(ddlRoughSubType);

    $.each(roughSubTypes, function (i, data) {
        $('<option>', { value: data.RoughCategoryId, text: data.Name }).html(data.Name).appendTo(ddlRoughSubType);
    });
}