﻿var lossInputControlCount = 1;
var isValid = false;

$(document).ready(function () {

    // Click event for SubRough Save
    $('#btnSaveSubRough').click(function () {
        // Get the value of Makeable Weight and PieceCount
        var makeablePieceCount = $("#SubRough_MakeablePieceCount").val();
        var makeableWeight = $("#SubRough_MakeableWeight").val();

        var makeableMinPolDiam = $("#SubRough_MakeableMinPolishedDiameter").val();
        var makeableTopsPolDiam = $("#SubRough_MakeableTopsPolishedDiameter").val();

        // Each loop for Show or Hide Element
        //$('#SubRough_RoughTypeId,#SubRough_Weight,#SubRough_PieceCount,#SubRough_MinPolishedWeight,#SubRough_TopsWeight,#SubRough_EmployeeId,#SubRough_AssignedOn').each(function () {
        //    if ($(this).val() === '' || $(this).val() === '0')
        //        hideElement('.loadingDiv');
        //    else
        //        showElement('.loadingDiv');
        //});

        // Each loop for PieceCount validation (If value is wrong then it gives error and Hide LoadingElement)
        $('#SubRough_PieceCount,#SubRough_MakeablePieceCount,#SubRough_Number').each(function () {
            if ($(this).hasClass('input-validation-error'))
                hideElement('.loadingDiv');
        });

        // Condition for if makeablePieceCount has value and makeableWeight don't have value then gives error
        if (makeablePieceCount !== "" && (makeableWeight === "" || makeableMinPolDiam === "" || makeableTopsPolDiam === "")) {
            hideElement('.loadingDiv');
            if (makeableWeight === "") {
                $('#SubRough_MakeableWeight').css({
                    "border": "1px solid #ff0000",
                    "background": "#fee"
                });
                $('#validationMakeableWeight').html('Makeable Weight is Required');
            }
            else {
                $('#SubRough_MakeableWeight').css({
                    "border": "",
                    "background": ""
                });
                $('#validationMakeableWeight').html('');
            }
            if (makeableMinPolDiam === "") {
                $('#SubRough_MakeableMinPolishedDiameter').css({
                    "border": "1px solid #ff0000",
                    "background": "#fee"
                });
                $('#validationMakeableMinPolDiam').html('Makeable min.polished diameter is Required');
            }
            else {
                $('#SubRough_MakeableMinPolishedDiameter').css({
                    "border": "",
                    "background": ""
                });
                $('#validationMakeableMinPolDiam').html('');
            }
            if (makeableTopsPolDiam === "") {
                $('#SubRough_MakeableTopsPolishedDiameter').css({
                    "border": "1px solid #ff0000",
                    "background": "#fee"
                });
                $('#validationMakeableTopsPolDiam').html('Makeable tops.polished diameter is Required');
            }
            else {
                $('#SubRough_MakeableTopsPolishedDiameter').css({
                    "border": "",
                    "background": ""
                });
                $('#validationMakeableTopsPolDiam').html('');
            }
            if (makeablePieceCount !== "") {
                $('#SubRough_MakeablePieceCount').css({
                    "border": "",
                    "background": ""
                });
                $('#validationMakeablePieces').html('');
            }

            isValid = validateRejectionLossDetail(makeablePieceCount, makeableWeight);
            if (isValid === false)
                return false;

            return false;
        }
        else {
            $('#SubRough_MakeableWeight, #SubRough_MakeablePieceCount, #SubRough_MakeableTopsPolishedDiameter, #SubRough_MakeableMinPolishedDiameter').css({
                "border": "",
                "background": ""
            });
            $('#validationMakeableWeight, #validationMakeablePieceCount, #validationMakeableTopsPolDiam, #validationMakeableMinPolDiam').html('');
        }

        // Condition for if makeablePieceCount don't have value and makeableWeight has value then gives error
        if (makeableWeight !== "" && (makeablePieceCount === "" || makeableMinPolDiam === "" || makeableTopsPolDiam === "")) {
            hideElement('.loadingDiv');
            if (makeablePieceCount === "") {
                $('#SubRough_MakeablePieceCount').css({
                    "border": "1px solid #ff0000",
                    "background": "#fee"
                });
                $('#validationMakeablePieces').html('Makeable Piece Count is Required');
            }
            else {
                $('#SubRough_MakeablePieceCount').css({
                    "border": "",
                    "background": ""
                });
                $('#validationMakeablePieceCount').html('');
            }
            if (makeableMinPolDiam === "") {
                $('#SubRough_MakeableMinPolishedDiameter').css({
                    "border": "1px solid #ff0000",
                    "background": "#fee"
                });
                $('#validationMakeableMinPolDiam').html('Makeable min.polished diameter is Required');
            }
            else {
                $('#SubRough_MakeableMinPolishedDiameter').css({
                    "border": "",
                    "background": ""
                });
                $('#validationMakeableMinPolDiam').html('');
            }
            if (makeableTopsPolDiam === "") {
                $('#SubRough_MakeableTopsPolishedDiameter').css({
                    "border": "1px solid #ff0000",
                    "background": "#fee"
                });
                $('#validationMakeableTopsPolDiam').html('Makeable tops.polished diameter is Required');
            }
            else {
                $('#SubRough_MakeableTopsPolishedDiameter').css({
                    "border": "",
                    "background": ""
                });
                $('#validationMakeableTopsPolDiam').html('');
            }
            if (makeableWeight !== "") {
                $('#SubRough_MakeableWeight').css({
                    "border": "",
                    "background": ""
                });
                $('#validationMakeableWeight').html('');
            }

            isValid = validateRejectionLossDetail(makeablePieceCount, makeableWeight);
            if (isValid === false)
                return false;

            return false;
        }
        else {
            $('#SubRough_MakeableWeight, #SubRough_MakeablePieceCount, #SubRough_MakeableTopsPolishedDiameter, #SubRough_MakeableMinPolishedDiameter').css({
                "border": "",
                "background": ""
            });
            $('#validationMakeableWeight, #validationMakeablePieceCount, #validationMakeableTopsPolDiam, #validationMakeableMinPolDiam').html('');
        }

        isValid = validateRejectionLossDetail(makeablePieceCount, makeableWeight);
        if (isValid === false)
            return false;

        // Hide loading
        if ($('#SubRough_RoughTypeId').val() === "" || $('#SubRough_RoughTypeId').val() === '0')
            hideElement('.loadingDiv');
        if ($('#SubRough_Weight').val() === "" || $('#SubRough_Weight').val() === '0')
            hideElement('.loadingDiv');
        if ($('#SubRough_PieceCount').val() === "" || $('#SubRough_PieceCount').val() === '0')
            hideElement('.loadingDiv');
        if ($('#SubRough_AssignedOn').val() === "" || $('#SubRough_AssignedOn').val() === undefined)
            hideElement('.loadingDiv');
        if ($('#SubRough_EmployeeId').val() === "" || $('#SubRough_EmployeeId').val() === '0')
            hideElement('.loadingDiv');
        if ($('#SubRough_RoughMinPolishedDiameter').val() === "" || $('#SubRough_RoughMinPolishedDiameter').val() === '0')
            hideElement('.loadingDiv');
        if ($('#SubRough_RoughTopsPolishedDiameter').val() === "" || $('#SubRough_RoughTopsPolishedDiameter').val() === '0')
            hideElement('.loadingDiv');
        if ($('#SubRough_Number').val() > "10")
            hideElement('.loadingDiv');

        if (isSieveSizeFileSelected()) {
            return true;
        }
        else
            return false;

    });

    //Click event for Makeable save
    $('#btnSaveMakeableEntry').click(function () {

        var makeablePcs = $('#PieceCount').val();
        var makeableWeight = $('#Weight').val();

        isValid = validateRejectionLossDetail(makeablePcs, makeableWeight);
        if (isValid === false)
            return false;
    });

    $('#btnClearMakeableValues').click(function () {
        var message = "Are you sure, you want to clear all makeable details?";
        var result = confirm(message);

        if (result) {
            $('#SubRough_MakeablePieceCount').val('');
            $('#SubRough_MakeableWeight').val('');
            $('#SubRough_MakeableMinPolishedDiameter').val('');
            $('#SubRough_MakeableTopsPolishedDiameter').val('');
            $('#Rejections_0__PieceCount').val('');
            $('#Rejections_0__Weight').val('');
            $('#Losses_0__PieceCount').val('');
            $('#Losses_0__Weight').val('');
            $('#Losses_0__Description').val('');
            $('#Damages_0__PieceCount').val('');
            $('#Damages_0__Weight').val('');
            $('#Damages_0__Description').val('');
        }
    });

    // Change event of action
    $('#SieveSizeFileAction').on('change', function (e) {

        var action = $('#SieveSizeFileAction').val();

        if (action === "Other") {
            sendRequest("GET", "GetSieveSizeFiles","{}", false, "json", bindSieveSizeFileDdl, false);
        }
        else {
            $('#SubRough_SieveSizeFileImportId').empty();
            hideElement('#sieveSizeFileDdl');
        }
    });

    $('#SubRough_SieveSizeFileImportId').on('change', function (e) {
        $('#emptySieveSizeFile').html('');
        $(this).css({
            "border": "",
            "background": ""
        });
    });
});

function validateRejectionLossDetail(makeablePcs, makeableWeight) {
    var rejectionPcs = $('#Rejections_0__PieceCount').val();
    var rejectionWeight = $('#Rejections_0__Weight').val();
    var lossPcs = $('#Losses_0__PieceCount').val();
    var lossWeight = $('#Losses_0__Weight').val();
    var damagePcs = $('#Damages_0__PieceCount').val();
    var damageWeight = $('#Damages_0__Weight').val();

    // Condition for if Makeable PieceCount has value and other control don't have value
    if (makeablePcs !== "" && (rejectionPcs === "" || rejectionWeight === "" || lossPcs === "" || lossWeight === "" || damagePcs === "" || damageWeight === "")) {
        if (rejectionPcs === "") {
            $('#Rejections_0__PieceCount').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationRejectionPcs').html('Pcs is required');
        }
        else {
            $('#Rejections_0__PieceCount').css({
                "border": "",
                "background": ""
            });
            $('#validationRejectionPcs').html('');
        }
        if (rejectionWeight === "") {
            $('#Rejections_0__Weight').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationRejectionWeight').html('Weight is required');
        }
        else {
            $('#Rejections_0__Weight').css({
                "border": "",
                "background": ""
            });
            $('#validationRejectionWeight').html('');
        }
        if (lossPcs === "") {
            $('#Losses_0__PieceCount').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationLossPcs').html('Pcs is required');
        }
        else {
            $('#Losses_0__PieceCount').css({
                "border": "",
                "background": ""
            });
            $('#validationLossPcs').html('');
        }
        if (lossWeight === "") {
            $('#Losses_0__Weight').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationLossWeight').html('Weight is required');
        }
        else {
            $('#Losses_0__Weight').css({
                "border": "",
                "background": ""
            });
            $('#validationLossWeight').html('');
        }
        if (damagePcs === "") {
            $('#Damages_0__PieceCount').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationDamagedPcs').html('Pcs is required');
        }
        else {
            $('#Damages_0__PieceCount').css({
                "border": "",
                "background": ""
            });
            $('#validationDamagedPcs').html('');
        }
        if (damageWeight === "") {
            $('#Damages_0__Weight').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationDamagedWeight').html('Weight is required');
        }
        else {
            $('#Damages_0__Weight').css({
                "border": "",
                "background": ""
            });
            $('#validationDamagedWeight').html('');
        }

        return false;
    }
    else {
        $('#Rejections_0__PieceCount, #Rejections_0__Weight, #Losses_0__PieceCount, #Losses_0__Weight, #Damages_0__PieceCount, #Damages_0__Weight').css({
            "border": "",
            "background": ""
        });
        $('#validationRejectionPcs, #validationRejectionWeight, #validationLossPcs, #validationLossWeight, #validationDamagedPcs, #validationDamagedWeight').html('');
    }

    // Condition for if Makeable Weight has value and other control don't have value
    if (makeableWeight !== "" && (rejectionPcs === "" || rejectionWeight === "" || lossPcs === "" || lossWeight === "" || damagePcs === "" || damageWeight === "")) {
        if (rejectionPcs === "") {
            $('#Rejections_0__PieceCount').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationRejectionPcs').html('Pcs is required');
        }
        else {
            $('#Rejections_0__PieceCount').css({
                "border": "",
                "background": ""
            });
            $('#validationRejectionPcs').html('');
        }
        if (rejectionWeight === "") {
            $('#Rejections_0__Weight').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationRejectionWeight').html('Weight is required');
        }
        else {
            $('#Rejections_0__Weight').css({
                "border": "",
                "background": ""
            });
            $('#validationRejectionWeight').html('');
        }
        if (lossPcs === "") {
            $('#Losses_0__PieceCount').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationLossPcs').html('Pcs is required');
        }
        else {
            $('#Losses_0__PieceCount').css({
                "border": "",
                "background": ""
            });
            $('#validationLossPcs').html('');
        }
        if (lossWeight === "") {
            $('#Losses_0__Weight').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationLossWeight').html('Weight is required');
        }
        else {
            $('#Losses_0__Weight').css({
                "border": "",
                "background": ""
            });
            $('#validationLossWeight').html('');
        }
        if (damagePcs === "") {
            $('#Damages_0__PieceCount').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationDamagedPcs').html('Pcs is required');
        }
        else {
            $('#Damages_0__PieceCount').css({
                "border": "",
                "background": ""
            });
            $('#validationDamagedPcs').html('');
        }
        if (damageWeight === "") {
            $('#Damages_0__Weight').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#validationDamagedWeight').html('Weight is required');
        }
        else {
            $('#Damages_0__Weight').css({
                "border": "",
                "background": ""
            });
            $('#validationDamagedWeight').html('');
        }

        return false;
    }
    else {
        $('#Rejections_0__PieceCount, #Rejections_0__Weight, #Losses_0__PieceCount, #Losses_0__Weight, #Damages_0__PieceCount, #Damages_0__Weight').css({
            "border": "",
            "background": ""
        });
        $('#validationRejectionPcs, #validationRejectionWeight, #validationLossPcs, #validationLossWeight, #validationDamagedPcs, #validationDamagedWeight').html('');
    }
}

function bindSieveSizeFileDdl(data) {
    var ddlSieveSizeFileSelect = $('#SubRough_SieveSizeFileImportId');
    ddlSieveSizeFileSelect.empty();
    $('<option>', { value: "0", text: "Select" }).html("Select").appendTo(ddlSieveSizeFileSelect);

    $.each(data.sieveSizeFilesDetail, function (i, data) {
        $('<option>', { value: data.Value, text: data.Text }).html(data.Text).appendTo(ddlSieveSizeFileSelect);
    });
    showElement('#sieveSizeFileDdl');
}

function isSieveSizeFileSelected() {
    var action = $('#SieveSizeFileAction').val();
    var isValid = true;
    if (action === 'Other') {
        var file = $('#SubRough_SieveSizeFileImportId').val();

        if (file === '' || file === '0') {
            isValid = false;
            $('#SubRough_SieveSizeFileImportId').css({
                "border": "1px solid #ff0000",
                "background": "#fee"
            });
            $('#emptySieveSizeFile').html('SieveSize File is Required');
        }
        else {
            $('#SubRough_SieveSizeFileImportId').css({
                "border": "",
                "background": ""
            });
            $('#emptySieveSizeFile').html('');
        }
    }
    return isValid;
}