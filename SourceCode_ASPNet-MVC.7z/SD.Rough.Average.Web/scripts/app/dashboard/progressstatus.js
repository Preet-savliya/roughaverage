﻿var status = null;
var sarinActivity = null;
var lotRowsCount = 0;
var currentRow = null;
var cutsChildRow = "subRoughsChildRow";
var subRoughDetailsByStatus = null;

$(document).ready(function () {

    subRoughDetailsByStatus = "GetSubRoughDetailsByStatus";

    // On page loads sends request and get details
    status = $('.navStatus li.active a').attr('name');
    getStatusData();
    showElement('.loadingDiv');

    // On click of status navbar send request and get details
    $('.navStatus').on('click', 'li', function () {
        $(this).addClass('active').siblings().removeClass('active');

        $('.navTabs li').removeClass("active");
        $('.navTabs li').first().addClass("active");

        status = $('.navStatus li.active a').attr('name');
        showElement('.loadingDiv');
        sendRequest("GET", subRoughDetailsByStatus,
            {
                status: status
            }, "application/json; charset=utf-8", "json", bindStatusDetails);
    });

    //On change of tab sends request and get detail
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        status = $('.navStatus li.active a').attr('name');
        sarinActivity = $(e.target).attr("name");
        showElement('.loadingDiv');

        sendRequest("GET", subRoughDetailsByStatus,
            {
                status: status,
                sarinActivity: sarinActivity
            },
            "application/json; charset=utf-8", "json", bindStatusDetails);
    });
});

// Function for Bind SubRough data in grid
function bindStatusDetails(data) {
    showElement('.loadingDiv');

    var dataTableByStatus = null;

    if (data !== null && data !== "Error") {
        //Assign values to paging variables
        totalPages = data.totalPages;
        totalRecords = data.totalRecords;

        var status = data.status;

        // For DataTable
        $("#statusOutput").empty();

        $('#statusOutput').html('<thead>' +
            '<tr class="gridHeaderRow">' +
            '<th rowspan="2" class="gridHeader gridHeaderView">View</th>' +
            '<th rowspan="2" class="gridHeader gridHeaderType">Cut Type</th>' +
            '<th rowspan="2" class="gridHeader gridHeaderShade">Color Shade</th>' +
            '<th rowspan="2" class="gridHeader gridHeaderNo">Cut #</th>' +
            '<th rowspan="2" class="gridHeader gridHeaderSize">Cut Size</th>' +
            '<th colspan="2" class="gridHeader">Rough</th>' +
            '<th colspan="2" class="gridHeader">Makeable</th>' +
            //'<th rowspan="2" class="gridHeader gridHeaderWeight">Tops.Pol.Diam.</th>' +
            //'<th rowspan="2" class="gridHeader gridHeaderMinPoweight">Min Pol.Diam.</th>' +
            '<th rowspan="2" class="gridHeader gridHeaderCreatedOn">Cut Date</th>' +
            '<th rowspan="2" class="gridHeader gridHeaderManager">Manager</th>' +
            '<th rowspan="2" class="gridHeader gridHeaderComment">Comment</th>' +
            '</tr>' +
            '<tr class="gridHeaderRow">' +
            '<th class="gridHeader gridHeaderPieceCount">Pcs</th>' +
            '<th class="gridHeader gridHeaderWeight">Wt</th>' +
            '<th class="gridHeader gridHeaderPieceCount">Pcs</th>' +
            '<th class="gridHeader gridHeaderWeight">Wt</th>' +
            '</tr>' +
            '</thead>');

        dataTableByStatus = $('#statusOutput').DataTable({
            "destroy": true,
            "searching": false,
            "paging": false,
            "info": false,
            "aaData": data.outputData,
            "aoColumns": [
                {
                    "class": "details-control",
                    "data": null,
                    "defaultContent": "",
                    //"sTitle":"View",
                    "mdata": "Id",
                    "orderable": false,
                    "searchable": false,
                    "render": function (id, type, full, meta) {
                        return '<input type="hidden" value="' + full.Id + '">';
                    }
                },
                {
                    "mData": "RoughType",
                    //"sTitle": "Cut Type",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-left"
                },
                {
                    "mData": "RoughColorShade",
                    //"sTitle": "Color Shade",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-left",
                    "render": function (id, type, full, meta) {
                        return full.RoughColorShade !== null ? full.RoughColorShade : "-";
                    }
                },
                {
                    "mData": "Number",
                    //"sTitle": "Cut #",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-right",
                    "render": function (id, type, full, meta) {
                        return full.Number !== null ? full.Number : "-";
                    }
                },
                {
                    "mData": "RoughSize",
                    //"sTitle": "Cut Size",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-right",
                    "render": function (id, type, full, meta) {
                        return full.RoughSize !== null ? full.RoughSize : "-";
                    }
                },
                {
                    "mData": "PieceCount",
                    //"sTitle": "Pcs",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-right"
                },
                {
                    "mData": "Weight",
                    //"sTitle": "Wt",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-right",
                    "render": function (id, type, full, meta) {
                        return full.Weight.toFixed(3);
                    }
                },
                {
                    "mData": "MakeablePieceCount",
                    //"sTitle": "Pcs",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-right",
                    "render": function (id, type, full, meta) {
                        return full.MakeablePieceCount !== null ? full.MakeablePieceCount : "-";
                    }
                },
                {
                    "mData": "MakeableWeight",
                    //"sTitle": "Wt",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-right",
                    "render": function (id, type, full, meta) {
                        return full.MakeableWeight !== null ? full.MakeableWeight.toFixed(3) : "-";
                    }
                },
                //{
                //    "mData": "TopsPolishedDiameter",
                //    //"sTitle": "Tops Wt",
                //    "orderable": false,
                //    "searchable": false,
                //    "sClass": "text-right",
                //    "render": function (id, type, full, meta) {
                //        return full.TopsPolishedDiameter !== null ? full.TopsPolishedDiameter.toFixed(3) : "-";
                //    }
                //},
                //{
                //    "mData": "MinPolishedDiameter",
                //    //"sTitle": "Min Pol. Wt",
                //    "orderable": false,
                //    "searchable": false,
                //    "sClass": "text-right",
                //    "render": function (id, type, full, meta) {
                //        return full.MinPolishedDiameter !== null ? full.MinPolishedDiameter.toFixed(3) : "-";
                //    }
                //},
                {
                    "mData": "AssignedOn",
                    //"sTitle": "Cut Date",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-left",
                    "render": function (id, type, full, meta) {
                        return full.AssignedOn;
                    }
                },
                {
                    "mData": "Manager",
                    //"sTitle": "Manager",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-left"
                },
                {
                    "mData": "Comment",
                    //"sTitle": "Comment",
                    "orderable": false,
                    "searchable": false,
                    "sClass": "text-left",
                    "render": function (id, type, full, meta) {
                        if (full.Comment.m_StringValue.indexOf('</li>') > -1)
                            return '<ul style="padding-left:17px; margin:0">' + full.Comment.m_StringValue + '</ul>';
                        else
                            return full.Comment.m_StringValue;
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (status === "MisMatch")
                    $(nRow).addClass('misMatch');
                if (status === "InComplete")
                    $(nRow).addClass('inComplete');
                if (status === "Pending")
                    $(nRow).addClass('pending');
                if (status === "Complete")
                    $(nRow).addClass('complete');
            }
        });

        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);
        hideElement('.loadingDiv');
    }
    hideElement('.loadingDiv');

    $('#statusOutput tbody').on('click', 'tr td.details-control', function () {
        lotRowsCount++;

        var tr = $(this).closest('tr');
        if (tr.hasClass('details')) {
            tr.removeClass('details');
            $(this).parent().next().remove();
        }
        else {
            tr.addClass('details');
            currentRow = $(this);
            var subRoughId = $(this).children().val();
            getLotData(subRoughId);
        }
    });
}

// Sends data - status and sarin activity
function getStatusData() {
    status = $('.navStatus li.active a').attr('name');
    sarinActivity = $('.navTabs li.active a').attr('name');
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }

    sendRequest("GET", subRoughDetailsByStatus,
        {
            status: status,
            sarinActivity: sarinActivity,
            PageSize: pageSize,
            PageNumber: pageNumber
        },
        "application/json; charset=utf-8", "json", bindStatusDetails);
}

// Function for Bind child table of lot
function bindLotDetail(data) {
    var lotDetail = data.lotsDetail;
    var tableData = "";
    var tableHeader = '<table class="childTable col-md-8 table-bordered table-striped table-hover table-responsive">' +
        '<tr class= "gridHeaderRow">' +
        '<th class="gridHeader">' + 'No' + '</th>' +
        '<th class="gridHeader">' + 'Name' + '</th>' +
        '<th class="gridHeader">' + 'Piece(s)' + '</th>' +
        '<th class="gridHeader">' + 'Weight' + '</th>' +
        '<th class="gridHeader">' + 'SarinActivity' + '</th>' +
        '<th class="gridHeader">' + 'Clarity' + '</th>' +
        '<th class="gridHeader">' + 'Cut Sub Type' + '</th>' +
        '<th class="gridHeader">' + 'Operator' + '</th>' +
        '</tr>';

    var closeTable = '</table>';
    var count = 0;

    if (lotDetail.length > 0) {
        $.each(lotDetail, function (key, value) {
            var name = value.Name !== null ? value.Name : "-";
            var clarity = value.Clarity !== null ? value.Clarity : "-";
            var cutSubType = value.RoughSubType !== null ? value.RoughSubType : "-";
            var assignedTo = "";

            var startul = "<ul>";
            var closeul = "</ul>";
            var startli = "<li>";
            var closeli = "</li>";
            if (value.AssignedTo !== null) {
                for (var i = 0; i < value.AssignedTo.length; i++) {
                    assignedTo = assignedTo + startli + value.AssignedTo[i] + closeli;
                }
            }
            else
                assignedTo = startli + "-" + closeli;

            count++;
            tableData = tableData + '<tr>' +
                '<td class="text-right"><b>' + count + '</b></td>' +
                '<td class="text-right">' + name + '</td>' +
                '<td class="text-right">' + value.PieceCount + '</td>' +
                '<td class="text-right">' + value.Weight.toFixed(3) + '</td>' +
                '<td class="text-left">' + value.SarinActivity + '</td>' +
                '<td class="text-left">' + clarity + '</td>' +
                '<td class="text-left">' + cutSubType + '</td>' +
                '<td class="text-left">' + startul + assignedTo + closeul + '</td>' +
                '</tr>';
        });
    }
    else
        tableData = '<tr><td colspan=9 text-center>No lot available</td></tr>';

    var heading = "<span class=tableHeading><b>Lots Detail:</b></span><div class=row clearfix></div>";

    $('<tr class=' + cutsChildRow + lotRowsCount + '><td colspan=14></td></tr>').insertAfter(currentRow.parent());
    $('.' + cutsChildRow + lotRowsCount).find('td').html(heading + tableHeader + tableData + closeTable);
    hideElement('.loadingDiv');
}