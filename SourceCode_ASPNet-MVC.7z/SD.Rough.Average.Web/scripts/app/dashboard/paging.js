﻿var pageIndex = 1;
var totalPages = 1;
var totalRecords = 0;
var currentPage = 0;

$(document).ready(function () {
    // Input textbox Paging 
    $('.inputPaging').keypress(function (e) {
        if (e.which === 13) {
            hideElement('.alertDetail');
            currentPage = parseInt($('#pageNumber').val());
            pageIndex = currentPage > totalPages ? totalPages : currentPage;
            $('#pageNumber').val(pageIndex);
            getStatusData();
        }
    });

    // Button FirstPage click
    $('#btnFirstPage').click(function (e) {
        hideElement('.alertDetail');
        pageIndex = 1;
        $('#pageNumber').val(pageIndex);
        getStatusData();
    });

    // Button previousPage click
    $('#btnPreviousPage').click(function (e) {
        hideElement('.alertDetail');
        currentPage = parseInt($('#pageNumber').val());
        pageIndex = currentPage > 1 ? currentPage - 1 : 1;
        $('#pageNumber').val(pageIndex);
        getStatusData();
    });

    // Button nextPage click
    $('#btnNextPage').click(function (e) {
        hideElement('.alertDetail');
        currentPage = parseInt($('#pageNumber').val());
        pageIndex = currentPage < totalPages ? currentPage + 1 : totalPages;
        $('#pageNumber').val(pageIndex);
        getStatusData();
    });

    // Button LastPage click
    $('#btnLastPage').click(function (e) {
        hideElement('.alertDetail');
        $('#pageNumber').val(totalPages);
        getStatusData();
    });

    $("#ddlPageSize").change(function () {
        hideElement('.alertDetail');
        getStatusData();
    });
});
