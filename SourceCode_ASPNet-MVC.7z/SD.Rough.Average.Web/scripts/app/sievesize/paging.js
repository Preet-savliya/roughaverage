﻿var pageIndex = 1;
var totalPages = 1;
var totalRecords = 0;
var currentPage = 0;

$(document).ready(function () {
    $('.inputPaging').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            currentPage = parseInt($('#pageNumber').val());
            pageIndex = currentPage > totalPages ? totalPages : currentPage;
            $('#pageNumber').val(pageIndex);
            getSieveSizeData();
        }
    });

    $('#btnFirstPage').click(function (e) {
        setControlVisibility();
        pageIndex = 1;
        $('#pageNumber').val(pageIndex);
        getSieveSizeData();
    });

    $('#btnPreviousPage').click(function (e) {
        setControlVisibility();
        currentPage = parseInt($('#pageNumber').val());
        pageIndex = currentPage > 1 ? currentPage - 1 : 1;
        $('#pageNumber').val(pageIndex);
        getSieveSizeData();
    });

    $('#btnNextPage').click(function (e) {
        setControlVisibility();
        currentPage = parseInt($('#pageNumber').val());
        pageIndex = currentPage < totalPages ? currentPage + 1 : totalPages;
        $('#pageNumber').val(pageIndex);
        getSieveSizeData();
    });

    $('#btnLastPage').click(function (e) {
        setControlVisibility();
        $('#pageNumber').val(totalPages);
        getSieveSizeData();
    });

    $("#ddlPageSize").change(function () {
        setControlVisibility();
        getSieveSizeData();
    });
});