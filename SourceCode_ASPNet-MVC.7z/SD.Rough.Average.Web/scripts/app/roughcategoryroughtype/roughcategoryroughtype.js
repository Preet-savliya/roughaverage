﻿$(document).ready(function () {
    setControlVisibility(false);
    getRoughCategoryRoughTypeData();
});

function getRoughCategoryRoughTypeData(sortColumn, sortDirection) {

    sendRequest("GET", appendURL("RoughCategoryRoughType/GetRoughCategoryRoughTypeDetails"),
        {
            roughTypeId: $('#Id').val()
        }, "application/json; charset=utf-8", "json", bindRoughCategoryRoughTypeData);
}

function bindRoughCategoryRoughTypeData(data) {
    if (data !== null && data !== "Error") {
        var roughTypeId = $('#Id').val();

        var dt = $('#roughCategoryRoughTypeTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '40vh',
            "columnDefs": [
                {
                    targets: [3, 5, 7],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 2, 8],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.roughCategoryRoughTypeDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="../RoughCategoryRoughType/Edit?roughCategoryRoughTypeId=' + full.Id + '&roughTypeId=' + roughTypeId + ' " title="Edit" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="glyphicon glyphicon-edit"></span>' +
                            '</a>';
                    }
                },
                {
                    "mData": "RoughCategory"
                },
                {
                    "mData": "IsBehaveSeparately",
                    "render": function (id, type, full, meta) {
                        var IsBehaveSeparately = null;
                        if (full.IsBehaveSeparately != null) {
                            if (full.IsBehaveSeparately) {
                                IsBehaveSeparately = '</span><i class="fa fa-check-square-o fa-lg text-success"></i>'
                            }
                            else {
                                IsBehaveSeparately = '<i class="color-disable fa fa-check-square-o fa-lg text-success"></i>'
                            }
                        }
                        else {
                            IsBehaveSeparately = "-"
                        }
                        return IsBehaveSeparately;
                    }
                },
                {
                    "mData": "DisplayOrder"
                },
                {
                    "mData": "CreatedBy",
                    "render": function (id, type, full, meta) {
                        return full.CreatedBy != null ? full.CreatedBy : "-";
                    }
                },
                {
                    "mData": "CreatedOn",
                    "render": function (id, type, full, meta) {
                        return full.CreatedOn != null ? full.CreatedOn : "-";
                    }
                },
                {
                    "mData": "ModifiedBy",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedBy != null ? full.ModifiedBy : "-";
                    }
                },
                {
                    "mData": "ModifiedOn",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedOn != null ? full.ModifiedOn : "-";
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="../RoughCategoryRoughType/Delete?roughCategoryRoughTypeId=' + full.Id + '&roughTypeId=' + roughTypeId + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate") + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            (deleteActivate === "Delete" ? '<span class="glyphicon glyphicon-trash"></span></a>' : '<span class="glyphicon glyphicon-ok"></span>') +
                            '</a>';
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}