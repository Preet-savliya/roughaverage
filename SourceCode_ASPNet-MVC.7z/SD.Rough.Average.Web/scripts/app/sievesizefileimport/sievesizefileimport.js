﻿$(document).ready(function () {
    setControlVisibility(false);
    getSieveSizeFileImportData();
});

// Function for search and sort Data
function getSieveSizeFileImportData(sortColumn, sortDirection) {
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }

    sendRequest("GET", "GetSieveSizeFileImportDetail",
        {
            PageSize: pageSize,
            PageNumber: pageNumber
        }, "application/json; charset=utf-8", "json", bindSieveSizeFileImportData);
}

function bindSieveSizeFileImportData(data) {
    if (data !== null && data !== "Error") {
        totalPages = data.totalPages;
        totalRecords = data.totalRecords;
        var dt = $('#sieveSizeFileImportDetail').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '65vh',
            "columnDefs": [
                {
                    targets: [2],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 3],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.sieveSizeFileImportDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        return '<a href="Detail?sieveSizeFileImportId=' + full.Id + '" title="View Diameter Sieve Size Details" class="btn-edit linkedit">' +
                            '<span class="fa fa-eye"></span></a>' +
                            '</a>';
                    }
                },
                {
                    "mData": "Name"
                },
                {
                    "mData": "EffectiveFrom"
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        return '<a href="Delete?id=' + full.Id + '" title="Delete" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            '<span class="glyphicon glyphicon-trash"></span></a>' +
                            '</a>';
                    }
                }
            ],
        });
        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}