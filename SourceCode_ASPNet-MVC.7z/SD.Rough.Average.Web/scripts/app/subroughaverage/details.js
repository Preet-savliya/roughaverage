﻿var sarinActivity = null;
var editablePcsRow = null;
var editableWtRow = null;
var minPolishedDiameterRow = null;
var topsPolishedDiameterRow = null;

$(document).ready(function () {
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
        sarinActivity = $(e.target).attr("name");
        var id = $("#SubRough_Id").val();
        sendRequest("GET", appendURL("SubRoughAverage/SubRoughDetailBySarinActivity"),
            {
                id: id,
                sarinActivity: sarinActivity
            },
            "application/json; charset=utf-8", "json", bindSubRoughDetailBySarinActivity);
    });
});

function bindSubRoughDetailBySarinActivity(data) {
    var subRough = null;

    if (data.subRough.length > 0) {
        subRough = data.subRough[0];

        var roughSubRoughTable = document.getElementById("roughSubRoughDetail");
        var makeableSubRoughTable = document.getElementById("makeableSubRoughDetail");

        if (subRough.SarinActivity === "Rough" || subRough.SarinActivity === "RoughPlanning") {
            makeableSubRoughTable.style.display = "none";
            roughSubRoughTable.style.display = "block";
        }

        if (subRough.SarinActivity === "Makeable" || subRough.SarinActivity === "MakeablePlanning") {
            roughSubRoughTable.style.display = "none";
            makeableSubRoughTable.style.display = "block";
        }
    }
}