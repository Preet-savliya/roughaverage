﻿$(document).ready(function () {
    setControlVisibility(false);
    getMachineTypeData();

    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            getMachineTypeData();

            e.preventDefault();
        }
        else { null; }
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        setControlVisibility();
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getMachineTypeData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });

    //Autocomplete of Name
    $('#Name').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("MachineType/GetMachineTypeName"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Name };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getMachineTypeData();
            }
        }
    });
});

function getMachineTypeData(sortColumn, sortDirection) {
    var name = $('#Name').val();

    sendRequest("GET", "GetMachineTypeDetails",
        {
            Name: name,
            SortColumn: sortColumn,
            SortDirection: sortDirection,
        }, "application/json; charset=utf-8", "json", bindMachineTypeData);
}

function bindMachineTypeData(data) {
    if (data !== null && data !== "Error") {
        var dt = $('#machineTypeTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '51vh',
            "columnDefs": [
                {
                    targets: [4, 6],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 7],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.machineTypeDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="Edit?machineTypeId=' + full.Id + '" title="Edit" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="glyphicon glyphicon-edit"></span>' +
                            '</a>';
                    }
                },
                {
                    "mData": "Name"
                },
                {
                    "mData": "Description",
                    "render": function (id, type, full, meta) {
                        return full.Description !== null ? full.Description : "-";
                    }
                },
                {
                    "mData": "CreatedBy",
                    "render": function (id, type, full, meta) {
                        return full.CreatedBy !== null ? full.CreatedBy : "-";
                    }

                },
                {
                    "mData": "CreatedOn",
                    "render": function (id, type, full, meta) {
                        return full.CreatedOn != null ? full.CreatedOn : "-";
                    }
                },
                {
                    "mData": "ModifiedBy",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedBy != null ? full.ModifiedBy : "-";
                    }
                },
                {
                    "mData": "ModifiedOn",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedOn != null ? full.ModifiedOn : "-";
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="Delete?machineTypeId=' + full.Id + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate") + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            (deleteActivate === "Delete" ? '<span class="glyphicon glyphicon-trash"></span></a>' : '<span class="glyphicon glyphicon-ok"></span>') +
                            '</a>';
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}