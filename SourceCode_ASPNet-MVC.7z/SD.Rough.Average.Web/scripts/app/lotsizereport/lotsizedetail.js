﻿var subRoughId = 0;
var sarinActivity = null;
var roughSarinActivity = 'Rough';
var makeableSarinActivity = 'Makeable';

$(document).ready(function () {
    if (document.getElementById("IsCombineReport")) {
        document.getElementById("IsCombineReport").checked = true;
    }

    subRoughId = $('#SubRoughId').val();
    if (sarinActivity !== undefined) {
        sarinActivity = roughSarinActivity;
        getLotWiseSizeAverageData(subRoughId, sarinActivity);
    }

    $('#IsCombineReport[name=IsCombineReport]').change(function () {
        getLotWiseSizeAverageData(subRoughId, sarinActivity, $(this).val());
    });

    $("#Rough").click(function () {
        sarinActivity = roughSarinActivity;

        if (document.getElementById("IsCombineReport")) {
            document.getElementById("IsCombineReport").checked = true;
        }
        getLotWiseSizeAverageData(subRoughId, sarinActivity);
    });
    
    $("#Makeable").click(function () {
        sarinActivity = makeableSarinActivity;

        if (document.getElementById("IsCombineReport")) {
            document.getElementById("IsCombineReport").checked = true;
        }
        getLotWiseSizeAverageData(subRoughId, sarinActivity);
    });

});

function getLotWiseSizeAverageData(subRoughId, sarinActivity, isCombineReport = true) {
    $.get(appendURL('LotSizeReport/GetLotSizeColorAverageDetails?subRoughId=' + subRoughId + '&sarinActivity='
        + sarinActivity + '&isTopsLot=' + true + '&isCombineReport=' + isCombineReport), function (data) {
            if (sarinActivity === roughSarinActivity) {
                $('#Rough_Planning').html(data);
                $('#Rough_Planning').fadeIn('fast');
            }
            else {
                $('#Makeable_Planning').html(data);
                $('#Makeable_Planning').fadeIn('fast');
            }
        });
}