﻿$(document).ready(function () {
    setControlVisibility(false);
    getDiameterSieveSizeData();

    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            getDiameterSieveSizeData();
            e.preventDefault();
        }
        else { null; }
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        setControlVisibility();
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getDiameterSieveSizeData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });

    $('#SieveSizeId').change(function () {
        setControlVisibility();
        getDiameterSieveSizeData();
    });

    //Autocomplete of Diameter
    $('#Diameter').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetDiameterSieveSizeDiameters",
                type: "GET",
                dataType: "json",
                data: {
                    diameter: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Diameter.toFixed(2) };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getDiameterSieveSizeData();
            }
        }
    });
});

function getDiameterSieveSizeData(sortColumn, sortDirection) {
    var diameter = $('#Diameter').val();
    var sieveSizeId = $('#SieveSizeId').val();
    var sieveSizeFileImportId = $('#SieveSizeFileImportId').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }
    sendRequest("GET", "GetDiameterSieveSizeDetails",
        {
            Diameter: diameter,
            SieveSizeId: sieveSizeId,
            SieveSizeFileImportId: sieveSizeFileImportId,
            SortColumn: sortColumn,
            SortDirection: sortDirection,
            PageSize: pageSize,
            PageNumber: pageNumber
        }, "application/json; charset=utf-8", "json", bindDiameterSieveSizeData);
}

function bindDiameterSieveSizeData(data) {
    if (data !== null && data !== "Error") {
        totalPages = data.totalPages;
        totalRecords = data.totalRecords;
        var dt = $('#diameterSieveSizeTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '50vh',
            "columnDefs": [
                {
                    targets: [1, 2, 3, 5, 7],
                    className: 'dt-body-right'
                },
                {
                    targets: [0],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.diameterSieveSizeDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        return '<a href="Edit?diameterSieveSizeId=' + full.Id + '" title="Edit" class="loadingProcess btn-edit linkedit">' +
                            '<span class="glyphicon glyphicon-edit"></span></a>' +
                            '</a>';
                    }
                },
                {
                    "mData": "Diameter",
                    "render": function (id, type, full, meta) {
                        return full.Diameter.toFixed(2);
                    }
                },
                {
                    "mData": "SieveSizeName"
                },
                {
                    "mData": "DiameterUpTo",
                    "render": function (id, type, full, meta) {
                        return full.DiameterUpTo !== null ? full.DiameterUpTo : "-";
                    }
                },
                {
                    "mData": "CreatedBy"
                },
                {
                    "mData": "CreatedOn"
                },
                {
                    "mData": "ModifiedBy",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedBy !== null ? full.ModifiedBy : "-";
                    }
                },
                {
                    "mData": "ModifiedOn",
                    "render": function (id, type, full, meta) {
                        return full.ModifiedOn !== null ? full.ModifiedOn : "-";
                    }
                }
            ]
        });
        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}