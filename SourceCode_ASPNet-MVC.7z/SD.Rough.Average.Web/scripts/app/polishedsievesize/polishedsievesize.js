﻿$(document).ready(function () {
    setControlVisibility(false);
    getPolishedSieveSizeData();

    // Input type Enter keypress in search
    $('.inputSearch').keypress(function (e) {
        if (e.which === 13) {
            setControlVisibility();
            getPolishedSieveSizeData();
            e.preventDefault();
        }
        else { null; }
    });

    $('#EntryStatus').on('change', function (e) {
        setControlVisibility();
        getPolishedSieveSizeData();
    });

    // Sorting Column
    $('.sortColumn').click(function (evt) {
        setControlVisibility();
        var sortColumn = $(evt.target).data("sortfield");
        var sortDirection = $(this).attr('class').split(' ')[1];
        setGridSortingStyles($(this), $(this).closest("th"), sortDirection);
        getPolishedSieveSizeData(sortColumn, sortDirection);
    });

    // Click event of TextBox then clear value
    $('input').click(function () {
        $(this).val('');
    });

    $('#MinSieveSize').click(function () {
        $('#MinSieveSizeId').val('');
    });

    $('#MaxSieveSize').click(function () {
        $('#MaxSieveSizeId').val('');
    });

    // Btn Search on click
    $('#btnSearch').click(function () {
        setControlVisibility();
        getPolishedSieveSizeData();
    });

    //Autocomplete of Name
    $('#Name').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetPolishedSieveSizeNamesForSearch",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Name };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getPolishedSieveSizeData();
            }
        }
    });

    //Autocomplete of Min Sieve Size
    $('#MinSieveSize').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SieveSize/GetSieveSizeName"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { label: item.Name, Value: item.Id };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.label);
                $('#MinSieveSizeId').val(ui.item.Value);
                setControlVisibility();
                getPolishedSieveSizeData();
            }
        }
    });

    //Autocomplete of Max Sieve Size
    $('#MaxSieveSize').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: appendURL("SieveSize/GetSieveSizeName"),
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { label: item.Name, Value: item.Id };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.label);
                $('#MaxSieveSizeId').val(ui.item.Value);
                setControlVisibility();
                getPolishedSieveSizeData();
            }
        }
    });

    //Autocomplete of Parent size
    $('#ParentSize').autocomplete({
        autoFocus: true,
        source: function (request, response) {
            $.ajax({
                url: "GetPolishedSieveSizeNamesForSearch",
                type: "GET",
                dataType: "json",
                data: {
                    prefix: request.term,
                    entryStatus: "All"
                },
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    if (data.length > 0) {
                        response($.map(data, function (item) {
                            return { value: item.Name };
                        }));
                    }
                    else
                        response([{ label: noResultFoundText, val: -1 }]);
                },
                error: function (props, errorThrown) {
                    ajaxError(props, errorThrown);
                }
            });
        },
        select: function (event, ui) {
            if (ui.item.val === -1)
                return false;
            else {
                $(this).val(ui.item.value);
                setControlVisibility();
                getPolishedSieveSizeData();
            }
        }
    });
});

function getPolishedSieveSizeData(sortColumn, sortDirection) {
    var name = $('#Name').val();
    var minSieveSizeId = $('#MinSieveSizeId').val();
    var maxSieveSizeId = $('#MaxSieveSizeId').val();
    var entryStatus = $('#EntryStatus :selected').val();
    var dateFrom = $('#EffectiveFromStartDate').val();
    var dateTo = $('#EffectiveFromEndDate').val();
    var parentSize = $('#ParentSize').val();
    var pageSize = $('#ddlPageSize :selected').val();
    var pageNumber = $('#pageNumber').val();

    if (isNaN(pageNumber) || pageNumber === '0') {
        pageNumber = '1';
    }
    sendRequest("GET", "GetPolishedSieveSizeDetails",
        {
            Name: name,
            MinSieveSizeId: minSieveSizeId,
            MaxSieveSizeId: maxSieveSizeId,
            EntryStatus: entryStatus,
            EffectiveFromStartDate: dateFrom,
            EffectiveFromEndDate: dateTo,
            ParentSize: parentSize,
            SortColumn: sortColumn,
            SortDirection: sortDirection,
            PageSize: pageSize,
            PageNumber: pageNumber
        }, "application/json; charset=utf-8", "json", bindPolishedSieveSizeData);
}

function bindPolishedSieveSizeData(data) {
    if (data !== null && data !== "Error") {

        totalPages = data.totalPages;
        totalRecords = data.totalRecords;

        var dt = $('#polishedSieveSizeTable').DataTable({
            "destroy": true,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            "scrollCollapse": true,
            "scrollY": '50vh',
            "columnDefs": [
                {
                    targets: [2, 3, 4, 5, 6],
                    className: 'dt-body-right'
                },
                {
                    targets: [0, 1, 7, 8],
                    className: 'dt-body-center'
                }
            ],
            "aaData": data.polishedSieveSizeDetails,
            "aoColumns": [
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        $('.gridHeaderEdit').removeClass('sorting_asc');
                        return '<a href="Edit?polishedSieveSizeId=' + full.Id + '" title="Edit" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="glyphicon glyphicon-edit"></span>' +
                            '</a>';
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        return '<a href="Detail?polishedSieveSizeId=' + full.Id + '" title="Detail" class="loadingProcess btn-edit linkEdit">' +
                            '<span class="fa fa-eye"></span>' +
                            '</a>';
                    }
                },
                {
                    "mData": "Name"
                },
                {
                    "mData": "MinSieveSize",
                    "render": function (id, type, full, meta) {
                        return full.MinSieveSize !== null ? full.MinSieveSize : "-";
                    }
                },
                {
                    "mData": "MaxSieveSize",
                    "render": function (id, type, full, meta) {
                        return full.MaxSieveSize !== null ? full.MaxSieveSize : "-";
                    }
                },
                {
                    "mData": "ParentPolishedSieveSize",
                    "render": function (id, type, full, meta) {
                        return full.ParentPolishedSieveSize !== null ? full.ParentPolishedSieveSize : "-";
                    }
                },
                {
                    "mData": "EffectiveFrom"
                },
                {
                    "mData": "IsPointerApply",
                    "render": function (id, type, full, meta) {
                        var IsPointerApply = null;
                        if (full.IsPointerApply) {
                            IsPointerApply = '</span><i class="fa fa-check-square-o fa-lg text-success"></i>'
                        }
                        else {
                            IsPointerApply = '<i class="color-disable fa fa-check-square-o fa-lg text-success"></i>'
                        }
                        return IsPointerApply;
                    }
                },
                {
                    "mdata": "Id",
                    "render": function (id, type, full, meta) {
                        var deleteActivate = full.IsActive === true ? "Delete" : "Activate";
                        return '<a href="Delete?polishedSieveSizeId=' + full.Id + '" title="' + (deleteActivate === "Delete" ? "Delete" : "Activate") + '" class="btn-delete" onclick = "return confirmDeleteActivate(' + full.IsActive + ');">' +
                            (deleteActivate === "Delete" ? '<span class="glyphicon glyphicon-trash"></span></a>' : '<span class="glyphicon glyphicon-ok"></span>') +
                            '</a>';
                    }
                }
            ],
            "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                if (!aData.IsActive) {
                    $(nRow).addClass('danger');
                }
            }
        });
        $('#totalPages').html(data.totalPages);
        $('#minPageIndex').html(data.totalRecords > 0 ? parseInt(data.minPageIndex + 1) : parseInt(0));
        $('#maxPageIndex').html(data.maxPageIndex);
        $('#totalRecords').html(data.totalRecords);
        managePagingButtonsVisibility(totalRecords, totalPages);

        $('.loadingProcess').click(function () {
            showElement('.loadingDiv');
        });
    }
    hideElement('.loadingDiv');
}