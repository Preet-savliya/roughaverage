﻿using System.Web.Optimization;

namespace SD.Rough.Average.Web.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jquery-ui").Include(
                "~/scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                "~/scripts/jquery.validate*",
                "~/scripts/jquery.unobtrusive*"));

            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                "~/scripts/vendor/modernizr/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                "~/scripts/vendor/bootstrap/bootstrap.js"));

            bundles.Add(new ScriptBundle("~/bundles/moment").Include(
               "~/scripts/moment.js"));

            bundles.Add(new ScriptBundle("~/bundles/datetimepickers").Include(
               "~/scripts/bootstrap-datetimepicker.js"));

            bundles.Add(new ScriptBundle("~/bundles/vendorcommon").Include(
                "~/scripts/vendor/moment.js"));

            bundles.Add(new ScriptBundle("~/bundles/datatables").Include(
               "~/scripts/DataTables/jquery.dataTables.min.js",
               "~/scripts/DataTables/dataTables.bootstrap.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/appcommon").Include(
                "~/scripts/app/common/*.js"));

            bundles.Add(new ScriptBundle("~/bundles/subRoughIndex").Include(
                "~/scripts/app/subrough/subrough.js",
                "~/scripts/app/subrough/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/subRoughAddEdit").Include(
                "~/scripts/app/subrough/subrough-add-edit.js"));

            bundles.Add(new ScriptBundle("~/bundles/lotIndex").Include(
                "~/scripts/app/lot/lot.js",
                "~/scripts/app/lot/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/lotAddEdit").Include(
                "~/scripts/app/lot/lot-add-edit.js",
                "~/scripts/app/subrough/modalsubrough.js",
                "~/scripts/app/subrough/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/lotImport").Include(
                "~/scripts/app/lotimport/lotimport.js",
                "~/scripts/app/lotimport/modalsubrough.js",
                "~/scripts/app/subrough/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/subRoughAvgDetail").Include(
                "~/scripts/app/subroughaverage/details.js"));

            bundles.Add(new ScriptBundle("~/bundles/sizeClarityIndex").Include(
                "~/scripts/app/sizeclarity/sizeclarity.js",
                "~/scripts/app/subroughaverage/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/sizeClarityDetail").Include(
                "~/scripts/app/sizeclarity/sizeclaritydetail.js"));

            bundles.Add(new ScriptBundle("~/bundles/lotSizeReportIndex").Include(
                "~/scripts/app/lotsizereport/lotsizereport.js",
                "~/scripts/app/subroughaverage/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/lotSizeDetail").Include(
                "~/scripts/app/lotsizereport/lotsizedetail.js"));

            bundles.Add(new ScriptBundle("~/bundles/topsReportIndex").Include(
                "~/scripts/app/topsreport/topsreport.js",
                "~/scripts/app/subroughaverage/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/subRoughAvgIndex").Include(
                "~/scripts/app/subroughaverage/subroughaverage.js",
                "~/scripts/app/subroughaverage/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/employeeIndex").Include(
                "~/scripts/app/employee/employee.js",
                "~/scripts/app/employee/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/measureTypeIndex").Include(
               "~/scripts/app/measuretype/measuretype.js",
               "~/scripts/app/measuretype/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/machineTypeIndex").Include(
              "~/scripts/app/machinetype/machinetype.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughTypeIndex").Include(
              "~/scripts/app/roughtype/roughtype.js",
              "~/scripts/app/roughtype/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughSizeIndex").Include(
             "~/scripts/app/roughsize/roughsize.js"));

            bundles.Add(new ScriptBundle("~/bundles/sieveSizeFileImportIndex").Include(
                "~/scripts/app/sievesizefileimport/sievesizefileimport.js",
                "~/scripts/app/sievesizefileimport/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/diametersievesizeDetail").Include(
                "~/scripts/app/diametersievesize/diametersievesize.js",
                "~/scripts/app/diametersievesize/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/machineIndex").Include(
                "~/scripts/app/machine/machine.js",
                "~/scripts/app/machine/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/planningLevelIndex").Include(
                "~/scripts/app/planninglevel/planninglevel.js",
                "~/scripts/app/planninglevel/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/clarityIndex").Include(
                "~/scripts/app/clarity/clarity.js",
                "~/scripts/app/clarity/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/shapeIndex").Include(
               "~/scripts/app/shape/shape.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughCategoryIndex").Include(
               "~/scripts/app/roughcategory/roughcategory.js"));

            bundles.Add(new ScriptBundle("~/bundles/lossTypeIndex").Include(
               "~/scripts/app/losstype/losstype.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughColorShadeIndex").Include(
               "~/scripts/app/roughcolorshade/roughcolorshade.js",
               "~/scripts/app/roughcolorshade/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/sieveSizeIndex").Include(
              "~/scripts/app/sievesize/sievesize.js",
              "~/scripts/app/sievesize/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/colorIndex").Include(
               "~/scripts/app/color/color.js"));

            bundles.Add(new ScriptBundle("~/bundles/rateIndex").Include(
              "~/scripts/app/rate/rate.js",
               "~/scripts/app/rate/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/rateaddedit").Include(
              "~/scripts/app/rate/rateaddedit.js"));

            bundles.Add(new ScriptBundle("~/bundles/colorRateVersionIndex").Include(
               "~/scripts/app/colorrateversion/colorrateversion.js"));

            bundles.Add(new ScriptBundle("~/bundles/topsParameterAddEdit").Include(
               "~/scripts/app/topsparameter/topsparameter-add-edit.js"));

            bundles.Add(new ScriptBundle("~/bundles/topsParameterIndex").Include(
             "~/scripts/app/topsparameter/topsparameter.js",
             "~/scripts/app/topsparameter/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/polishedSieveSizeAddEdit").Include(
               "~/scripts/app/polishedsievesize/polishedsievesize-add-edit.js"));

            bundles.Add(new ScriptBundle("~/bundles/polishedSieveSizeIndex").Include(
             "~/scripts/app/polishedsievesize/polishedsievesize.js",
             "~/scripts/app/polishedsievesize/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughSizeSieveSizeAddEdit").Include(
              "~/scripts/app/roughsizesievesize/roughsizesievesize-add-edit.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughSizeSieveSizeIndex").Include(
             "~/scripts/app/roughsizesievesize/roughsizesievesize.js",
             "~/scripts/app/roughsizesievesize/paging.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughCategoryRoughTypeIndex").Include(
             "~/scripts/app/roughcategoryroughtype/roughcategoryroughtype.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughSizePolishedSieveSize").Include(
             "~/scripts/app/roughsizepolishedsievesize/roughsizepolishedsievesize.js"));

            bundles.Add(new ScriptBundle("~/bundles/roughSizePolishedSieveSizeAdd").Include(
            "~/scripts/app/roughsizepolishedsievesize/roughsizepolishedsievesize-add.js"));

            bundles.Add(new ScriptBundle("~/bundles/sticker").Include(
                "~/scripts/vendor/JsBarcode.all.min.js",
                "~/scripts/vendor/qrcode.min.js"));

            // CSS bundles
            bundles.Add(new StyleBundle("~/Content/css").Include(
                "~/Content/bootstrap*",
                "~/Content/bootstrap-*",
                "~/Content/style.css",
                "~/Content/font-awesome*"));

            bundles.Add(new StyleBundle("~/Content/themes/base/jquery-ui").Include(
               "~/Content/themes/base/*.css"));

            bundles.Add(new StyleBundle("~/Content/print").Include(
                "~/Content/print.css"));

            bundles.Add(new StyleBundle("~/Content/print-landscape").Include(
                "~/Content/print-landscape.css"));

            bundles.Add(new StyleBundle("~/Content/sticker").Include(
                "~/Content/print-sticker.css"));

            //BundleTable.EnableOptimizations = true;
        }
    }
}