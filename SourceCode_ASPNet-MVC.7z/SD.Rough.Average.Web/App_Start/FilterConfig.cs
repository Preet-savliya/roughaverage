﻿using System.Web.Mvc;

namespace SD.Rough.Average.Web.App_Start
{
    using Common;
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new AuthorizeAttribute());
            filters.Add(new GlobalErrorHandlerAttribute());
        }
    }
}