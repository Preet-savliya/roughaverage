﻿using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SD.Rough.Average.Services
{
    public class MachineService : Service<Machine>, IMachineService
    {
        private IRepository<Machine> _repository; 

        public MachineService(IUnitOfWork unitOfWork, IRepository<Machine> repository) : base(unitOfWork)
        {
            _repository = repository;
        }

        public IEnumerable<ValidationResult> ValidateMachineNoUniqueness(Machine machine)
        {

            var machineEntry = _repository
                .FirstOrDefault(m => m.Number == machine.Number && m.Id != machine.Id);

            var errors = new List<ValidationResult>();
            if (machineEntry != null)
            {
                if (machineEntry.IsActive)
                    errors.Add(new ValidationResult($"Machine Number - {machine.Number} entry is already exists"));
                else
                    errors.Add(new ValidationResult($"Machine Number - {machine.Number} entry is already exists but status is deleted"));
            }

            return errors;
        }
    }
}
