﻿namespace SD.Rough.Average.Services
{
    using System.Linq;
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class RoughSizeSieveSizeService : Service<RoughSizeSieveSize>, IRoughSizeSieveSizeService
    {
        #region PrivateFields
        private IRepository<RoughSizeSieveSize> _repository;
        #endregion

        #region Ctor
        public RoughSizeSieveSizeService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<RoughSizeSieveSize>();
        }
        #endregion

        #region Method
        public string CheckNameAndRoughSizeIsUnique(string name, int roughSizeId, int roughSizeSieveSizeId)
        {
            string roughSizeSieveSizeName = name.Trim();

            RoughSizeSieveSize roughSizeSieveSize = _repository.Get(m => (m.Name == roughSizeSieveSizeName
                      && m.RoughSizeId == roughSizeId
                      && m.Id != roughSizeSieveSizeId))
                      .FirstOrDefault();

            if (roughSizeSieveSize == null)
            {
                return null;
            }

            return roughSizeSieveSize.IsActive
              ? $"Rough size Sieve Size with same name is already exists for the selected Rough Size"
              : $"Rough size Sieve Size with same name is already exists for the selected Rough Size but status is deleted";
        }

        public string ValidateMinSieveSizeAndMaxSieveSize(int? MinSieveSizeId, int? MaxSieveSizeId)
        {
            string error = null;

            if (!MinSieveSizeId.HasValue && !MaxSieveSizeId.HasValue)
            {
                error = "Min Sieve Size or Max Sieve Size one of the required";
            }

            return error;
        }
        #endregion
    }
}
