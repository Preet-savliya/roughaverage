﻿using System.Linq;
using System.Text;
using SD.Rough.Average.Core;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using static SD.Rough.Average.Core.AppGlobalSettings;
using static SD.Rough.Average.Services.Shared.UtilityMethods;

namespace SD.Rough.Average.Services
{
    public class LotService : Service<Lot>, ILotService
    {
        public LotService(IUnitOfWork unitOfWork) : base(unitOfWork) { }

        public bool ValidateTopsType(TopsType subRoughTopsType, TopsType lotTopsType)
        {
            if (lotTopsType == TopsType.Many)
                return false;

            if (subRoughTopsType == lotTopsType)
                return true;

            if (subRoughTopsType == TopsType.None || lotTopsType == TopsType.None)
                return true;

            return false;
        }

        public bool TryParseLotFileName(string fileName, int lotId)
        {
            if (string.IsNullOrWhiteSpace(fileName))
                return false;

            string[] fileNameParts = fileName.Split(FileExtensionSeparator);
            if (fileNameParts.Length <= 1)
                return false;

            var lotParameterParts = fileNameParts[0].Trim().Split(new char[] { FileNameSeparator }, 2);
            if (lotParameterParts.Length < 2)
                return false;

            var isPieceCountValid = int.TryParse(lotParameterParts[0], out int pieces);
            bool isWeightValid = TryGetWeightFromString(lotParameterParts[1], out decimal lotWeight);

            if (isPieceCountValid && isWeightValid)
            {
                var dbLot = Get(l => l.Id == lotId).Select(l => new { l.PieceCount, l.Weight }).FirstOrDefault();
                return pieces == dbLot.PieceCount && lotWeight == dbLot.Weight;
            }
            return false;
        }
    }
}