﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;

namespace SD.Rough.Average.Services
{
    public class NonMakeableStoneService : Service<NonMakeableStone>, INonMakeableStoneService
    {
        #region PrivateFields
        private IRepository<NonMakeableStone> _repository;
        #endregion

        #region Ctor
        public NonMakeableStoneService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<NonMakeableStone>();
        }
        #endregion

        #region Methods
        #endregion
    }
}
