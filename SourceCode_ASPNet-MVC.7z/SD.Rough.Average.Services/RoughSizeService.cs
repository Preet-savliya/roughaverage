﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Interface;

    public class RoughSizeService : Service<RoughSize>, IRoughSizeService
    {
        #region Fields
        private IRepository<RoughSize> _repository;
        #endregion

        #region Ctor
        public RoughSizeService(IUnitOfWork unitOfWork,
            IRepository<RoughSize> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckNameIsUnique(string name, int roughSizeId)
        {
            RoughSize roughSize = _repository
                .FirstOrDefault(m => m.Name == name.Trim() && m.Id != roughSizeId);

            if (roughSize == null)
            {
                return null;
            }

            return roughSize.IsActive
               ? "Rough size entry with name is already exists"
               : "Rough size entry with name is already exists but marked as deleted";
        }
        public string CheckDisplayNameIsUnique(string displayName, int roughSizeId)
        {
            RoughSize roughSize = _repository
               .FirstOrDefault(m => m.DisplayName == displayName.Trim() && m.Id != roughSizeId);

            if (roughSize == null)
            {
                return null;
            }

            return roughSize.IsActive
               ? "Rough size entry with display name is already exists"
               : "Rough size entry with display name is already exists but marked as deleted";
        }

        public string CheckDisplayOrderIsUnique(int displayOrder, int roughSizeId)
        {
            RoughSize roughSize = _repository
               .FirstOrDefault(m => m.DisplayOrder == displayOrder && m.Id != roughSizeId);

            if (roughSize == null)
            {
                return null;
            }

            return roughSize.IsActive
               ? "Rough size entry with display order is already exists"
               : "Rough size entry with display order is already exists but marked as deleted";
        }
        #endregion
    }
}
