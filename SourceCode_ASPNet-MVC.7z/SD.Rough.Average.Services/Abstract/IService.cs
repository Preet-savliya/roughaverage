﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;

namespace SD.Rough.Average.Services.Abstract
{
    public interface IService<TEntity> : IDisposable where TEntity : class
    {
        #region RepositoryMethods

        #region ReadMethods
        TEntity GetById(int id);
        IList<TEntity> GetAll();

        IList<TEntity> GetWithTracking(Expression<Func<TEntity, bool>> predicate);
        IList<TEntity> Get(Expression<Func<TEntity, bool>> predicate);
        IList<TEntity> Get(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties);

        TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate);
        TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties);

        IQueryable<TEntity> Select(Expression<Func<TEntity, bool>> predicate = null,
                Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                List<Expression<Func<TEntity, object>>> includeProperties = null,
                int? page = null, int? pageSize = null);

        // TODO: Refactoring - Do not expose IQueryable from repository
        IQueryable<TEntity> SelectForCount(Expression<Func<TEntity, bool>> predicate,
            params Expression<Func<TEntity, object>>[] includeProperties);

        bool IsEntryExists(TEntity entity);
        bool IsEntryExists(Expression<Func<TEntity, bool>> predicate);
        #endregion

        #region DataChangesMethods
        TEntity Add(TEntity entity, int userId);
        IList<TEntity> AddMany(IEnumerable<TEntity> entities, int userId);

        TEntity Update(TEntity entity, int userId);
        IList<TEntity> UpdateMany(IEnumerable<TEntity> entities, int userId);

        /// <summary>
        /// Soft Delete
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="userId"></param>
        TEntity DeActivate(TEntity entity, int userId);
        /// <summary>
        /// Soft Delete
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="userId"></param>
        IList<TEntity> DeActivateMany(IEnumerable<TEntity> entities, int userId);

        TEntity Activate(TEntity entity, int userId);
        IList<TEntity> ActivateMany(IEnumerable<TEntity> entities, int userId);

        void Delete(int id);

        /// <summary>
        /// Hard Delete
        /// </summary>
        /// <param name="entity"></param>
        void Delete(TEntity entity);

        /// <summary>
        /// Hard Delete
        /// </summary>
        /// <param name="entities"></param>
        void DeleteMany(IEnumerable<TEntity> entities);
        #endregion

        #endregion
    }
}
