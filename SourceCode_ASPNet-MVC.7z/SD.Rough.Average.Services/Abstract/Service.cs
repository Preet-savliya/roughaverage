﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;

namespace SD.Rough.Average.Services.Abstract
{
    public class Service<TEntity> : IService<TEntity> where TEntity : BaseEntity
    {
        #region PrivateFields
        private readonly IUnitOfWork _unitOfWork;
        #endregion

        #region Ctor
        protected Service(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        #endregion

        #region Properties
        protected IUnitOfWork UnitOfWork => _unitOfWork;
        #endregion

        #region RepositoryMethods

        #region ReadMethods
        public virtual TEntity GetById(int id) => UnitOfWork.Repository<TEntity>().GetById(id);
        public virtual IList<TEntity> GetAll() => UnitOfWork.Repository<TEntity>().GetAll();
        public virtual IList<TEntity> Get(Expression<Func<TEntity, bool>> predicate) => UnitOfWork.Repository<TEntity>().Get(predicate);
        public virtual IList<TEntity> GetWithTracking(Expression<Func<TEntity, bool>> predicate) => UnitOfWork.Repository<TEntity>().GetWithTracking(predicate);
        public virtual IList<TEntity> Get(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties) => UnitOfWork.Repository<TEntity>().Get(predicate, includeProperties);

        public TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate) => UnitOfWork.Repository<TEntity>().FirstOrDefault(predicate);
        public TEntity FirstOrDefault(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties) => UnitOfWork.Repository<TEntity>().FirstOrDefault(predicate, includeProperties);

        public IQueryable<TEntity> Select(Expression<Func<TEntity, bool>> predicate = null,
                Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
                List<Expression<Func<TEntity, object>>> includeProperties = null,
                int? page = null, int? pageSize = null) 
            => UnitOfWork.Repository<TEntity>().Select(predicate, orderBy, includeProperties, page, pageSize);

        public IQueryable<TEntity> SelectForCount(Expression<Func<TEntity, bool>> predicate,
            params Expression<Func<TEntity, object>>[] includeProperties) 
            => UnitOfWork.Repository<TEntity>().Select(predicate, includeProperties);

        public bool IsEntryExists(TEntity entity) => UnitOfWork.Repository<TEntity>().IsEntryExists(entity);

        public bool IsEntryExists(Expression<Func<TEntity, bool>> predicate) => UnitOfWork.Repository<TEntity>().IsEntryExists(predicate);
        #endregion

        #region DataChangesMethods
        public virtual TEntity Add(TEntity entity, int userId)
        {
            entity.CreatedBy = userId;
            return UnitOfWork.Repository<TEntity>().Add(entity);
        }
        public virtual IList<TEntity> AddMany(IEnumerable<TEntity> entities, int userId)
        {
            foreach (var entity in entities)
                entity.CreatedBy = userId;

            return UnitOfWork.Repository<TEntity>().AddMany(entities);
        }

        public virtual TEntity Update(TEntity entity, int userId)
        {
            entity.ModifiedBy = userId;
            return UnitOfWork.Repository<TEntity>().Update(entity);
        }
        public virtual IList<TEntity> UpdateMany(IEnumerable<TEntity> entities, int userId)
        {
            foreach (var entity in entities)
                entity.ModifiedBy = userId;

            return UnitOfWork.Repository<TEntity>().UpdateMany(entities);
        }

        /// <summary>
        /// Soft Delete
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="userId"></param>
        public virtual TEntity DeActivate(TEntity entity, int userId)
        {
            entity.IsActive = false;
            entity.ModifiedBy = userId;

            return UnitOfWork.Repository<TEntity>().Update(entity);
        }
        /// <summary>
        /// Soft Delete
        /// </summary>
        /// <param name="entities"></param>
        /// <param name="userId"></param>
        public virtual IList<TEntity> DeActivateMany(IEnumerable<TEntity> entities, int userId)
        {
            foreach (var entity in entities)
            {
                entity.IsActive = false;
                entity.ModifiedBy = userId;
            }

            return UnitOfWork.Repository<TEntity>().UpdateMany(entities);
        }

        public virtual TEntity Activate(TEntity entity, int userId)
        {
            entity.IsActive = true;
            entity.ModifiedBy = userId;

            return UnitOfWork.Repository<TEntity>().Update(entity);
        }
        public virtual IList<TEntity> ActivateMany(IEnumerable<TEntity> entities, int userId)
        {
            foreach (var entity in entities)
            {
                entity.IsActive = true;
                entity.ModifiedBy = userId;
            }

            return UnitOfWork.Repository<TEntity>().UpdateMany(entities);
        }

        public virtual void Delete(int id) => UnitOfWork.Repository<TEntity>().Delete(id);

        /// <summary>
        /// Hard Delete
        /// </summary>
        /// <param name="entity"></param>
        public virtual void Delete(TEntity entity) => UnitOfWork.Repository<TEntity>().Delete(entity);
        /// <summary>
        /// Hard Delete
        /// </summary>
        /// <param name="entity"></param>
        public virtual void DeleteMany(IEnumerable<TEntity> entities) => UnitOfWork.Repository<TEntity>().DeleteMany(entities);
        #endregion

        #endregion

        #region CommonMethods
        public void Dispose()
        {
            if (_unitOfWork != null)
            {
                _unitOfWork.Dispose();
            }

            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
