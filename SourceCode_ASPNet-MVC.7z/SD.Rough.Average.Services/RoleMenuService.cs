﻿using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using System.Collections.Generic;
using System.Linq;

namespace SD.Rough.Average.Services
{
    public class RoleMenuService : Service<RoleMenu>, IRoleMenuService
    {
        #region Ctor
        private IRepository<RoleMenu> _repository;
        public RoleMenuService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<RoleMenu>();
        }
        #endregion

        #region Methods
        public IList<RoleMenu> GetAllRoleMenuByID(int roleID) => _repository.GetAll().Where(m => m.RoleId == roleID && m.IsActive).ToList();
        #endregion

    }
}
