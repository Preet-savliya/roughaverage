﻿using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;

namespace SD.Rough.Average.Services
{
    public class StoneService : Service<Stone>, IStoneService
    {
        private IRepository<Stone> _repository;

        public StoneService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<Stone>();
        }

        public ICollection<Lot> DeActivateStones(ICollection<Lot> lots, int userId)
        {
            foreach (Lot lot in lots)
            {
                DeActivateMany(lot.Stones, userId);
            }

            return lots;
        }
    }
}
