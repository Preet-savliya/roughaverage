﻿using System;
using System.Web.Security;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;

namespace SD.Rough.Average.Services
{
    public class AuthenticationService : Service<AppUser>, IAuthenticationService
    {
        #region PrivateFields
        private IRepository<AppUser> _repository;
        private IUnitOfWork _unitOfWork;
        AppUser updateUser = new AppUser();
        #endregion

        #region Ctor
        public AuthenticationService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<AppUser>();
            _unitOfWork = unitOfWork;
        }
        #endregion

        #region Methods
        public void Login(string loginId, int userId, bool rememberMe = false)
        {
            if (loginId != null)
            {
                updateUser = _repository.FirstOrDefault(x => x.Id == userId && x.IsActive);
                updateUser.LastLoginOn = DateTime.Now;
                
                _repository.Update(updateUser);
                _unitOfWork.Save();
            }
        }

        public void Logout() => FormsAuthentication.SignOut();
        #endregion
    }
}
