﻿namespace SD.Rough.Average.Services
{
    using System;
    using System.Linq;
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class RoughSizePolishedSieveSizeService : Service<RoughSizePolishedSieveSize>, IRoughSizePolishedSieveSizeService
    {
        #region PrivateFields
        private IRepository<RoughSizePolishedSieveSize> _repository;
        #endregion 

        #region Ctor
        public RoughSizePolishedSieveSizeService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<RoughSizePolishedSieveSize>();
        }
        #endregion

        #region Method
        public string CheckRoughSizeWisePolishedSieveSizeIsUnique(int roughSizeId, int polishedSieveSizeId, DateTime effectiveFrom, int roughSizePolishedSieveSizeId)
        {
            RoughSizePolishedSieveSize roughSizePolishedSieveSize = _repository.Get(m => (m.RoughSizeId == roughSizeId
                      && m.PolishedSieveSizeId == polishedSieveSizeId
                      && m.EffectiveFrom == effectiveFrom
                      && m.Id != roughSizePolishedSieveSizeId))
                      .FirstOrDefault();

            if (roughSizePolishedSieveSize == null)
            {
                return null;
            }

            return roughSizePolishedSieveSize.IsActive
              ? $"Rough Size Polished Sieve Size with same Rough Size is already exists for the selected Polised Sieve Size"
              : $"Rough Size Polished Sieve Size with same Rough Size is already exists for the selected Polised Sieve Size but status is deleted";
        }
        #endregion
    }
}
