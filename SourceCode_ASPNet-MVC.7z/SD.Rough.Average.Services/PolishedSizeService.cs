﻿using System;
using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using static SD.Rough.Average.Services.Shared.SizeExtensions;

namespace SD.Rough.Average.Services
{
    public class PolishedSizeService : Service<PolishedSieveSize>, IPolishedSizeService
    {
        private IRepository<PolishedSieveSize> _repository;
        private IDiameterSieveService _diameterSieveService;

        public PolishedSizeService(IUnitOfWork unitOfWork,
            IDiameterSieveService diameterSieveService) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<PolishedSieveSize>();
            _diameterSieveService = diameterSieveService;
        }

        public IList<PolishedSieveSize> GetPolishedSieveSizeWithDiameters(IList<PolishedSieveSize> polishedSieveSizes, SubRough subRough)
        {
            //IList<PolishedSieveSize> polishedSieveSizes = polishedSieveSize
            //    .Where(x => x.EffectiveFrom <= EffectiveDate)
            //    .ToList();

            //DateTime TopMostEffectiveDateAsOn = polishedSieveSizes
            //    .Where(x => x.IsActive)
            //    .Select(s => s.EffectiveFrom)
            //    .Distinct()
            //    .OrderByDescending(x => x)
            //    .Max();

            //IList<DiameterSieveSize> diameterSieveSizes = _diameterSieveService.Get(x => x.IsActive);

            //IList<DiameterSieveSize> diameterSieveSizes = _diameterSieveService
            //    .Get(x => x.EffectiveFrom <= asOnDate)
            //    .GroupBy(x => x.SieveSizeId)
            //    .Select((IGrouping<int, DiameterSieveSize> grp) => new
            //    {
            //        grp.Key,
            //        Diameter = grp.OrderByDescending(a => a.EffectiveFrom).FirstOrDefault()
            //    })
            //    .Where(x => x.Diameter.IsActive)
            //    .Select(x => x.Diameter)
            //    .ToList();

            List<DiameterSieveSize> diameterSieveSizes = new List<DiameterSieveSize>();

            if (subRough.SieveSizeFileImportId > 0 && subRough.SieveSizeFileImport != null)
                diameterSieveSizes.AddRange(subRough.SieveSizeFileImport.DiameterSieveSizes);
            else
                diameterSieveSizes = _diameterSieveService.GetDiametersAsOn(subRough.AssignedOn).ToList();

            IList<PolishedSieveSize> polSieveSizeWithDiameters = (from polSieveSize in polishedSieveSizes
                                                                  join minDiameter in diameterSieveSizes on polSieveSize.MinSieveSizeId equals minDiameter.SieveSizeId into minJoinData
                                                                  join maxDiameter in diameterSieveSizes on polSieveSize.MaxSieveSizeId equals maxDiameter.SieveSizeId into maxJoinData
                                                                  from minRes in minJoinData.DefaultIfEmpty()
                                                                  from maxRes in maxJoinData.DefaultIfEmpty()
                                                                  select new PolishedSieveSize
                                                                  {
                                                                      Id = polSieveSize.Id,
                                                                      Name = polSieveSize.Name,
                                                                      MinSieveSizeId = polSieveSize.MinSieveSizeId,
                                                                      MinSieveSize = polSieveSize.MinSieveSize,
                                                                      MinDiameter = minRes?.Diameter ?? null,
                                                                      MaxSieveSizeId = polSieveSize.MaxSieveSizeId,
                                                                      MaxSieveSize = polSieveSize.MaxSieveSize,
                                                                      MaxDiameter = maxRes?.Diameter ?? null,
                                                                      ParentId = polSieveSize.ParentId
                                                                  }).ToList();

            //IList<PolishedSieveSize> resultData = polishedSieveSize
            //    .GroupBy(x => new { x.MinSieveSizeId, x.MaxSieveSizeId})
            //    .Select(grp => new
            //    {
            //        grp.Key,
            //        Rate = grp
            //        .Where(x => x.EffectiveFrom <= TopMostEffectiveDateAsOn)
            //        .OrderByDescending(y => y.EffectiveFrom)
            //        .FirstOrDefault()
            //    })
            //    .Where(n => n.Rate != null)
            //    .Select(s => s.Rate)
            //    .ToList();

            //return resultData;

            return polSieveSizeWithDiameters;
        }

        public IEnumerable<PolishedSieveSize> GetPolishedSieveSizeAsOn(DateTime asOnDate)
        {
            IList<PolishedSieveSize> polishedSieveSizes = _repository
                    .Get(x => x.EffectiveFrom <= asOnDate && x.ParentId == null)
                    .GetAsOnDetail(asOnDate);

            return polishedSieveSizes;
        }

        public string CheckMinSieveSizeMaxSieveSizeParentIdIsActiveAndEffectiveDateIsUnique
            (int? minSieveSizeId, int? maxSieveSizeId, DateTime effectiveFrom, int? parentId, int polishedSieveSizeId)
        {
            PolishedSieveSize polishedSieveSize = _repository
                .Get(m => (m.MinSieveSizeId == minSieveSizeId && m.MaxSieveSizeId == maxSieveSizeId
                && m.EffectiveFrom == effectiveFrom && m.ParentId == parentId && m.IsActive
                && m.Id != polishedSieveSizeId))
                .FirstOrDefault();

            if (polishedSieveSize == null)
            {
                return null;
            }

            return polishedSieveSize.IsActive
              ? $"Polished Sieve Size with same min sieve size, max sieve size and parent size is already exists for the selected effective date"
              : $"Polished Sieve Size with same min sieve size, max sieve size and parent size is already exists for the selected effective date but status is deleted";
        }

        public string ValidateMinSieveSizeAndMaxSieveSize(int? minSieveSizeId, int? maxSieveSizeId)
        {
            string error = null;

            if (!minSieveSizeId.HasValue && !maxSieveSizeId.HasValue)
            {
                error = "Min Sieve Size or Max Sieve Size one of the required";
            }

            return error;
        }
    }
}
