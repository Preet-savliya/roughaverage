﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;

namespace SD.Rough.Average.Services
{
    public class ExtraMakeableStoneService : Service<ExtraMakeableStone>, IExtraMakeableStoneService
    {
        #region PrivateFields
        private IRepository<ExtraMakeableStone> _repository;
        #endregion

        #region Ctor
        public ExtraMakeableStoneService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<ExtraMakeableStone>();
        }
        #endregion

        #region Methods
        #endregion
    }
}
