﻿using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;

namespace SD.Rough.Average.Services
{
    public class DesignationService : Service<Designation>, IDesignationService
    {
        #region Ctor
        public DesignationService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
        #endregion
    }
}
