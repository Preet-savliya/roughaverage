﻿using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;

namespace SD.Rough.Average.Services
{
    public class LotStoneTopsParameterService : Service<LotStoneTopsParameter>, ILotStoneTopsParameterService
    {
        private IRepository<LotStoneTopsParameter> _repository;
        private IRepository<StoneTopsParameter> _stoneTopsRepository;

        public LotStoneTopsParameterService(IUnitOfWork unitOfWork,
            IRepository<LotStoneTopsParameter> repository,
            IRepository<StoneTopsParameter> stoneTopsRepository) : base(unitOfWork)
        {
            _repository = repository;
            _stoneTopsRepository = stoneTopsRepository;
        }

        //public void AddTopsParameters(IList<LotStoneTopsParameter> topsParameters, int userId)
        //{
        //    AddMany(topsParameters, userId);
        //}

        public void UpdateTopsParameters(IList<LotStoneTopsParameter> dbTopsParameters,
            IList<LotStoneTopsParameter> topsParameters, int userId)
        {
            UpdateMany(dbTopsParameters, userId);
        }

        public void DeleteTopsParameters(IList<LotStoneTopsParameter> deletedTopsParameters)
        {
            _stoneTopsRepository
                .DeleteMany(deletedTopsParameters.SelectMany(s => s.StoneTopsParameters));

            _repository
                .DeleteMany(deletedTopsParameters);
        }

        public void DeleteStoneTopsParameters(IList<StoneTopsParameter> deletedStoneTopsParameters)
        {
            _stoneTopsRepository.DeleteMany(deletedStoneTopsParameters);
        }
    }
}
