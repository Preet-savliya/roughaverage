﻿using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;

using System.Collections.Generic;
using System.Linq;

namespace SD.Rough.Average.Services
{
    public class LotAssignService : Service<LotAssign>, ILotAssignService
    {
        private IRepository<LotAssign> _repository;

        public LotAssignService(IUnitOfWork unitOfWork, IRepository<LotAssign> repository) : base(unitOfWork)
        {
            _repository = repository;
        }

        public void DeleteLotAssignDetail(IList<LotAssign> dbLotAssigns, IList<LotAssign> lotAssign)
        {
            IEnumerable<LotAssign> lotAssignToDelete = new List<LotAssign>();

            if (lotAssign.Count > 0)
                lotAssignToDelete = dbLotAssigns
                    .Where(db => !lotAssign.Any(n => n.AssignedTo == db.AssignedTo));

            if (lotAssignToDelete.Count() > 0)
                _repository.DeleteMany(lotAssignToDelete);
        }

        public void UpdateLotAssignDetail(IList<LotAssign> dbLotAssigns, IList<LotAssign> lotAssigns, int userId)
        {
            var matchedLotAssign = from newLotAssign in lotAssigns
                                   join dbLotAssign in dbLotAssigns
                                   on newLotAssign.AssignedTo equals dbLotAssign.AssignedTo
                                   select new { newLotAssign, dbLotAssign };

            if (matchedLotAssign.Count() > 0)
            {
                foreach (var lotAssign in matchedLotAssign)
                {
                    lotAssign.newLotAssign.Id = lotAssign.dbLotAssign.Id;
                    lotAssign.newLotAssign.CreatedBy = lotAssign.dbLotAssign.CreatedBy;
                    lotAssign.newLotAssign.CreatedOn = lotAssign.dbLotAssign.CreatedOn;
                }
                IEnumerable<LotAssign> lotAssignToUpdate = lotAssigns.Where(x => x.Id > 0);

                if (lotAssignToUpdate.Count() > 0)
                    UpdateMany(lotAssignToUpdate, userId);
            }
        }

        public void InsertLotAssignDetail(IList<LotAssign> lotAssigns, int userId)
        {
            IEnumerable<LotAssign> lotAssignToInsert = lotAssigns.Where(x => x.Id == 0);

            if (lotAssignToInsert.Count() > 0)
                AddMany(lotAssignToInsert, userId);
        }
    }
}
