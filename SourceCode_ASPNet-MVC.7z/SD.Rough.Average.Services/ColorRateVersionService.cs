﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;

    using SD.Rough.Average.Services.Interface;
    public class ColorRateVersionService : Service<ColorRateVersion>, IColorRateVersionService
    {
        #region Fields
        private IRepository<ColorRateVersion> _repository;
        #endregion

        #region Ctor
        public ColorRateVersionService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<ColorRateVersion>();
        }
        #endregion

        #region Method
        public string CheckColorIdNameIsUnique(int colorId, string name, int id)
        {
            string colorRateVersionName = name.Trim();
            ColorRateVersion colorRateVersion = _repository
                .FirstOrDefault(p => p.Name == colorRateVersionName
                && p.ColorId == colorId 
                && p.Id != id);

            if (colorRateVersion == null)
            {
                return null;
            }

            return colorRateVersion.IsActive
            ? $"Color Rate Version Name - {colorRateVersionName} entry is already exists for the selected color"
            : $"Color Rate Version Name - {colorRateVersionName} entry is already exists for the selected color but status is deleted";
        }
        #endregion
    }
}
