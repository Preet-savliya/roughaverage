﻿namespace SD.Rough.Average.Services
{
    using Data.Repositories;
    using Data.UnitOfWork;
    using Models;
    using Abstract;
    using Interface;
    using System.Collections.Generic;

    public class PolishedStoneService : Service<PolishedStone>, IPolishedStoneService
    {
        #region PrivateFields
        private IRepository<PolishedStone> _repository;
        #endregion

        #region Ctor
        public PolishedStoneService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<PolishedStone>();
        }
        #endregion

        #region Methods
        public ICollection<Lot> DeActivatePolishedStones(ICollection<Lot> lots, int userId)
        {
            foreach (Lot lot in lots)
            {
                foreach (Stone stone in lot.Stones)
                {
                    DeActivateMany(stone.PolishedStones, userId);
                }
            }

            return lots;
        }

        public ICollection<Stone> DeActivatePolishedStones(ICollection<Stone> stones, int userId)
        {
            foreach (Stone stone in stones)
            {
                DeActivateMany(stone.PolishedStones, userId);
            }

            return stones;
        }

        public ICollection<Stone> ActivatePolishedStones(ICollection<Stone> stones, int userId)
        {
            foreach (Stone stone in stones)
            {
                ActivateMany(stone.PolishedStones, userId);
            }

            return stones;
        }


        #endregion
    }
}
