﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System;

namespace SD.Rough.Average.Services
{
    public class SieveSizeFileImportService : Service<SieveSizeFileImport>, ISieveSizeFileImportService
    {
        #region Fields
        private IRepository<SieveSizeFileImport> _repository;
        #endregion

        #region Ctor
        public SieveSizeFileImportService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<SieveSizeFileImport>();
        }
        #endregion

        #region Method
        public IEnumerable<ValidationResult> ValidateEffectiveFromUniqueness(DateTime effectiveFrom, int id = 0)
        {
            List<ValidationResult> errors = new List<ValidationResult>();

            SieveSizeFileImport sieveSizeFileImport = _repository.FirstOrDefault(s => s.EffectiveFrom == effectiveFrom
                                                        && s.Id != id);

            if (sieveSizeFileImport != null)
            {
                errors.Add(new ValidationResult("SieveSize detail for the same effective date is already exist. Kindly delete it then try to import."));
            }

            return errors;
        }
        #endregion
    }
}
