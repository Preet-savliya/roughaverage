﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

using SD.Rough.Average.Core;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.DTO;
using SD.Rough.Average.Services.Interface;
using SD.Rough.Average.Services.Shared;

using static SD.Rough.Average.Core.AppGlobalSettings;
using static SD.Rough.Average.Core.ArrayExtensions;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;
using static SD.Rough.Average.Services.DTO.ParsedResultExtensions;

namespace SD.Rough.Average.Services
{
    public class LotFileImportService : Service<LotFile>, ILotFileImportService
    {
        private readonly IRepository<Lot> _repository;

        private readonly IEmployeeService _employeeService;
        private readonly IRoughCategoryService _roughCategoryService;
        private readonly IColorRateVersionService _colorRateVersionService;
        private readonly IClarityService _clarityService;
        private readonly IShapeService _shapeService;
        private readonly IMachineService _machineService;
        private readonly IMeasureTypeService _measureTypeService;
        private readonly IPlanningLevelService _planningLevelService;
        private readonly ISieveSizeService _sieveSizeService;
        private readonly IDiameterSieveService _diameterSieveService;
        private readonly ISarinActivityService _sarinActivityService;
        private readonly IRateService _rateService;

        private readonly ISubRoughService _subRoughService;
        private readonly IPolishedStoneService _polishedStoneService;

        // NOTE: Using Shared variables is not a good practice as per functional programming,
        // but using here for Lookup Data & Parsed-LookupData to avoid multiple parameters in methods
        private IList<Employee> _operators;
        private IList<Machine> _machines;
        private IList<MeasureType> _measureTypes;
        private IList<PlanningLevel> _planningLevels;

        private IList<Shape> _shapes;
        private IList<Clarity> _clarities;
        private IList<SieveSize> _sieveSizes;
        private IList<ColorRateVersion> _colorRateVersions;

        private IList<Rate> _rates;

        private IList<ParsedResult<DateTime>> _parsedMeasureDates;

        private IList<ParsedResult<OperatorDTO>> _parsedOperators;
        private IList<ParsedResult<MachineNumberDTO>> _parsedMachineNumbers;
        private IList<ParsedResult<MeasureTypeDTO>> _parsedMeasureTypes;
        private IList<ParsedResult<PlanningLevelDTO>> _parsedPlanningLevels;

        private IList<ParsedResult<ColorDTO>> _parsedColors;
        private IList<ParsedResult<ClarityDTO>> _parsedClarities;
        private IList<ParsedResult<ShapeDTO>> _parsedShapes;

        public LotFileImportService(IUnitOfWork unitOfWork,
            ISubRoughService subRoughService, IRoughCategoryService roughCategoryService,
            IPolishedStoneService polishedStoneService, IColorRateVersionService colorRateVersionService,
            IClarityService clarityService, IShapeService shapeService, IMachineService machineService,
            IMeasureTypeService measureTypeService, IPlanningLevelService planningLevelService,
            IEmployeeService employeeService, ISieveSizeService sieveSizeService, IRateService rateService,
            IDiameterSieveService diameterSieveService, ISarinActivityService sarinActivityService) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<Lot>();

            _roughCategoryService = roughCategoryService;
            _polishedStoneService = polishedStoneService;
            _colorRateVersionService = colorRateVersionService;
            _rateService = rateService;
            _clarityService = clarityService;
            _shapeService = shapeService;
            _machineService = machineService;
            _measureTypeService = measureTypeService;
            _planningLevelService = planningLevelService;
            _subRoughService = subRoughService;
            _employeeService = employeeService;
            _sieveSizeService = sieveSizeService;
            _diameterSieveService = diameterSieveService;
            _sarinActivityService = sarinActivityService;
        }

        public Either<Lot, List<StoneDTO>> ParseLotFiles(
            Dictionary<string, List<string>> lotAllFilesData,
            SubRough subRough, Lot lot, SarinActivityType sarinActivity,
            TopsType subRoughTopsType, TopsDiameterRange topsDiameterRange,
            IReadOnlyList<LotFileHeaderSchema> lotFileHeaderSchema,
            ColorRateVersion lotColorRateVersion, int userLoginId)
        {
            var filesParsedResult = TryParseLotFilesData(lotAllFilesData, subRough,
                lot, sarinActivity, subRoughTopsType, topsDiameterRange,
                lotFileHeaderSchema, lotColorRateVersion, userLoginId);

            if (filesParsedResult.IsFailure)
            {
                return Either<Lot, List<StoneDTO>>.Failure(filesParsedResult.Error);
            }

            var lotFile = new LotFile
            {
                LotId = lot.Id,
                // NOTE: This code needs to be refactore. First store LotFile then use its Id into stones
                Stones = filesParsedResult.Value,
            };

            var resultLot = new Lot
            {
                Id = lot.Id,
                Stones = lotFile.Stones,
                LotFiles = lotFile.Stones
                    .GroupBy(g => g.FileName)
                    .Select(s => new LotFile
                    {
                        LotId = lot.Id,
                        FileName = s.Key,
                        Stones = s.ToList()
                    }).ToList()
            };
            return Either<Lot, List<StoneDTO>>.Success(resultLot);
        }

        public Either<List<Stone>, List<StoneDTO>> TryParseLotFilesData
            (Dictionary<string, List<string>> lotAllFilesData, SubRough subRough, Lot lot,
             SarinActivityType sarinActivity, TopsType subRoughTopsType,
             TopsDiameterRange topsDiameterRange,
             IReadOnlyList<LotFileHeaderSchema> lotFileHeaderSchema,
             ColorRateVersion lotColorRateVersion, int userLoginId)
        {
            var headerSummary = LotFileHeaderSummary.Calculate(lotFileHeaderSchema);

            var lotRoughCategory = _roughCategoryService.FirstOrDefault(x => x.Id == lot.RoughCategoryId);
            var subRoughRoughCategoryNames = subRough.RoughType.RoughCategoryRoughTypes
                .Select(x => x.RoughCategory.Name.Trim())
                .ToArray();

            var lotStonesTopsParameters = sarinActivity == SarinActivityType.RoughPlanning
                ? lot.LotStoneTopsParameters?.ToList()
                : null;

            LoadLookupData(subRough);

            var sieveSizeDiameters = subRough.SieveSizeFileImportId > 0 && subRough.SieveSizeFileImport != null
                    ? subRough.SieveSizeFileImport.DiameterSieveSizes.ToList()
                    : _diameterSieveService.GetDiametersAsOn(subRough.AssignedOn).ToList();

            // NOTE: As per the current requirement, a single lot has a single ColorRateVersion so loading rates here 
            // but if the requirement is changed and per stone or polished stone/part based color rate version is introduced then
            // this logic needs to be changed
            _rates = _rateService
                .Get(x => x.ColorRateVersionId == lotColorRateVersion.Id && x.IsActive)
                .ToList();

            var files = lotAllFilesData.Keys
                .Select((value, index) => new { value, index })
                .ToDictionary(pair => pair.index, pair => pair.value);

            var parsedStones = new List<StoneDTO>();
            foreach (var fileContentEntry in lotAllFilesData)
            {
                var fileDataRows = fileContentEntry.Value
                    .Where(x => !string.IsNullOrWhiteSpace(x)).ToArray();

                foreach (var dataRow in fileDataRows)
                {
                    var parsedStone = ParseStoneAttributes(dataRow, subRough, lot, sarinActivity,
                        lotFileHeaderSchema, headerSummary, lotRoughCategory, subRoughRoughCategoryNames,
                        lotColorRateVersion, sieveSizeDiameters, topsDiameterRange, lotStonesTopsParameters);

                    parsedStone.FileName = fileContentEntry.Key;
                    parsedStones.Add(parsedStone);
                }
            }

            if (parsedStones.Any(s => s.HasError))
            {
                var invalidStones = parsedStones
                    .Where(s => s.HasError)
                    .ToList();

                return Either<List<Stone>, List<StoneDTO>>.Failure(invalidStones);
            }

            var allFilesAllStones = new List<Stone>();
            foreach (var parsedStone in parsedStones)
            {
                var stone = new Stone
                {
                    LotId = lot.Id,

                    StoneDate = parsedStone.MeasureDate.ParsedValue,
                    StoneTime = parsedStone.MeasureTime.ParsedValue
                };

                var stoneNumberValue = parsedStone.StoneNumber.ParsedValue;
                stone.StoneNumber = stoneNumberValue.StoneNumber;
                stone.StoneNumberNumeric = stoneNumberValue.NumericalStoneNumber;
                stone.IsM2Stone = stoneNumberValue.IsM2;

                stone.OpertorId = parsedStone.Operator.ParsedValue.Id;
                stone.MachineId = parsedStone.MachineNumber.ParsedValue.Id;

                stone.MeasureTypeId = parsedStone.MeasureType.ParsedValue.Id;
                stone.PlanningLevelId = parsedStone.PlanningLevel.ParsedValue.Id;

                stone.Weight = parsedStone.RoughWeight.ParsedValue;

                foreach (var ps in parsedStone.PolishStones)
                {
                    var polishStone = new PolishedStone
                    {
                        PartWeight = ps.ResultPartWeight.ParsedValue,
                        PolishedWeight = ps.PolishWeight.ParsedValue,
                        ColorRateVersionId = ps.Color.ParsedValue?.Id,
                        ClarityId = ps.Clarity.ParsedValue?.Id,
                        ShapeId = ps.Shape.ParsedValue?.Id,
                        Rate = ps.Rate.ParsedValue.Rate,
                        OldRate = ps.Rate.ParsedValue.OldRate,
                        Diameter = ps.Shape.ParsedValue.Diameter,
                        Length = ps.Shape.ParsedValue.Length,
                        MeasureByValue = ps.Rate.ParsedValue.MeasurementValue,
                        OldMeasureByValue = ps.Rate.ParsedValue.OldMeasurementValue,
                        MinSieveSizeId = ps.SieveSize.ParsedValue.MinSieveSizeId,
                        MaxSieveSizeId = ps.SieveSize.ParsedValue.MaxSieveSizeId,
                        SieveSize = ps.SieveSize.ParsedValue.Name,
                        CreatedBy = userLoginId
                    };
                    stone.PolishedStones.Add(polishStone);
                }
                stone.FileName = parsedStone.FileName;
                stone.CreatedBy = userLoginId;

                allFilesAllStones.Add(stone);
            }

            var stones = allFilesAllStones
                .GroupBy(g => g.StoneNumber.ToLower())
                .Select(s => s.OrderBy(o1 => o1.StoneDate).ThenBy(o2 => o2.StoneTime).Last())
                .OrderBy(o => o.StoneNumber)
                .ToList();

            return Either<List<Stone>, List<StoneDTO>>.Success(stones);
        }

        private ParsedResult<DateTime> TryParseMeasureDate(string inputValue)
        {
            if (_parsedMeasureDates == null)
            {
                _parsedMeasureDates = new List<ParsedResult<DateTime>>();
            }

            var result = _parsedMeasureDates
                .FirstOrDefault(x => string.Compare(x.FileValue, inputValue, true) == 0);

            if (result != null)
            {
                return result;
            }

            result = new ParsedResult<DateTime>
            {
                FileValue = inputValue
            };

            if (string.IsNullOrWhiteSpace(inputValue))
            {
                result.Errors.Add("Date is empty");
                _parsedMeasureDates.Add(result);

                return result;
            }

            var parsedDate = DateTime.TryParseExact(inputValue,
                StoneDateFormat, null, DateTimeStyles.None, out DateTime stoneDateInFile);

            if (parsedDate)
            {
                result.ParsedValue = stoneDateInFile;
            }
            else
            {
                result.Errors.Add($"Date format is invalid. It should be:'{StoneDateFormat}'.");
            }
            _parsedMeasureDates.Add(result);

            return result;
        }

        private ParsedResult<TimeSpan> TryParseMeasureTime(string inputValue)
        {
            var result = new ParsedResult<TimeSpan>
            {
                FileValue = inputValue
            };

            if (string.IsNullOrWhiteSpace(inputValue))
            {
                result.Errors.Add("Time value is empty");
                return result;
            }

            var parsedTime = TimeSpan.TryParseExact(inputValue,
                FileTimeFormatString, null, out TimeSpan stoneTimeInFile);

            if (parsedTime)
            {
                result.ParsedValue = stoneTimeInFile;
            }
            else
            {
                result.Errors.Add("Time format is invalid. It should be:'hh:mm'.");
            }

            return result;
        }

        private ParsedResult<OperatorDTO> TryParseOperator(string inputValue)
        {
            if (_parsedOperators == null)
            {
                _parsedOperators = new List<ParsedResult<OperatorDTO>>();
            }

            var result = _parsedOperators
                .FirstOrDefault(x => string.Compare(x.FileValue, inputValue, true) == 0);
            if (result != null)
            {
                return result;
            }

            result = new ParsedResult<OperatorDTO>
            {
                FileValue = inputValue
            };

            if (string.IsNullOrWhiteSpace(inputValue))
            {
                result.Errors.Add("Operator (Code or Name) is empty");
                _parsedOperators.Add(result);

                return result;
            }

            var machineOperators = _operators
                .Where(e => string.Compare(e.EmployeeNo.Trim(), inputValue, true) == 0)
                .ToList();

            // TODO: Remove below condition once employeeNo would start to use and all the files with firstname are processed.
            if (machineOperators == null || machineOperators.Count == 0)
            {
                machineOperators = _operators
                    .Where(r => string.Compare(r.FirstName.Trim(), inputValue, true) == 0)
                    .ToList();
            }

            if (machineOperators.Count == 0)
            {
                result.Errors.Add($"There is no any operator with name or employee-number {inputValue} into the system.");
            }
            else if (machineOperators.Count > 1)
            {
                result.Errors.Add($"Multiple operators with name or employee-number {inputValue} into the system.");
            }
            else
            {
                var machineOperator = machineOperators.First();

                // NOTE: Check of Employee is de-activated is excluded intentionally
                //if (!machineOperator.IsActive)
                //{
                //    existingParsedOperator.Error = $"This operator with name or employee-number {inputValue}, is de-activated into the system.";
                //}

                result.ParsedValue = new OperatorDTO
                {
                    Id = machineOperator.Id,
                    Code = machineOperator.EmployeeNo,
                    Name = $"{machineOperator.FirstName} {machineOperator.LastName}"
                };
            }
            _parsedOperators.Add(result);

            return result;
        }

        private ParsedResult<StoneNumberDTO> TryParseStoneNumber(string inputValue,
            SarinActivityType sarinActivity)
        {
            var result = new ParsedResult<StoneNumberDTO>
            {
                FileValue = inputValue
            };

            if (string.IsNullOrWhiteSpace(inputValue))
            {
                result.Errors.Add("Stone Number is empty.");
                return result;
            }

            var stoneNumber = inputValue.SplitStoneNumberForM2(out bool isM2Stone);
            int stoneNumberNumeric = 0;
            if (sarinActivity == SarinActivityType.RoughPlanning)
            {
                if (Regex.IsMatch(stoneNumber, NumericRegEx))
                {
                    stoneNumberNumeric = Convert.ToInt32(stoneNumber);
                }
                else
                {
                    result.Errors.Add("Stone number is invalid");
                }
            }

            if (sarinActivity == SarinActivityType.MakeablePlanning)
            {
                if (stoneNumber.Contains(MinusSign))
                {
                    result.Errors.Add("Stone number is invalid");
                }
                else
                {
                    stoneNumberNumeric = Convert.ToInt32(stoneNumber.SplitStoneNumber());
                }
            }

            result.ParsedValue = new StoneNumberDTO
            {
                IsM2 = isM2Stone,
                StoneNumber = stoneNumber,
                NumericalStoneNumber = stoneNumberNumeric
            };

            return result;
        }

        private ParsedResult<MachineNumberDTO> TryParseMachineNumber(string inputValue)
        {
            if (_parsedMachineNumbers == null)
            {
                _parsedMachineNumbers = new List<ParsedResult<MachineNumberDTO>>();
            }

            var result = _parsedMachineNumbers
                .FirstOrDefault(x => string.Compare(x.FileValue, inputValue, true) == 0);

            if (result != null)
            {
                return result;
            }

            result = new ParsedResult<MachineNumberDTO>
            {
                FileValue = inputValue
            };

            if (string.IsNullOrWhiteSpace(inputValue))
            {
                result.Errors.Add("Machine number is empty");
                _parsedMachineNumbers.Add(result);

                return result;
            }

            var parsedMachineNumber = int.TryParse(inputValue, out int machineNumber);
            if (parsedMachineNumber)
            {
                var machine = _machines.FirstOrDefault(r => r.Number == machineNumber);
                if (machine is null)
                {
                    result.Errors.Add($"There is no any machine entry in system for which machine number is: '{machineNumber}'");
                }
                else if (machine.IsActive)
                {
                    result.ParsedValue = new MachineNumberDTO { Id = machine.Id, MachineNumber = machine.Number };
                }
                else
                {
                    result.Errors.Add($"Machine with number '{machineNumber}' is de-activated into the system.");
                }
            }
            else
            {
                result.Errors.Add($"Machine Number: {inputValue} is invalid.");
            }
            _parsedMachineNumbers.Add(result);

            return result;
        }

        private ParsedResult<MeasureTypeDTO> TryParseMeasureType(string inputValue,
            SarinActivityType sarinActivity, RoughCategory lotRoughCategory,
            IList<string> subRoughRoughCategoryNames)
        {
            if (_parsedMeasureTypes == null)
            {
                _parsedMeasureTypes = new List<ParsedResult<MeasureTypeDTO>>();
            }

            var result = _parsedMeasureTypes
                .FirstOrDefault(x => string.Compare(x.FileValue, inputValue, true) == 0);

            if (result != null)
            {
                return result;
            }

            result = new ParsedResult<MeasureTypeDTO>
            {
                FileValue = inputValue
            };

            if (string.IsNullOrWhiteSpace(inputValue))
            {
                result.Errors.Add("Measure Type is empty.");
                _parsedMeasureTypes.Add(result);

                return result;
            }

            var measureType = _measureTypes
                .FirstOrDefault(r => string.Compare(r.Code.Trim(), inputValue, true) == 0);

            if (measureType is null)
            {
                result.Errors.Add($"There is no any measure type with code {inputValue} in system.");
            }
            else if (!measureType.IsActive)
            {
                result.Errors.Add($"Measure Type with code {inputValue} is de-activated in system.");
            }
            else
            {
                if (string.Compare(measureType.Code, MeasureTypeCode, true) == 0)
                {
                    if (sarinActivity == SarinActivityType.MakeablePlanning)
                    {
                        result.Errors.Add("Invalid Measure Type.");
                    }
                    else
                    {
                        if ((string.IsNullOrWhiteSpace(lotRoughCategory.Name)
                                && subRoughRoughCategoryNames.Contains(RoughCategoryName))
                            || (!string.IsNullOrWhiteSpace(lotRoughCategory.Name)
                                && string.Compare(lotRoughCategory.Name, RoughCategoryName, true) == 0))
                        {
                            result.ParsedValue = new MeasureTypeDTO
                            {
                                Id = measureType.Id,
                                Code = measureType.Code,
                                Name = measureType.Name
                            };
                        }
                        else
                        {
                            result.Errors.Add("Invalid Measure Type for Rough Category.");
                        }
                    }
                }
                else
                {
                    result.ParsedValue = new MeasureTypeDTO
                    {
                        Id = measureType.Id,
                        Code = measureType.Code,
                        Name = measureType.Name
                    };
                }
            }
            _parsedMeasureTypes.Add(result);

            return result;
        }

        private ParsedResult<PlanningLevelDTO> TryParsePlanningLevel(string inputValue)
        {
            if (_parsedPlanningLevels == null)
            {
                _parsedPlanningLevels = new List<ParsedResult<PlanningLevelDTO>>();
            }

            var result = _parsedPlanningLevels
                .FirstOrDefault(x => string.Compare(x.FileValue, inputValue, true) == 0);

            if (result != null)
            {
                return result;
            }

            result = new ParsedResult<PlanningLevelDTO>
            {
                FileValue = inputValue
            };

            if (string.IsNullOrWhiteSpace(inputValue))
            {
                result.Errors.Add("Planning Level is empty");
                _parsedPlanningLevels.Add(result);

                return result;
            }

            var planningLevel = _planningLevels
                .FirstOrDefault(r => string.Compare(r.Name.Trim(), inputValue, true) == 0);

            if (planningLevel is null)
            {
                result.Errors.Add($"No Planning Level with name {inputValue} in system.");
            }
            else if (planningLevel.IsActive)
            {
                result.ParsedValue = new PlanningLevelDTO
                {
                    Id = planningLevel.Id,
                    Name = planningLevel.Name
                };
            }
            else
            {
                result.Errors.Add($"Planning Level '{planningLevel.Name}' is de-activated.");
            }
            _parsedPlanningLevels.Add(result);

            return result;
        }

        private IList<ParsedResult<decimal>> TryParseResultPartWeights(string[] attributeValues,
            IList<ParsedResult<decimal>> partWeights,
            int noOfStonePartsWithValues)
        {
            var partWeightsValues = partWeights.Select(s => s.FileValue).ToArray();

            var result = new List<ParsedResult<decimal>>();
            var valuesToParse = attributeValues.SubArray(0, noOfStonePartsWithValues);
            foreach (var entry in valuesToParse)
            {
                var parsedResult = DecimalUtility.Parse(entry, "Result Part Weight").ToParsedResult(entry);

                if (parsedResult.IsValid && !partWeightsValues.Contains(entry))
                {
                    parsedResult.Errors.Add($"Result part weight value {entry} does not match with the stone part weight.");
                }

                result.Add(parsedResult);
            }
            return result;
        }

        private Result<List<ParsedResult<decimal>>> TryParsePolishWeights(string[] attributeValues,
            IList<ParsedResult<decimal>> resultPartWeights,
            int noOfStonePartsWithValues)
        {
            var noOfPolWeightPartsWithValues = attributeValues.MaxIndexOfNonEmptyValue() + 1;
            if (noOfPolWeightPartsWithValues == 0)
            {
                return Result<List<ParsedResult<decimal>>>.Failure("No Polish Weight values for any parts in the file.");
            }

            if (noOfPolWeightPartsWithValues > noOfStonePartsWithValues)
            {
                return Result<List<ParsedResult<decimal>>>
                    .Failure($"{noOfPolWeightPartsWithValues - noOfStonePartsWithValues} - part(s) have value of Polish Weight, but do not have values in Result Part Weight.");
            }

            var valuesToParse = attributeValues.SubArray(0, noOfStonePartsWithValues);

            var result = new List<ParsedResult<decimal>>();
            for (int polWtIndex = 0; polWtIndex < valuesToParse.Length; polWtIndex++)
            {
                var parsedResult = DecimalUtility
                    .Parse(valuesToParse[polWtIndex], "Polish Weight")
                    .ToParsedResult(valuesToParse[polWtIndex]);

                if (parsedResult.IsValid && parsedResult.ParsedValue > 0)
                {
                    var resultPartWeight = resultPartWeights[polWtIndex];
                    if (resultPartWeight.IsValid && parsedResult.ParsedValue > resultPartWeight.ParsedValue)
                    {
                        parsedResult.Errors.Add($"Polished weight ({parsedResult.ParsedValue}) is greater than Result Part Weight ({resultPartWeight.ParsedValue}).");
                    }
                }
                result.Add(parsedResult);
            }

            return Result<List<ParsedResult<decimal>>>.Success(result);
        }

        private Result<List<ParsedResult<ColorDTO>>> TryParseColors(string[] attributeValues,
            int subRoughId, SarinActivityType sarinActivity,
            ColorRateVersion lotColorRateVersion,
            int noOfStonePartsWithValues)
        {
            var noOfColorPartsWithValues = attributeValues.MaxIndexOfNonEmptyValue() + 1;
            if (noOfColorPartsWithValues == 0)
            {
                return Result<List<ParsedResult<ColorDTO>>>.Failure("No Color Rate Version values for any parts in the file.");
            }

            if (noOfColorPartsWithValues > noOfStonePartsWithValues)
            {
                return Result<List<ParsedResult<ColorDTO>>>
                    .Failure($"{noOfColorPartsWithValues - noOfStonePartsWithValues} - part(s) have value for Color, but do not have values in Result Part Weight.");
            }

            var valuesToParse = attributeValues.SubArray(0, noOfStonePartsWithValues);

            // NOTE: As per the current requirements,
            // Color Rate Version value of each part for the stone is same,
            // Also, the Color Rate Version value of each stone in lot file is same,            
            // That means, Color Rate Version of Lot is considered for all the stones and their parts (polished stones and tops)
            // But if the requirement is changed in future, then code of this methods needs to be changed accordingly
            if (_parsedColors == null)
            {
                _parsedColors = new List<ParsedResult<ColorDTO>>();
            }

            var distinctColorRateValues = valuesToParse.Distinct().ToArray();

            var parsedColorValues = new Dictionary<string, ParsedResult<ColorDTO>>();

            foreach (var fv in distinctColorRateValues)
            {
                var parsedColorResult = _parsedColors
                    .FirstOrDefault(x => string.Compare(x.FileValue, fv, true) == 0);

                if (parsedColorResult != null)
                {
                    parsedColorValues.Add(fv, parsedColorResult);
                    continue;
                }

                parsedColorResult = new ParsedResult<ColorDTO>
                {
                    FileValue = fv
                };

                if (string.IsNullOrWhiteSpace(fv))
                {
                    parsedColorResult.Errors.Add("No Color Version value for the part.");

                    _parsedColors.Add(parsedColorResult);

                    parsedColorValues.Add(fv, parsedColorResult);
                    continue;
                }

                if (lotColorRateVersion == null)
                {
                    parsedColorResult.Errors.Add("Color Rate Version details of lot is not available.");

                    _parsedColors.Add(parsedColorResult);

                    parsedColorValues.Add(fv, parsedColorResult);
                    continue;
                }

                if (string.Compare(fv, lotColorRateVersion.Name, true) != 0)
                {
                    parsedColorResult.Errors.Add($"Color Version of part ({fv}) does not match with the Lot Color Version ({lotColorRateVersion.Name})");

                    _parsedColors.Add(parsedColorResult);

                    parsedColorValues.Add(fv, parsedColorResult);
                    continue;
                }

                var colorRateVersion = _colorRateVersions
                    .FirstOrDefault(r => r.Id == lotColorRateVersion.Id);

                if (colorRateVersion == null)
                {
                    parsedColorResult.Errors.Add($"Color Version ({fv}) does not exist into the system.");
                }
                else if (!colorRateVersion.IsActive)
                {
                    parsedColorResult.Errors.Add($"Color Version ({fv}) is de-activated into the system.");
                }
                else
                {
                    parsedColorResult.ParsedValue = new ColorDTO
                    {
                        Id = colorRateVersion.Id,
                        ColorId = colorRateVersion.ColorId,
                        Name = colorRateVersion.Name
                    };
                }

                _parsedColors.Add(parsedColorResult);
                parsedColorValues.Add(fv, parsedColorResult);
            }

            return Result<List<ParsedResult<ColorDTO>>>
                .Success(valuesToParse.Select(fv => parsedColorValues[fv]).ToList());
        }

        private Result<List<ParsedResult<ClarityDTO>>> TryParseClarities(string[] attributeValues,
            int noOfStonePartsWithValues)
        {
            var noOfClarityPartsWithValues = attributeValues.MaxIndexOfNonEmptyValue() + 1;
            if (noOfClarityPartsWithValues == 0)
            {
                return Result<List<ParsedResult<ClarityDTO>>>.Failure("No Clarity values for any parts in the file.");
            }

            if (noOfClarityPartsWithValues > noOfStonePartsWithValues)
            {
                return Result<List<ParsedResult<ClarityDTO>>>
                    .Failure($"{noOfClarityPartsWithValues - noOfStonePartsWithValues} - part(s) have value for Clarity, but do not have values in Result Part Weight.");
            }

            var valuesToParse = attributeValues.SubArray(0, noOfStonePartsWithValues);

            if (_parsedClarities == null)
            {
                _parsedClarities = new List<ParsedResult<ClarityDTO>>();
            }

            var distinctClarityValues = valuesToParse.Distinct().ToArray();
            var parsedClarityValues = new Dictionary<string, ParsedResult<ClarityDTO>>();

            foreach (var fv in distinctClarityValues)
            {
                var parsedClarityResult = _parsedClarities
                    .FirstOrDefault(x => string.Compare(x.FileValue, fv, true) == 0);

                if (parsedClarityResult != null)
                {
                    parsedClarityValues.Add(fv, parsedClarityResult);
                    continue;
                }

                parsedClarityResult = new ParsedResult<ClarityDTO>
                {
                    FileValue = fv
                };

                if (string.IsNullOrWhiteSpace(fv))
                {
                    parsedClarityResult.Errors.Add("No Clarity value for the part.");

                    _parsedClarities.Add(parsedClarityResult);

                    parsedClarityValues.Add(fv, parsedClarityResult);
                    continue;
                }

                var clarity = _clarities
                    .FirstOrDefault(c => string.Compare(c.Name.Trim(), fv, true) == 0);

                if (clarity == null)
                {
                    parsedClarityResult.Errors.Add($"Clarity ({fv}) does not exist into the system.");
                }
                else if (!clarity.IsActive)
                {
                    parsedClarityResult.Errors.Add($"Clarity ({fv}) is de-activated into the system.");
                }
                else
                {
                    parsedClarityResult.ParsedValue = new ClarityDTO
                    {
                        Id = clarity.Id,
                        Name = clarity.Name
                    };
                }

                _parsedClarities.Add(parsedClarityResult);
                parsedClarityValues.Add(fv, parsedClarityResult);
            }

            return Result<List<ParsedResult<ClarityDTO>>>
                .Success(valuesToParse.Select(fv => parsedClarityValues[fv]).ToList());
        }

        private Result<List<ParsedResult<decimal>>> TryParseDecimalValues(string[] attributeValues,
            int noOfStonePartsWithValues, string fieldName)
        {
            var noOfPartsWithValues = attributeValues.MaxIndexOfNonEmptyValue() + 1;
            if (noOfPartsWithValues == 0)
            {
                return Result<List<ParsedResult<decimal>>>.Failure($"No {fieldName} values for any parts in the file.");
            }

            if (noOfPartsWithValues > noOfStonePartsWithValues)
            {
                return Result<List<ParsedResult<decimal>>>
                    .Failure($"{noOfPartsWithValues - noOfStonePartsWithValues} - part(s) have value of ${fieldName}, but do not have values in Result Part Weight.");
            }

            var valuesToParse = attributeValues.SubArray(0, noOfStonePartsWithValues);

            var result = new List<ParsedResult<decimal>>();
            for (int index = 0; index < valuesToParse.Length; index++)
            {
                var parsedResult = DecimalUtility
                    .Parse(valuesToParse[index], fieldName)
                    .ToParsedResult(valuesToParse[index]);

                result.Add(parsedResult);
            }

            return Result<List<ParsedResult<decimal>>>.Success(result);
        }

        private Result<List<ParsedResult<ShapeDTO>>> TryParseShapes(string[] attributeValues,
            IList<ParsedResult<decimal>> parsedDiameters,
            IList<ParsedResult<decimal>> parsedLengths,
            int noOfStonePartsWithValues)
        {
            var noOfShapePartsWithValues = attributeValues.MaxIndexOfNonEmptyValue() + 1;
            if (noOfShapePartsWithValues == 0)
            {
                return Result<List<ParsedResult<ShapeDTO>>>.Failure("No Shape values for any parts in the file.");
            }

            if (noOfShapePartsWithValues > noOfStonePartsWithValues)
            {
                return Result<List<ParsedResult<ShapeDTO>>>
                    .Failure($"{noOfShapePartsWithValues - noOfStonePartsWithValues} - part(s) have value for Shape, but do not have values in Result Part Weight.");
            }

            var valuesToParse = attributeValues.SubArray(0, noOfStonePartsWithValues);

            if (_parsedShapes == null)
            {
                _parsedShapes = new List<ParsedResult<ShapeDTO>>();
            }

            var distinctShapeValues = valuesToParse.Distinct().ToArray();
            var parsedShapeValues = new Dictionary<string, ParsedResult<ShapeDTO>>();

            foreach (var fv in distinctShapeValues)
            {
                var parsedShapeResult = _parsedShapes
                    .FirstOrDefault(x => string.Compare(x.FileValue, fv, true) == 0);

                if (parsedShapeResult != null)
                {
                    parsedShapeValues.Add(fv, parsedShapeResult);
                    continue;
                }

                parsedShapeResult = new ParsedResult<ShapeDTO>
                {
                    FileValue = fv
                };

                if (string.IsNullOrWhiteSpace(fv))
                {
                    parsedShapeResult.Errors.Add("No Shape value for the part.");

                    _parsedShapes.Add(parsedShapeResult);

                    parsedShapeValues.Add(fv, parsedShapeResult);
                    continue;
                }

                var shape = _shapes
                    .FirstOrDefault(s => string.Compare(s.Name.Trim(), fv, true) == 0);

                if (shape == null)
                {
                    parsedShapeResult.Errors.Add($"Shape ({fv}) does not exist into the system.");
                }
                else if (!shape.IsActive)
                {
                    parsedShapeResult.Errors.Add($"Shape ({fv}) is de-activated into the system.");
                }
                else
                {
                    parsedShapeResult.ParsedValue = new ShapeDTO
                    {
                        Id = shape.Id,
                        Name = shape.Name,
                        MeasurementBy = (MeasurementParameters)Enum.Parse(typeof(MeasurementParameters), shape.MeasurementBy)
                    };
                }
                _parsedShapes.Add(parsedShapeResult);
                parsedShapeValues.Add(fv, parsedShapeResult);
            }

            var result = new List<ParsedResult<ShapeDTO>>();
            for (int index = 0; index < valuesToParse.Length; index++)
            {
                var parsedShape = parsedShapeValues[valuesToParse[index]];
                var parsedShapeResult = new ParsedResult<ShapeDTO>
                {
                    FileValue = parsedShape.FileValue,
                    Errors = new List<string>(parsedShape.Errors)
                };

                if (parsedShape.IsValid && parsedShape.ParsedValue != null)
                {
                    var parsedDiameter = parsedDiameters[index];
                    var parsedLength = parsedLengths[index];

                    parsedShapeResult.ParsedValue = new ShapeDTO
                    {
                        Id = parsedShape.ParsedValue.Id,
                        Name = parsedShape.ParsedValue.Name,
                        MeasurementBy = parsedShape.ParsedValue.MeasurementBy,
                        Diameter = parsedDiameter.IsValid ? parsedDiameter.ParsedValue : 0.0M,
                        Length = parsedLength.IsValid ? parsedLength.ParsedValue : 0.0M
                    };
                }
                result.Add(parsedShapeResult);
            }

            return Result<List<ParsedResult<ShapeDTO>>>.Success(result);
        }

        private Result<List<ParsedResult<RateDTO>>> TryParseRates(string[] attributeValues,
            SubRough subRough, SarinActivityType sarinActivity, List<DiameterSieveSize> diameterSieveSizes,
            IList<ParsedResult<ColorDTO>> colors, IList<ParsedResult<ClarityDTO>> clarities,
            IList<ParsedResult<ShapeDTO>> shapes, IList<ParsedResult<decimal>> polishWeights,
            int noOfStonePartsWithValues)
        {
            var noOfRatePartsWithValues = attributeValues.MaxIndexOfNonEmptyValue() + 1;
            if (noOfRatePartsWithValues == 0)
            {
                return Result<List<ParsedResult<RateDTO>>>.Failure("No Rate values for any parts in the file.");
            }

            if (noOfRatePartsWithValues > noOfStonePartsWithValues)
            {
                return Result<List<ParsedResult<RateDTO>>>
                    .Failure($"{noOfRatePartsWithValues - noOfStonePartsWithValues} - part(s) have value for Rate, but do not have values in Result Part Weight.");
            }

            var valuesToParse = attributeValues.SubArray(0, noOfStonePartsWithValues);

            var result = new List<ParsedResult<RateDTO>>();
            for (int index = 0; index < valuesToParse.Length; index++)
            {
                var parsedValue = DecimalUtility
                    .Parse(valuesToParse[index], "Rate")
                    .ToParsedResult(valuesToParse[index]);

                var parsedRateResult = new ParsedResult<RateDTO>
                {
                    FileValue = parsedValue.FileValue
                };

                if (parsedValue.IsValid)
                {
                    var parsedShape = shapes[index];
                    var measurementValue = parsedShape.IsValid && parsedShape.ParsedValue != null
                            ? parsedShape.ParsedValue.MeasurementValue
                            : 0;

                    parsedRateResult.ParsedValue = new RateDTO
                    {
                        Rate = parsedValue.ParsedValue,
                        MeasurementValue = measurementValue
                    };

                    if (sarinActivity == SarinActivityType.MakeablePlanning)
                    {
                        var diameterSieveSize = diameterSieveSizes
                            .Where(x => x.DiameterUpTo <= measurementValue)
                            .OrderByDescending(x => x.Diameter)
                            .FirstOrDefault();

                        if (diameterSieveSize != null && diameterSieveSize.IsActive
                            && diameterSieveSize.DiameterUpTo.HasValue
                            && measurementValue < diameterSieveSize.Diameter
                            && measurementValue >= diameterSieveSize.DiameterUpTo.Value)
                        {
                            var colorRateVersionId = colors[index].IsValid && colors[index].ParsedValue != null
                                ? colors[index].ParsedValue.Id
                                : 0;

                            var clarityId = clarities[index].IsValid && clarities[index].ParsedValue != null
                                ? clarities[index].ParsedValue.Id
                                : 0;

                            if (colorRateVersionId > 0 && clarityId > 0)
                            {
                                var rate = _rates
                                    .Where(x => x.ClarityId == clarityId && x.Diameter <= diameterSieveSize.Diameter)
                                    .OrderByDescending(x => x.Diameter)
                                    .FirstOrDefault();

                                if (rate != null)
                                {
                                    var polishedWeight = polishWeights[index].IsValid
                                        ? polishWeights[index].ParsedValue
                                        : 0.0M;

                                    parsedRateResult.ParsedValue.OldRate = parsedRateResult.ParsedValue.Rate;
                                    parsedRateResult.ParsedValue.Rate = rate.UnitPrice * polishedWeight * 100;

                                    parsedRateResult.ParsedValue.OldMeasurementValue = parsedRateResult.ParsedValue.MeasurementValue;
                                    parsedRateResult.ParsedValue.MeasurementValue = rate.Diameter;
                                }
                            }
                        }
                    }
                }
                else
                {
                    parsedRateResult.Errors.AddRange(parsedValue.Errors);
                }
                result.Add(parsedRateResult);
            }
            return Result<List<ParsedResult<RateDTO>>>.Success(result);
        }

        private SieveSizeName GetSieveSizeByDiameter(decimal polDiameter,
            List<DiameterSieveSize> diameterSieveSizes)
        {
            var minSieveSize = diameterSieveSizes
                .Where(x => x.Diameter <= polDiameter)
                .OrderByDescending(x => x.Diameter)
                .FirstOrDefault();

            var maxSieveSize = diameterSieveSizes
                .Where(x => x.Diameter > polDiameter)
                .OrderBy(x => x.Diameter)
                .FirstOrDefault();

            return new SieveSizeName()
            {
                MinSieveSizeId = minSieveSize?.SieveSizeId ?? null,
                MinSieveSize = minSieveSize?.SieveSize?.Name ?? null,
                MaxSieveSizeId = maxSieveSize?.SieveSizeId ?? null,
                MaxSieveSize = maxSieveSize?.SieveSize?.Name ?? null
            };
        }

        private Result<List<ParsedResult<SieveSizeDTO>>> TryParseSieveSizes(string[] attributeValues,
            List<DiameterSieveSize> diameterSieveSizes,
            IList<ParsedResult<ShapeDTO>> shapes,
            IList<ParsedResult<decimal>> polishWeights,
            int noOfStonePartsWithValues)
        {
            var noOfSieveSizePartsWithValues = attributeValues.MaxIndexOfNonEmptyValue() + 1;
            if (noOfSieveSizePartsWithValues == 0)
            {
                return Result<List<ParsedResult<SieveSizeDTO>>>.Failure("No Sieve Size values for any parts in the file.");
            }

            if (noOfSieveSizePartsWithValues > noOfStonePartsWithValues)
            {
                return Result<List<ParsedResult<SieveSizeDTO>>>
                    .Failure($"{noOfSieveSizePartsWithValues - noOfStonePartsWithValues} - part(s) have value for Sieve Size, but do not have values in Result Part Weight.");
            }

            var valuesToParse = attributeValues.SubArray(0, noOfStonePartsWithValues);

            var result = new List<ParsedResult<SieveSizeDTO>>();
            for (int index = 0; index < valuesToParse.Length; index++)
            {
                var ssv = valuesToParse[index];
                var parsedSieveSizeResult = new ParsedResult<SieveSizeDTO>
                {
                    FileValue = ssv
                };

                SieveSizeName sieveSizeInfo;
                var polishWeightResult = polishWeights[index];
                if (polishWeightResult.IsValid && polishWeightResult.ParsedValue > 0)
                {
                    var sizeName = ssv;
                    if (string.IsNullOrWhiteSpace(ssv))
                    {
                        var shapeResult = shapes[index];
                        var measurementValue = shapeResult.IsValid && shapeResult.ParsedValue != null
                            ? shapeResult.ParsedValue.MeasurementValue
                            : 0;

                        sieveSizeInfo = GetSieveSizeByDiameter(measurementValue, diameterSieveSizes);
                        sizeName = sieveSizeInfo.GenerateName();
                    }
                    else
                    {
                        sieveSizeInfo = ssv.SplitSieveSize();
                        if (sieveSizeInfo.MinSieveSize != null)
                        {
                            var minSieveSize = _sieveSizes
                                .FirstOrDefault(s => string.Compare(s.Name.Trim(), sieveSizeInfo.MinSieveSize) == 0);

                            if (minSieveSize == null)
                            {
                                parsedSieveSizeResult.Errors.Add($"Sieve Size ({sieveSizeInfo.MinSieveSize}) does not exist into the system.");
                            }
                            else
                            {
                                if (minSieveSize.IsActive)
                                {
                                    sieveSizeInfo.MinSieveSizeId = minSieveSize.Id;
                                }
                                else
                                {
                                    parsedSieveSizeResult.Errors.Add($"Sieve Size ({sieveSizeInfo.MinSieveSize}) is de-activated into the system.");
                                }
                            }
                        }

                        if (sieveSizeInfo.MaxSieveSize != null)
                        {
                            var maxSieveSize = _sieveSizes
                                .FirstOrDefault(s => string.Compare(s.Name.Trim(), sieveSizeInfo.MaxSieveSize) == 0);

                            if (maxSieveSize == null)
                            {
                                parsedSieveSizeResult.Errors.Add($"Sieve Size ({sieveSizeInfo.MaxSieveSize}) does not exist into the system.");
                            }
                            else
                            {
                                if (maxSieveSize.IsActive)
                                {
                                    sieveSizeInfo.MaxSieveSizeId = maxSieveSize.Id;
                                }
                                else
                                {
                                    parsedSieveSizeResult.Errors.Add($"Sieve Size ({sieveSizeInfo.MaxSieveSize}) is de-activated into the system.");
                                }
                            }
                        }
                    }

                    parsedSieveSizeResult.ParsedValue = new SieveSizeDTO
                    {
                        MinSieveSizeId = sieveSizeInfo.MinSieveSizeId,
                        MaxSieveSizeId = sieveSizeInfo.MaxSieveSizeId,
                        Name = sizeName
                    };
                }
                else
                {
                    parsedSieveSizeResult.Errors.Add("Unable to derive Sieve Size because part does not have polish weight value.");
                }

                result.Add(parsedSieveSizeResult);
            }
            return Result<List<ParsedResult<SieveSizeDTO>>>.Success(result);
        }

        private StoneDTO ValidateTops(int stoneNumber, SarinActivityType sarinActivity,
            StoneDTO parsedStone, TopsDiameterRange topsDiameterRange,
            List<LotStoneTopsParameter> lotStonesTopsParameters)
        {
            bool hasPolishTops = false;
            foreach (var ps in parsedStone.PolishStones)
            {
                var measurementValue = ps.MeasurementValue.IsValid
                    ? ps.MeasurementValue.ParsedValue
                    : 0;

                var clarityId = ps.Clarity.IsValid && ps.Clarity.ParsedValue != null
                    ? ps.Clarity.ParsedValue.Id
                    : 0;

                var isPolishTops = PolishedStoneExtensions
                    .IsPolishedTop(measurementValue, clarityId, stoneNumber,
                        sarinActivity.ToString(), topsDiameterRange, lotStonesTopsParameters);

                if (isPolishTops)
                {
                    if (!hasPolishTops)
                    {
                        hasPolishTops = true;
                    }

                    if (sarinActivity == SarinActivityType.MakeablePlanning)
                    {
                        ps.Errors.Add("Polished stone contains tops");
                    }
                }
            }

            if (hasPolishTops && sarinActivity == SarinActivityType.MakeablePlanning)
            {
                parsedStone.Errors.Add("Tops are not allowed in Makeable planning lots.");
            }

            return parsedStone;
        }

        private StoneDTO ParseStoneAttributes(string dataRow, SubRough subRough, Lot lot,
            SarinActivityType sarinActivity, IReadOnlyList<LotFileHeaderSchema> lotFileHeaderSchema,
            LotFileHeaderSummary headerSummary, RoughCategory lotRoughCategory,
            IList<string> subRoughRoughCategoryNames, ColorRateVersion lotColorRateVersion,
            List<DiameterSieveSize> diameterSieveSizes, TopsDiameterRange topsDiameterRange,
            List<LotStoneTopsParameter> lotStonesTopsParameters)
        {
            var stoneErrors = new List<string>();

            var dataRowValues = dataRow.Split(FileDataSeparator);
            var stoneAttributesValues = dataRowValues
                .Take(headerSummary.FirstPartAttributeIndex)
                .ToArray();

            var stonePartsCountResult = LotFileHeaderUtility
                .CalculatePartsCount(headerSummary, dataRowValues);
            if (stonePartsCountResult.IsFailure)
            {
                stoneErrors.Add(stonePartsCountResult.Error);
            }

            var parsedStone = new StoneDTO
            {
                HasMisMatchInPartsCount = stonePartsCountResult.IsFailure,
                PolishStones = new List<PolishStoneDTO>()
            };

            var dateAttrIndex = LotFileHeaderUtility
                .GetStoneAttributeIndex(lotFileHeaderSchema, "Date");
            parsedStone.MeasureDate = TryParseMeasureDate(stoneAttributesValues[dateAttrIndex]?.Trim() ?? string.Empty);

            var timeAttrIndex = LotFileHeaderUtility
                .GetStoneAttributeIndex(lotFileHeaderSchema, "Time");
            parsedStone.MeasureTime = TryParseMeasureTime(stoneAttributesValues[timeAttrIndex]?.Trim() ?? string.Empty);

            var operatorAttrIndex = LotFileHeaderUtility
                .GetStoneAttributeIndex(lotFileHeaderSchema, "UserName");
            parsedStone.Operator = TryParseOperator(stoneAttributesValues[operatorAttrIndex]?.Trim() ?? string.Empty);

            var stoneNumberAttrIndex = LotFileHeaderUtility
                .GetStoneAttributeIndex(lotFileHeaderSchema, "StoneNumber");
            parsedStone.StoneNumber = TryParseStoneNumber(stoneAttributesValues[stoneNumberAttrIndex]?.Trim() ?? string.Empty, sarinActivity);

            var machineNumberAttrIndex = LotFileHeaderUtility
                .GetStoneAttributeIndex(lotFileHeaderSchema, "MachineSerialNumber");
            parsedStone.MachineNumber = TryParseMachineNumber(stoneAttributesValues[machineNumberAttrIndex]?.Trim() ?? string.Empty);

            var measureTypeAttrIndex = LotFileHeaderUtility
                .GetStoneAttributeIndex(lotFileHeaderSchema, "MeasureTypeShort");
            parsedStone.MeasureType = TryParseMeasureType(stoneAttributesValues[measureTypeAttrIndex]?.Trim() ?? string.Empty,
                sarinActivity, lot.RoughCategory, subRoughRoughCategoryNames);

            var planningLevelAttrIndex = LotFileHeaderUtility
                .GetStoneAttributeIndex(lotFileHeaderSchema, "PlanningLevel");
            parsedStone.PlanningLevel = TryParsePlanningLevel(stoneAttributesValues[planningLevelAttrIndex]?.Trim() ?? string.Empty);

            var roughWeightAttrIndex = LotFileHeaderUtility
                .GetStoneAttributeIndex(lotFileHeaderSchema, "RoughWeight");
            var roughWeightFileValue = stoneAttributesValues[roughWeightAttrIndex]?.Trim() ?? string.Empty;
            parsedStone.RoughWeight = DecimalUtility
                .Parse(roughWeightFileValue, "Rough Weight")
                .ToParsedResult(roughWeightFileValue);

            var roughStoneNumber = parsedStone.StoneNumber.IsValid && parsedStone.StoneNumber.ParsedValue != null
                ? parsedStone.StoneNumber.ParsedValue.NumericalStoneNumber
                : 0;

            // NOTE: Currently, the color rate version is lot based, not stone part based
            // So, using lot level color rate version, otherwise have to use stone part wise color rate version
            // And for that this implementation would be moved at part level parsing
            if (lotColorRateVersion == null)
            {
                stoneErrors.Add(sarinActivity == SarinActivityType.RoughPlanning
                    ? "Unable to find the Lot Color Version details."
                    : $"Stone with number '{roughStoneNumber}' does not match with rough planning stone.");
            }

            if (!parsedStone.HasMisMatchInPartsCount)
            {
                // Part Weight
                // NOTE: PartWeight in file is not significant
                // PartWeight is only to export stone parts detail in sequence while exporing from Sarin
                // Sometimes, first part value in PartWeight section is last value (or any place but not at first part place)
                // in ResultPartWeight section
                var firstPartWeightValueIndex = LotFileHeaderUtility
                    .GetIndex(lotFileHeaderSchema, "PartWeight", stonePartsCountResult.Value);

                var partWeightFileValues = dataRowValues
                    .SubArray(firstPartWeightValueIndex, stonePartsCountResult.Value);
                
                var noOfPartsWeightsWithValues = partWeightFileValues.MaxIndexOfNonEmptyValue() + 1;

                var parsedPartWeights = partWeightFileValues
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Select(s => DecimalUtility.Parse(s, "Part Weight").ToParsedResult(s))
                    .ToList();

                // Result Part Weight
                // NOTE: ResultPartWeight is rough weight of each part
                // Each part details are in sequence as per the ResultPartWeight part sequence
                // For ex. For, all the multipart columns in files
                //  First value of each section is for first value of ResultPartWeight section
                var firstResultPartWeightValueIndex = LotFileHeaderUtility
                    .GetIndex(lotFileHeaderSchema, "ResultPartWeight", stonePartsCountResult.Value);

                var resultPartWeightFileValues = dataRowValues
                    .SubArray(firstResultPartWeightValueIndex, stonePartsCountResult.Value);

                var noOfPartsWithValues = resultPartWeightFileValues.MaxIndexOfNonEmptyValue() + 1;
                if (noOfPartsWithValues > 0)
                {
                    var parsedResultPartWeights = TryParseResultPartWeights(resultPartWeightFileValues,
                        parsedPartWeights, noOfPartsWithValues);

                    // Polish Weight
                    var firstPolishWeightValueIndex = LotFileHeaderUtility
                        .GetIndex(lotFileHeaderSchema, "Pol", stonePartsCountResult.Value);

                    var polishWeightFileValues = dataRowValues
                        .SubArray(firstPolishWeightValueIndex, stonePartsCountResult.Value);

                    var parsedPolishWeights = new List<ParsedResult<decimal>>();
                    TryParsePolishWeights(polishWeightFileValues,
                        parsedResultPartWeights, noOfPartsWithValues)
                        .OnSuccess(val => parsedPolishWeights = val)
                        .OnFailure(err => stoneErrors.Add(err));

                    // Colors
                    var firstColorValueIndex = LotFileHeaderUtility
                        .GetIndex(lotFileHeaderSchema, "Color", stonePartsCountResult.Value);

                    var colorFileValues = dataRowValues
                        .SubArray(firstColorValueIndex, stonePartsCountResult.Value);

                    IList<ParsedResult<ColorDTO>> parsedColors = new List<ParsedResult<ColorDTO>>();
                    TryParseColors(colorFileValues, lot.SubRoughId, sarinActivity,
                            lotColorRateVersion, noOfPartsWithValues)
                        .OnSuccess(val => parsedColors = val)
                        .OnFailure(err => stoneErrors.Add(err));

                    // Clarities
                    var firstClarityValueIndex = LotFileHeaderUtility
                        .GetIndex(lotFileHeaderSchema, "Clarity", stonePartsCountResult.Value);

                    var clarityFileValues = dataRowValues
                        .SubArray(firstClarityValueIndex, stonePartsCountResult.Value);

                    IList<ParsedResult<ClarityDTO>> parsedClarities = new List<ParsedResult<ClarityDTO>>();
                    TryParseClarities(clarityFileValues, noOfPartsWithValues)
                        .OnSuccess(val => parsedClarities = val)
                        .OnFailure(err => stoneErrors.Add(err));

                    // Diameters
                    var firstDiameterValueIndex = LotFileHeaderUtility
                        .GetIndex(lotFileHeaderSchema, "Diameter", stonePartsCountResult.Value);

                    var diameterFileValues = dataRowValues
                        .SubArray(firstDiameterValueIndex, stonePartsCountResult.Value);

                    var parsedDiameters = new List<ParsedResult<decimal>>();
                    TryParseDecimalValues(diameterFileValues, noOfPartsWithValues, "Diameter")
                        .OnSuccess(val => parsedDiameters = val)
                        .OnFailure(err => stoneErrors.Add(err));

                    // Lengths
                    var firstLengthValueIndex = LotFileHeaderUtility
                        .GetIndex(lotFileHeaderSchema, "Length", stonePartsCountResult.Value);

                    var lengthFileValues = dataRowValues
                        .SubArray(firstLengthValueIndex, stonePartsCountResult.Value);

                    var parsedLengths = new List<ParsedResult<decimal>>();
                    TryParseDecimalValues(lengthFileValues, noOfPartsWithValues, "Length")
                        .OnSuccess(val => parsedLengths = val)
                        .OnFailure(err => stoneErrors.Add(err));

                    // Shapes
                    var firstShapeValueIndex = LotFileHeaderUtility
                        .GetIndex(lotFileHeaderSchema, "ShapeName", stonePartsCountResult.Value);

                    var shapeFileValues = dataRowValues
                        .SubArray(firstShapeValueIndex, stonePartsCountResult.Value);

                    IList<ParsedResult<ShapeDTO>> parsedShapes = new List<ParsedResult<ShapeDTO>>();
                    TryParseShapes(shapeFileValues, parsedDiameters, parsedLengths, noOfPartsWithValues)
                        .OnSuccess(val => parsedShapes = val)
                        .OnFailure(err => stoneErrors.Add(err));

                    // Rates / Values
                    var firstRateValueIndex = LotFileHeaderUtility
                        .GetIndex(lotFileHeaderSchema, "Value", stonePartsCountResult.Value);

                    var rateFileValues = dataRowValues
                        .SubArray(firstRateValueIndex, stonePartsCountResult.Value);

                    IList<ParsedResult<RateDTO>> parsedRates = new List<ParsedResult<RateDTO>>();
                    TryParseRates(rateFileValues, subRough, sarinActivity,
                            diameterSieveSizes, parsedColors, parsedClarities,
                            parsedShapes, parsedPolishWeights, noOfPartsWithValues)
                        .OnSuccess(val => parsedRates = val)
                        .OnFailure(err => stoneErrors.Add(err));

                    // SieveSizes
                    var firstSieveSizeValueIndex = LotFileHeaderUtility
                        .GetIndex(lotFileHeaderSchema, "SieveSize", stonePartsCountResult.Value);

                    var sieveSizeFileValues = dataRowValues
                        .SubArray(firstSieveSizeValueIndex, stonePartsCountResult.Value);

                    IList<ParsedResult<SieveSizeDTO>> parsedSieveSizes = new List<ParsedResult<SieveSizeDTO>>();
                    TryParseSieveSizes(sieveSizeFileValues, diameterSieveSizes, parsedShapes,
                            parsedPolishWeights, noOfPartsWithValues)
                        .OnSuccess(val => parsedSieveSizes = val)
                        .OnFailure(err => stoneErrors.Add(err));

                    for (int partIndex = 0; partIndex < noOfPartsWithValues; partIndex++)
                    {
                        var parsedPolishedStone = new PolishStoneDTO()
                        {
                            PartWeight = partIndex < parsedPartWeights.Count ? parsedPartWeights[partIndex] : null,
                            ResultPartWeight = partIndex < parsedResultPartWeights.Count ? parsedResultPartWeights[partIndex] : null,
                            PolishWeight = partIndex < parsedPolishWeights.Count ? parsedPolishWeights[partIndex] : null,
                            Color = partIndex < parsedColors.Count ? parsedColors[partIndex] : null,
                            Clarity = partIndex < parsedClarities.Count ? parsedClarities[partIndex] : null,
                            Shape = partIndex < parsedShapes.Count ? parsedShapes[partIndex] : null,
                            Rate = partIndex < parsedRates.Count ? parsedRates[partIndex] : null,
                            SieveSize = partIndex < parsedSieveSizes.Count ? parsedSieveSizes[partIndex] : null
                        };
                        parsedPolishedStone.MeasurementValue = parsedPolishedStone.Shape != null
                                    && parsedPolishedStone.Shape.IsValid
                                    && parsedPolishedStone.Shape.ParsedValue.MeasurementBy == MeasurementParameters.Length
                                ? (partIndex < parsedLengths.Count ? parsedLengths[partIndex] : null)
                                : (partIndex < parsedDiameters.Count ? parsedDiameters[partIndex] : null);

                        parsedPolishedStone.Errors = parsedPolishedStone.CollectErrors().Distinct().ToList();

                        parsedStone.PolishStones.Add(parsedPolishedStone);
                    }
                }
                else
                {
                    stoneErrors.Add("None of the Result Part Weight has value.");
                }

                if(noOfPartsWeightsWithValues != noOfPartsWithValues)
                {
                    stoneErrors.Add("Part Weights and Result Part Weights has different number of parts in file.");
                }
            }

            parsedStone = ValidateTops(roughStoneNumber, sarinActivity,
                parsedStone, topsDiameterRange, lotStonesTopsParameters);

            stoneErrors.AddRange(parsedStone.CollectErrors());
            parsedStone.Errors.AddRange(stoneErrors.Distinct());

            return parsedStone;
        }

        private void LoadLookupData(SubRough subRough)
        {
            _operators = _employeeService.Get(x => x.IsActive).ToList();
            _machines = _machineService.GetAll().ToList();
            _measureTypes = _measureTypeService.GetAll().ToList();
            _planningLevels = _planningLevelService.GetAll().ToList();

            _shapes = _shapeService.GetAll().ToList();
            _clarities = _clarityService.GetClaritiesAsOn(subRough.AssignedOn).ToList();
            _colorRateVersions = _colorRateVersionService.GetAll().ToList();

            _sieveSizes = _sieveSizeService.GetAll().ToList();
        }
    }
}
