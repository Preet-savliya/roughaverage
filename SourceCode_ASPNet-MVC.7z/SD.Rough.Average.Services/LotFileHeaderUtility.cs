﻿using System;
using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Core;

namespace SD.Rough.Average.Services
{
    public enum AttributeOf
    {
        Stone,
        Part
    }

    public class LotFileHeaderSchema
    {
        public string Name { get; set; }
        public AttributeOf AttributeOf { get; set; }
        public bool DerivedFromParts { get; set; } = false;
    }

    public class LotFileHeaderSummary
    {
        public int TotalAttributes { get; set; }
        public int StoneAttributes { get; set; }
        public int PartAttributes { get; set; }
        public int FirstPartAttributeIndex { get; set; }

        public static LotFileHeaderSummary Calculate(IReadOnlyList<LotFileHeaderSchema> lotFileHeaderSchema)
        {
            var totalDistinctColumnsOfFile = lotFileHeaderSchema.Count;

            var singleValueColumns = lotFileHeaderSchema
                .Where(x => x.AttributeOf == AttributeOf.Stone)
                .Count();

            var multiPartColumns = lotFileHeaderSchema
                .Where(x => x.AttributeOf == AttributeOf.Part)
                .Count();

            var firstPartAttributeIndex = lotFileHeaderSchema
                .TakeWhile(x => x.AttributeOf != AttributeOf.Part)
                .Count();

            return new LotFileHeaderSummary
            {
                TotalAttributes = totalDistinctColumnsOfFile,
                StoneAttributes = singleValueColumns,
                PartAttributes = multiPartColumns,
                FirstPartAttributeIndex = firstPartAttributeIndex
            };
        }
    }

    public class LotFileHeaderUtility
    {
        public static Result<int> CalculatePartsCount(
            LotFileHeaderSummary lotFileColumnsCount, string[] stoneAttributes)
        {
            var stoneMultiPartsAttributesCount = stoneAttributes.Length - lotFileColumnsCount.StoneAttributes;

            return stoneMultiPartsAttributesCount % lotFileColumnsCount.PartAttributes > 0
                ? Result<int>.Failure("Invalid number of parts for some of the attributes")
                : Result<int>.Success(stoneMultiPartsAttributesCount / lotFileColumnsCount.PartAttributes);
        }

        public static int GetStoneAttributeIndex(IReadOnlyList<LotFileHeaderSchema> headers, string headerName)
        {
            if (headers == null || headerName.Length == 0 || string.IsNullOrWhiteSpace(headerName))
            {
                return -1;
            }

            var result = headers
                .Select((h, idx) => new { Name = h.Name.Trim(), Index = idx })
                .FirstOrDefault(x => string.Compare(x.Name, headerName.Trim(), true) == 0);

            if (result == null)
            {
                return -1;
            }

            return result.Index;
        }

        public static int GetIndex(IReadOnlyList<LotFileHeaderSchema> headers, string headerName, int partsCount)
        {
            if (headers == null || headerName.Length == 0 || string.IsNullOrWhiteSpace(headerName))
            {
                return -1;
            }

            var leftHeaders = headers
                .TakeWhile(x => !x.Name.Equals(headerName, StringComparison.OrdinalIgnoreCase));

            if (!leftHeaders.Any())
                return -1;

            var noOfSingleValueAttributeHeaders = leftHeaders.Where(x => x.AttributeOf == AttributeOf.Stone).Count();
            var noOfMultiValueAttributeHeaders = leftHeaders.Where(x => x.AttributeOf == AttributeOf.Part).Count();

            return (noOfSingleValueAttributeHeaders + (noOfMultiValueAttributeHeaders * partsCount));
        }
    }
}