﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using System.Collections.Generic;
using System.Linq;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;

namespace SD.Rough.Average.Services
{
    public class AppUserService : Service<AppUser>, IAppUserService
    {
        #region PrivateFields
        private IRepository<AppUser> _repository;
        #endregion

        #region Ctor
        public AppUserService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<AppUser>();
        }
        #endregion

        #region Method
        //public IEnumerable<AppUser> GetUserInfo(string loginId, string password)
        //{
        //    IEnumerable<AppUser> result = _repository.GetAll().Where(u => u.IsActive);
        //    var user = result.Where(e => string.Compare(e.LoginId, loginId, true) == 0 && e.Password == password).ToList();
        //    return user;
        //}

        public AppUser GetUserInfo(string loginId)
        {
            AppUser result = _repository.Get(x => string.Compare(x.LoginId, loginId, true) == 0
                                            && x.IsActive).FirstOrDefault();
            return result;
        }


        public int GetUserRoleId(int userId)
        {
            int xUserRoleId = FirstOrDefault(x => x.Id == userId && x.IsActive).RoleId;

            return (xUserRoleId > 0 && xUserRoleId != 0) ? xUserRoleId : 0;
        }
        #endregion
    }
}
