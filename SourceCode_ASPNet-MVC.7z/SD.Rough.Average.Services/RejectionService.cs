﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SD.Rough.Average.Data.UnitOfWork;
using System.ComponentModel.DataAnnotations;
using SD.Rough.Average.Data.Repositories;

namespace SD.Rough.Average.Services
{
    public class RejectionService : Service<Rejection>, IRejectionService
    {
        #region Fields
        private IRepository<Rejection> _repository;
        #endregion

        #region Ctor
        public RejectionService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<Rejection>();
        }
        #endregion

        #region Methods
        #endregion

    }
}
