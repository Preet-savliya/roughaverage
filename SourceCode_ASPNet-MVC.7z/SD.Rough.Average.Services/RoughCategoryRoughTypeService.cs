﻿namespace SD.Rough.Average.Services
{
    using System.Linq;
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class RoughCategoryRoughTypeService : Service<RoughCategoryRoughType>, IRoughCategoryRoughTypeService
    {
        #region PrivateFields
        private IRepository<RoughCategoryRoughType> _repository;
        #endregion 

        #region Ctor
        public RoughCategoryRoughTypeService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<RoughCategoryRoughType>();
        }
        #endregion

        #region Method
        public string CheckRoughTypeWiseRoughCategoryIsUnique(int roughTypeId, int roughCategoryId, int roughCategoryRoughTypeId)
        {
            RoughCategoryRoughType roughCategoryRoughType = _repository.Get(m => (m.RoughTypeId == roughTypeId
                      && m.RoughCategoryId == roughCategoryId
                      && m.Id != roughCategoryRoughTypeId))
                      .FirstOrDefault();

            if (roughCategoryRoughType == null)
            {
                return null;
            }

            return roughCategoryRoughType.IsActive
              ? $"Rough Category Rough Type with same rough category is already exists for the selected Rough type"
              : $"Rough Category Rough Type with same rough category is already exists for the selected Rough type but status is deleted";
        }
        public string CheckRoughTypeWiseDisplayOrderIsUnique(int roughTypeId, int displayOrder, int roughCategoryRoughTypeId)
        {
            RoughCategoryRoughType roughCategoryRoughType = _repository.Get(m => (m.RoughTypeId == roughTypeId
                      && m.DisplayOrder == displayOrder
                      && m.Id != roughCategoryRoughTypeId))
                      .FirstOrDefault();

            if (roughCategoryRoughType == null)
            {
                return null;
            }

            return $"Rough Category Rough Type with same display order is already exists for the selected Rough type";
        }
        #endregion
    }
}
