﻿using System;
using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Services.Interface;

namespace SD.Rough.Average.Services
{
    public class ClarityService : Service<Clarity>, IClarityService
    {
        private IRepository<Clarity> _repository;

        public ClarityService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<Clarity>();
        }

        public string CheckNameGroupNameAndEffectiveDateIsUnique(string name, DateTime effectiveFrom, int clarityId)
        {
            string clarityName = name.Trim();

            var clarity = _repository
                .Get(m => m.Name == clarityName && m.EffectiveFrom == effectiveFrom 
                    && m.Id != clarityId)
                .FirstOrDefault();

            if (clarity == null)
            {
                return null;
            }

            return clarity.IsActive
              ? $"Clarity with same name is already exists for the selected effective date"
              : $"Clarity with same name is already exists for the selected effective date but status is deleted";
        }

        public IList<Clarity> GetClaritiesAsOn(DateTime asOnDate)
        {
            IList<Clarity> clarities = new List<Clarity>();

            clarities = _repository
                .GetWithTracking(x => x.EffectiveFrom <= asOnDate)
                .GroupBy(x => x.Name)
                .Select((IGrouping<string, Clarity> grp) => new
                {
                    grp.Key,
                    Clarity = grp.OrderByDescending(a => a.EffectiveFrom).FirstOrDefault()
                })
                .Where(x => x.Clarity.IsActive)
                .Select(x => x.Clarity)
                .OrderBy(x => x.DisplayOrder)
                .ToList();
                
            return clarities;
        }
    }
}
