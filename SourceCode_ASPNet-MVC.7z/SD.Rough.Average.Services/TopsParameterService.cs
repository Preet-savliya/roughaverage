﻿using System;
using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using static SD.Rough.Average.Services.Shared.TopsExtensions;

namespace SD.Rough.Average.Services
{
    public class TopsParameterService : Service<TopsParameter>, ITopsParameterService
    {
        private readonly IRepository<TopsParameter> _repository;

        public TopsParameterService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<TopsParameter>();
        }

        public IEnumerable<TopsParameter> GetTopsParametersAsOn(DateTime asOnDate)
        {
            return _repository
                .Get(x => x.EffectiveFrom <= asOnDate)
                .GroupBy(x => x.Name.Trim())
                .Select((IGrouping<string, TopsParameter> grp) => new
                {
                    grp.Key,
                    Size = grp.OrderByDescending(y => y.EffectiveFrom).FirstOrDefault()
                })
                .Where(s => s.Size.IsActive)
                .Select(s => s.Size)
                .OrderBy(x => x.MinSieveSize != null ? Convert.ToDecimal(x.MinSieveSize.Name) : 0)
                .ThenBy(x => x.MaxSieveSize != null ? Convert.ToDecimal(x.MaxSieveSize.Name) : 0)
                .ToList();
        }

        public string CheckMinSieveSizeMaxSieveSizeIsActiveAndEffectiveDateIsUnique(int? minSieveSizeId, int? maxSieveSizeId, DateTime effectiveFrom, int topsParametersId)
        {
            var topsParameters = _repository
                .Get(m => m.MinSieveSizeId == minSieveSizeId && m.MaxSieveSizeId == maxSieveSizeId
                    && m.EffectiveFrom == effectiveFrom && m.IsActive
                    && m.Id != topsParametersId)
                .FirstOrDefault();

            if (topsParameters == null)
            {
                return null;
            }

            return topsParameters.IsActive
              ? "Tops Parameter with same min sieve size and max sieve size is already exists for the selected effective date"
              : "Tops Parameter with same min sieve size and max sieve size is already exists for the selected effective date but status is deleted";
        }

        public string ValidateMinSieveSizeAndMaxSieveSize(int? minSieveSizeId, int? maxSieveSizeId)
        {
            string error = null;

            if (!minSieveSizeId.HasValue && !maxSieveSizeId.HasValue)
            {
                error = "Min Sieve Size or Max Sieve Size one of the required";
            }

            return error;
        }
    }
}
