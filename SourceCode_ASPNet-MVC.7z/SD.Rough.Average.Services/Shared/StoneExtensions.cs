﻿using System;
using System.Text.RegularExpressions;

using static SD.Rough.Average.Core.AppGlobalSettings;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Services.Shared
{
    public static class StoneExtensions
    {
        public static string SplitStoneNumber(this string stoneNumber)
        {
            bool isNumeric = Regex.IsMatch(stoneNumber, NumericRegEx);
            if (isNumeric)
                return stoneNumber;

            bool isAlphNumeric = Regex.IsMatch(stoneNumber, AlphaNumericWithDotSpaceRegEx);
            if (isAlphNumeric)
            {
                var number = Convert.ToInt32(Regex.Split(stoneNumber, @"\D+")[0]);
                stoneNumber = number.ToString();
            }

            return stoneNumber;
        }

        public static string SplitStoneNumberForM2(this string stoneNumber, out bool isM2Stone)
        {
            isM2Stone = false;

            if (stoneNumber.Contains(MinusSign))
            {
                var splitStoneNumber = stoneNumber.Split(Convert.ToChar(MinusSign));
                isM2Stone = string.Compare(splitStoneNumber[1], "m2", true) == 0;

                return isM2Stone
                    ? splitStoneNumber[0]
                    : stoneNumber;
            }
            return stoneNumber;
        }

        public static string SplitStoneNumberWithoutM2(this string stoneNumber)
        {
            if (string.IsNullOrEmpty(stoneNumber))
                return stoneNumber;

            string m2String = null;
            string stoneNo;

            if (stoneNumber.Contains(MinusSign))
            {
                string[] splitStoneNumber = stoneNumber.Split(Convert.ToChar(MinusSign));
                stoneNo = splitStoneNumber[0].Trim();
                m2String = $"-{splitStoneNumber[1].Trim()}";
            }
            else
            {
                stoneNo = stoneNumber.Trim();
            }

            string stoneNumberWithoutSerialNo = stoneNo.StoneNumberWithoutLastAlphabet();

            return string.IsNullOrEmpty(m2String)
                ? stoneNumberWithoutSerialNo
                : $"{stoneNumberWithoutSerialNo}{m2String}";
        }

        public static string StoneNumberWithoutLastAlphabet(this string stoneNumber)
        {
            int lastCharacterIndex = stoneNumber.Length - 1;

            char lastCharacter = stoneNumber[lastCharacterIndex];

            if (char.IsDigit(lastCharacter))
                return stoneNumber;
            else
                return stoneNumber.Remove(lastCharacterIndex, 1);
        }
    }
}
