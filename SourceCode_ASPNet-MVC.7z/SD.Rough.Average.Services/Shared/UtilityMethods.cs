﻿using static SD.Rough.Average.Core.AppGlobalSettings;

namespace SD.Rough.Average.Services.Shared
{
    public class UtilityMethods
    {
        public static bool TryGetWeightFromString(string lotParameters, out decimal weight)
        {
            weight = 0;
            var parametersParts = lotParameters.Split(FileNameSeparator);

            if (parametersParts.Length < 2)
                return false;

            var isValidCaratWeight = int.TryParse(parametersParts[0], out int caratWeightValue);
            var isValidCentWeight = int.TryParse(parametersParts[1], out int centWeightValue);

            int doraWeightValue = 0;
            var isValidDora = parametersParts.Length > 2 && parametersParts[2].Length > 0
                ? int.TryParse(parametersParts[2], out doraWeightValue)
                : true;

            if (isValidCaratWeight && isValidCentWeight && isValidDora)
            {
                var centWeight = centWeightValue * 10 + doraWeightValue;
                weight = caratWeightValue + ((decimal)centWeight / 1000);
                return true;
            }
            return false;
        }
    }
}
