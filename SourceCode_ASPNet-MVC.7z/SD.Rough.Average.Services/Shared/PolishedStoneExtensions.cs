﻿using System;
using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Core;
using SD.Rough.Average.Models;
using static SD.Rough.Average.Core.AppGlobalSettings;

namespace SD.Rough.Average.Services.Shared
{
    public static class PolishedStoneExtensions
    {
        public static IList<PolishedStone> PolishedStonesByDiameter(this List<PolishedStone> polishedStoneData,
            decimal? minDiameter, decimal? maxDiameter)
        {
            return polishedStoneData
                .Where(ps => (minDiameter == null || ps.MeasureByValue >= minDiameter.Value)
                    && (maxDiameter == null || ps.MeasureByValue < maxDiameter.Value)
                    && ps.IsActive)
                .ToList();
        }

        public static IList<PolishedStone> PolishedStonesByClarity(this List<PolishedStone> polishedStoneData,
            string clarity)
        {
            return polishedStoneData
                .Where(ps => string.Compare(ps.Clarity.Name, clarity, true) == 0 && ps.IsActive)
                .ToList();
        }


        // Tops Related Methods

        // CODE-REFACTOR: Pull-out method for code-resuability.
        // For ex. Create TopsSpecification to filter the tops based on the Diameter Range
        // and Making
        public static List<PolishedStone> GetPolishedStoneData(this IList<Lot> lotData,
            string sarinActivity, TopsDiameterRange topsDiameterRange,
            PolishedStoneType polishedStoneType, EntryStatus entryStatus = EntryStatus.Active)
        {
            if (sarinActivity == "Rough")
                sarinActivity = "Rough Planning";

            var lots = lotData.Where(x => x.SarinActivity?.Name == sarinActivity
                && (entryStatus == EntryStatus.All || (x.IsActive == (entryStatus == EntryStatus.Active))))
                .ToList();

            var polishedStones = new List<PolishedStone>();
            foreach (Lot lot in lots)
            {
                var lotPolishedStonesData = lot.GetLotPolishedStoneData(sarinActivity, 
                    topsDiameterRange, polishedStoneType, entryStatus);

                var polStones = polishedStoneType == PolishedStoneType.MakingStone
                    ? lotPolishedStonesData.MakingStones
                    : lotPolishedStonesData.Tops;

                if (polStones?.Count > 0)
                    polishedStones.AddRange(polStones);
            }

            return polishedStones;
        }

        public static List<LotPolishedStoneData> GetLotPolishedStoneData(this IList<Lot> lotData,
            string sarinActivity, TopsDiameterRange topsDiameterRange)
        {
            if (sarinActivity == "Rough")
                sarinActivity = "Rough Planning";

            var lots = lotData
                .Where(x => x.SarinActivity.Name == sarinActivity && x.IsActive)
                .ToList();

            var result = new List<LotPolishedStoneData>();
            foreach (var lot in lots)
            {
                var lotPolishedStones = lot.GetLotPolishedStoneData(sarinActivity, topsDiameterRange);
                result.Add(lotPolishedStones);
            }

            return result;
        }

        public static LotPolishedStoneData GetLotPolishedStoneData(this Lot lot,
            string sarinActivity, TopsDiameterRange topsDiameterRange,
            PolishedStoneType polishedStoneType = PolishedStoneType.MakingStone,
            EntryStatus entryStatus = EntryStatus.Active)
        {
            if (lot is null)
                return null;

            if (sarinActivity == "Rough")
                sarinActivity = "Rough Planning";

            var lotPolishedStoneData = new LotPolishedStoneData
            {
                LotId = lot.Id
            };

            bool isTopsLot = sarinActivity == MakeableSarinActivity && polishedStoneType == PolishedStoneType.Tops
                ? true : false;

            var lotAllStones = lot.Stones
                .Where(x => entryStatus == EntryStatus.All || x.IsActive == (entryStatus == EntryStatus.Active))
                .ToList();
        
            if (sarinActivity == MakeableSarinActivity)
            {
                if (polishedStoneType == PolishedStoneType.MakingStone)
                {
                    lotPolishedStoneData.MakingStones = lotAllStones
                        .SelectMany(s => s.PolishedStones)
                        .ToList();
                }
                else
                {
                    lotPolishedStoneData.Tops = lotAllStones
                        .SelectMany(s => s.PolishedStones)
                        .ToList();
                }

                return lotPolishedStoneData;
            }

            var lotStones = lotAllStones
                .Select(x => new
                {
                    StoneId = x.Id,
                    StoneNumber = Convert.ToInt32(x.StoneNumber),
                    PolishedStones = x.PolishedStones
                        .Where(y => (topsDiameterRange.MinPolishedDiameter == 0
                                || y.MeasureByValue >= topsDiameterRange.MinPolishedDiameter)
                            && (entryStatus == EntryStatus.All || y.IsActive == (entryStatus == EntryStatus.Active)))
                        .ToList()
                }).ToList();

            // Check if Lot has specific requirement for the Tops
            // like for some Range of Stones and specific Clarities, tops diameter value would be different
            if (lot.LotStoneTopsParameters?.Count > 0)
            {
                var lotStoneTopsParameters = lot.LotStoneTopsParameters
                    .Select(x => new { x.StoneNumberFrom, x.StoneNumberTo, x.StoneTopsParameters })
                    .ToList();

                var stonesWithCustomTopsCalculationReq = new List<StoneTopsParameterModel>();
                foreach (var lotStoneTopsParamEntry in lotStoneTopsParameters)
                {
                    var filteredStones = lotStones
                        .Where(x => x.StoneNumber >= lotStoneTopsParamEntry.StoneNumberFrom
                                 && x.StoneNumber <= lotStoneTopsParamEntry.StoneNumberTo)
                        .Select(s => new StoneTopsParameterModel
                        {
                            StoneId = s.StoneId,
                            StoneNumber = s.StoneNumber,
                            TopsParameters = lotStoneTopsParamEntry
                                .StoneTopsParameters
                                .Select(st => new TopsParameterModel
                                {
                                    ClarityId = st.ClarityId,
                                    TopsDiameter = st.TopsDiameter
                                }).ToList()
                        }).ToList();

                    stonesWithCustomTopsCalculationReq.AddRange(filteredStones);
                }

                var stoneDataWithCustomTopsParams = stonesWithCustomTopsCalculationReq
                    .GroupBy(g => new { g.StoneId, g.StoneNumber })
                    .Select(x => new
                    {
                        x.Key.StoneId,
                        x.Key.StoneNumber,
                        TopsParameters = x.SelectMany(s => s.TopsParameters).Distinct().ToList()
                    }).ToList();

                var stoneIdsForCustomTopsCalculation = stoneDataWithCustomTopsParams
                    .Select(s => s.StoneId)
                    .ToArray();

                var stonesForCustomTopsCalculation = lotStones
                    .Where(x => stoneIdsForCustomTopsCalculation.Contains(x.StoneId))
                    .ToList();

                var tops = new List<PolishedStone>();
                var makingPolishedStones = new List<PolishedStone>();

                // For all the Stones with Custom Tops Calculation Requirement
                // Generate separate Collections of Polished Stones Tops Diameter Values
                foreach (var stone in stonesForCustomTopsCalculation)
                {
                    var topsParams = stoneDataWithCustomTopsParams
                        .Where(x => x.StoneId == stone.StoneId)
                        .SelectMany(s => s.TopsParameters)
                        .ToList();

                    foreach (var polStone in stone.PolishedStones)
                    {
                        var clarityTopsDiameter = (topsParams
                            .Where(x => x.ClarityId == polStone.ClarityId)
                            .FirstOrDefault()?.TopsDiameter - 0.006M) ?? topsDiameterRange.DiameterTo;

                        if (clarityTopsDiameter > 0 && polStone.MeasureByValue <= clarityTopsDiameter)
                        {
                            tops.Add(polStone);
                        }
                        else
                        {
                            makingPolishedStones.Add(polStone);
                        }
                    }
                }

                // just call method to calculate tops based on regular tops calculation logic and generate result modal
                var polishedStonesForRegularTopsCalculation = lotStones
                    .Where(x => !stoneIdsForCustomTopsCalculation.Contains(x.StoneId))
                    .SelectMany(s => s.PolishedStones)
                    .ToList();

                if (topsDiameterRange.DiameterTo > 0)
                {
                    tops.AddRange(
                        polishedStonesForRegularTopsCalculation
                            .Where(x => x.MeasureByValue >= topsDiameterRange.DiameterFrom
                                && x.MeasureByValue <= topsDiameterRange.DiameterTo)
                            .ToList()
                    );
                }

                makingPolishedStones.AddRange(
                    polishedStonesForRegularTopsCalculation
                    .Where(x => x.MeasureByValue > topsDiameterRange.DiameterTo)
                    .ToList()
                );

                lotPolishedStoneData.MakingStones = makingPolishedStones;
                lotPolishedStoneData.Tops = tops;

                return lotPolishedStoneData;
            }
            else
            {
                if (topsDiameterRange.DiameterTo == 0)
                {
                    // Then all polished stones are pieces only, so no need to check for Tops 
                    // and just return all the Polished Stones as Making/Manufacturing stones

                    lotPolishedStoneData.MakingStones = lotStones.SelectMany(s => s.PolishedStones).ToList();
                    return lotPolishedStoneData;
                }

                lotPolishedStoneData.Tops = lotStones
                    .SelectMany(s => s.PolishedStones
                        .Where(y => y.MeasureByValue >= topsDiameterRange.DiameterFrom
                            && y.MeasureByValue <= topsDiameterRange.DiameterTo))
                    .ToList();

                lotPolishedStoneData.MakingStones = lotStones
                    .SelectMany(s => s.PolishedStones.Where(y => y.MeasureByValue > topsDiameterRange.DiameterTo))
                    .ToList();

                return lotPolishedStoneData;
            }
        }

        public static bool IsPolishedTop(decimal measureByValue, int polishedStoneClarityId,
            int roughStoneNumber, string sarinActivity, TopsDiameterRange topsDiameterRange,
            IList<LotStoneTopsParameter> lotStoneTopsParameters)
        {
            if (sarinActivity == "Rough" || sarinActivity == "RoughPlanning")
                sarinActivity = "Rough Planning";

            var topsDiameterTo = topsDiameterRange.DiameterTo;

            if (sarinActivity == RoughSarinActivity && lotStoneTopsParameters?.Count > 0)
            {
                var stoneTopsParameters = lotStoneTopsParameters
                    .Where(x => x.StoneNumberFrom <= roughStoneNumber && x.StoneNumberTo >= roughStoneNumber)
                    .ToList();

                if (stoneTopsParameters.Any())
                {
                    var clarityTopsParameter = stoneTopsParameters
                        .SelectMany(x => x.StoneTopsParameters)
                        .Where(x => x.ClarityId == polishedStoneClarityId)
                        .FirstOrDefault();

                    if (clarityTopsParameter != null)
                    {
                        topsDiameterTo = clarityTopsParameter.TopsDiameter - 0.006M;
                    }
                }
            }

            if (topsDiameterTo == 0)
            {
                return false;
            }

            return measureByValue >= topsDiameterRange.DiameterFrom
                && measureByValue <= topsDiameterTo;
        }
    }
}
