﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using static SD.Rough.Average.Core.AppGlobalSettings;

namespace SD.Rough.Average.Services.Shared
{
    public enum RoughSubTypeBehavior
    {
        All,
        BehaveSeparately,
        NotBehaveSeparately
    }

    public static class SubRoughUtility
    {
        public static string GenerateRoughName(SubRough subRough)
        {
            if (subRough == null || (subRough.RoughType == null && subRough.RoughColorShade == null))
                return string.Empty;

            string roughName = subRough.RoughType != null
                ? (subRough.RoughColorShade == null
                    ? subRough.RoughType.Name.Trim()
                    : string.Join(EntityValueSeprator.ToString(), subRough.RoughType.Name.Trim(), subRough.RoughColorShade.Name.Trim()))
                : subRough.RoughColorShade.Name.Trim();

            return (subRough.Number.HasValue && subRough.Number.Value > 0)
                ? string.Join(EntityValueSeprator.ToString(), roughName, subRough.Number.Value.ToString("00"))
                : roughName;
        }
    }

    public static class SubRoughExtensions
    {
        public static List<RoughCategory> RoughSubTypes(this SubRough subRough,
            RoughSubTypeBehavior subTypeBehavior)
        {
            Func<RoughCategoryRoughType, bool> predicate = null;

            if (subTypeBehavior == RoughSubTypeBehavior.All)
            {
                predicate = x => x.IsActive;
            }
            else
            {
                predicate = x => x.IsActive
                    && x.IsBehaveSeparately.HasValue
                    && x.IsBehaveSeparately.Value == (subTypeBehavior == RoughSubTypeBehavior.BehaveSeparately);
            }

            return subRough.RoughType.RoughCategoryRoughTypes
                .Where(predicate)
                .OrderBy(x => x.DisplayOrder)
                .Select(x => new RoughCategory
                {
                    Id = x.RoughCategoryId,
                    Name = x.RoughCategory.Name
                }).ToList();
        }

        public static void SetPriceListAndSieveSizeFileData(this SubRough subRough,
            IList<SieveSizeFileImport> sieveSizeFileImports)
        {
            var sieveSizeFileName = subRough.SieveSizeFileImportId.HasValue
                ? subRough.SieveSizeFileImport.Name
                : sieveSizeFileImports
                    .Where(x => x.EffectiveFrom <= subRough.AssignedOn)
                    .OrderByDescending(x => x.EffectiveFrom)
                    .FirstOrDefault()?.Name;

            subRough.SieveSizeFileName = Path.GetFileNameWithoutExtension(sieveSizeFileName);
            subRough.SetPriceListData();
        }

        public static void SetPriceListData(this SubRough subRough)
        {
            var priceList = subRough.Lots
                .LotsBySarinActivity(RoughSarinActivity)
                .Select(x => x.ColorRateVersion?.Name)
                .Distinct()
                .OrderBy(o => o)
                .ToList();

            if (priceList.Count > 0)
            {
                subRough.PriceList = priceList.Aggregate((acc, pl) => $"{acc}, {pl}");
            }
        }
    }
}
