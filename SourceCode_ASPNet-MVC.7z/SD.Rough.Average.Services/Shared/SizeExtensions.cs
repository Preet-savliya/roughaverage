﻿using System;
using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using static SD.Rough.Average.Core.AppGlobalSettings;

namespace SD.Rough.Average.Services.Shared
{
    public static class SizeExtensions
    {
        public static IList<PolishedSieveSize> GetAsOnDetail(this IEnumerable<PolishedSieveSize> polishedSieveSizes,
            DateTime asOnDate)
        {
            IList<PolishedSieveSize> polishedSieveSize = polishedSieveSizes
                .Where(x => x.EffectiveFrom <= asOnDate)
                .GroupBy(x => x.Name.Trim())
                .Select((IGrouping<string, PolishedSieveSize> grp) => new
                {
                    grp.Key,
                    Size = grp.OrderByDescending(y => y.EffectiveFrom).GroupBy(x => x.EffectiveFrom).FirstOrDefault().Count() > 1
                        ? grp.OrderByDescending(y => y.EffectiveFrom).Where(x => x.IsActive).FirstOrDefault()
                        : grp.OrderByDescending(y => y.EffectiveFrom).FirstOrDefault()
                })
                .Where(s => s.Size.IsActive)
                .Select(s => s.Size)
                .OrderBy(x => x.MinSieveSize != null ? Convert.ToDecimal(x.MinSieveSize.Name) : 0)
                .ToList();

            return polishedSieveSize;
        }

        public static IList<RoughSizePolishedSieveSize> GetAsOnDetail(this IEnumerable<RoughSizePolishedSieveSize> roughSizePolishedSieveSizes,
            DateTime asOnDate)
        {
            return roughSizePolishedSieveSizes
                .Where(x => x.EffectiveFrom <= asOnDate)
                .GroupBy(x => x.PolishedSieveSize.Name)
                .Select((IGrouping<string, RoughSizePolishedSieveSize> grp) => new
                {
                    grp.Key,
                    Size = grp.OrderByDescending(y => y.EffectiveFrom).FirstOrDefault()
                })
                .Where(s => s.Size.IsActive)
                .Select(s => s.Size)
                .OrderBy(x => x.PolishedSieveSize.MinSieveSize != null ? Convert.ToDecimal(x.PolishedSieveSize.MinSieveSize.Name) : 0)
                .ToList();
        }

        public static IList<RoughSizePolishedSieveSize> GetInActiveDataAsOnDetail(this IEnumerable<RoughSizePolishedSieveSize> roughSizePolishedSieveSizes,
            DateTime asOnDate)
        {
            return roughSizePolishedSieveSizes
                .Where(x => x.EffectiveFrom <= asOnDate)
                .GroupBy(x => x.PolishedSieveSize.Name)
                .Select((IGrouping<string, RoughSizePolishedSieveSize> grp) => new
                {
                    grp.Key,
                    Size = grp.OrderByDescending(y => y.EffectiveFrom).FirstOrDefault()
                })
                .Where(s => !s.Size.IsActive)
                .Select(s => s.Size)
                .OrderBy(x => x.PolishedSieveSize.MinSieveSize != null ? Convert.ToDecimal(x.PolishedSieveSize.MinSieveSize.Name) : 0)
                .ToList();
        }

        public static SieveSizeName SplitSieveSize(this string sieveSize)
        {
            SieveSizeName sieveSizeName = new SieveSizeName();
            string[] splitSize;
            if (sieveSize.Contains(PlusSign) && sieveSize.Contains(MinusSign))
            {
                splitSize = sieveSize.Split(Convert.ToChar(MinusSign));
                sieveSizeName.MinSieveSize = splitSize.First().Split(Convert.ToChar(PlusSign)).Last().Trim();
                sieveSizeName.MaxSieveSize = splitSize.Last().Trim();
            }
            else if (sieveSize.Contains(PlusSign))
            {
                splitSize = sieveSize.Split(Convert.ToChar(PlusSign));
                sieveSizeName.MinSieveSize = splitSize.Last().Trim();
                sieveSizeName.MaxSieveSize = null;
            }
            else if (sieveSize.Contains(MinusSign))
            {
                splitSize = sieveSize.Split(Convert.ToChar(MinusSign));
                sieveSizeName.MinSieveSize = null;
                sieveSizeName.MaxSieveSize = splitSize.Last().Trim();
            }

            return sieveSizeName;
        }

        public static string GenerateName(this SieveSizeName sieveSizeName)
        {
            if (sieveSizeName == null)
                return string.Empty;

            var minSieveSize = sieveSizeName.MinSieveSize == null
                ? string.Empty
                : $"+{sieveSizeName.MinSieveSize}";

            var maxSieveSize = sieveSizeName.MaxSieveSize == null
                ? string.Empty
                : $"-{sieveSizeName.MaxSieveSize}";

            var separator = (sieveSizeName.MinSieveSize == null || sieveSizeName.MaxSieveSize == null)
                ? string.Empty
                : " ";

            return $"{minSieveSize}{separator}{maxSieveSize}".Trim();
        }
    }
}
