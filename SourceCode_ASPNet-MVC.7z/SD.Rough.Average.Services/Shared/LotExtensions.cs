﻿using System.Linq;
using System.Collections.Generic;
using SD.Rough.Average.Models;

namespace SD.Rough.Average.Services.Shared
{
    public static class LotExtensions
    {
        public static List<Lot> LotsByRoughCategory(this ICollection<Lot> lotData, int? roughCategoryId)
            => lotData.Where(x => x.RoughCategoryId == roughCategoryId && x.IsActive).ToList();

        public static List<Lot> LotsBySarinActivity(this ICollection<Lot> lotData, string sarinActivity)
            => lotData
                .Where(x => x.SarinActivity.Name == sarinActivity 
                    && (x.IsTopsLot == null || x.IsTopsLot == false)
                    && x.IsActive).ToList();

        public static List<Lot> LotsBySarinActivity(this ICollection<Lot> lotData, string sarinActivity, bool isTopsLot = false)
            => lotData
                .Where(x => x.SarinActivity.Name == sarinActivity 
                    && x.IsTopsLot.HasValue && x.IsTopsLot.Value == isTopsLot 
                    && x.IsActive)
                .ToList();
    }
}
