﻿using System.Collections.Generic;

using SD.Rough.Average.Models;

namespace SD.Rough.Average.Services.Shared
{
    public enum PolishedStoneType
    {
        MakingStone = 1,
        Tops = 2
    }

    public class LotPolishedStoneData
    {
        public int LotId { get; set; }
        public List<PolishedStone> MakingStones { get; set; } = new List<PolishedStone>();
        public List<PolishedStone> Tops { get; set; } = new List<PolishedStone>();
    }

    public class TopsDiameterRange
    {
        public decimal MinPolishedDiameter { get; set; }
        public decimal TopsPolishedDiameter { get; set; }

        public decimal DiameterFrom { get; set; }
        public decimal DiameterTo { get; set; }

        public static TopsDiameterRange GetTopsDiameterRange(decimal? minPolishedDiameter, decimal? topsPolishedDiameter)
        {
            var topsDiameters = new TopsDiameterRange
            {
                MinPolishedDiameter = minPolishedDiameter ?? 0,
                TopsPolishedDiameter = topsPolishedDiameter ?? 0
            };

            if (topsDiameters.TopsPolishedDiameter == 0
                || topsDiameters.TopsPolishedDiameter <= topsDiameters.MinPolishedDiameter)
            {
                topsDiameters.DiameterFrom = 0;
                topsDiameters.DiameterTo = 0;

                return topsDiameters;
            }

            topsDiameters.DiameterFrom = topsDiameters.MinPolishedDiameter;
            topsDiameters.DiameterTo = topsDiameters.TopsPolishedDiameter;

            return topsDiameters;
        }
    }

    public class StoneTopsParameterModel
    {
        public int StoneId { get; set; }
        public int StoneNumber { get; set; }

        public List<TopsParameterModel> TopsParameters { get; set; }
            = new List<TopsParameterModel>();

    }

    public class TopsParameterModel
    {
        public int ClarityId { get; set; }
        public decimal TopsDiameter { get; set; }
    }
}
