﻿using System.Collections.Generic;
using System.Linq;

using SD.Rough.Average.Core;
using SD.Rough.Average.Models;

namespace SD.Rough.Average.Services.Shared
{
    public static class TopsUtility
    {
        public static decimal GetMaxTopsDiameter(decimal? topsPolishedDiameter, decimal? minPolishedDiameter)
        {
            var minPolishedDiameterVal = minPolishedDiameter ?? 0;
            var topsPolishedDiameterVal = topsPolishedDiameter ?? 0;

            return topsPolishedDiameterVal >= minPolishedDiameterVal
                ? topsPolishedDiameterVal
                : (minPolishedDiameter.Value - 0.001M);
        }
    }

    public static class TopsExtensions
    {
        public static IEnumerable<Tops> TopsRoughStones(this List<Lot> lotData, EntryStatus entryStatus = EntryStatus.All)
        {
            return lotData
                .Where(l => entryStatus == EntryStatus.All || l.IsActive == (entryStatus == EntryStatus.Active))
                .SelectMany(l => l.Stones
                    .Where(s => entryStatus == EntryStatus.All || s.IsActive == (entryStatus == EntryStatus.Active))
                    .SelectMany(s => s.Topses
                        .Where(t => entryStatus == EntryStatus.All || t.IsActive == (entryStatus == EntryStatus.Active))));
        }

        public static TopsType GetTopsTypeByLots(this List<Lot> lots,
            string sarinActivity, TopsDiameterRange topsDiameterRange,
            EntryStatus entryStatus = EntryStatus.Active)
        {
            bool hasRoughTops = lots.TopsRoughStones(entryStatus).Count() > 0;

            var hasPolishedTops = lots
                .GetPolishedStoneData(sarinActivity, topsDiameterRange, PolishedStoneType.Tops, entryStatus)
                .Any();

            if (hasRoughTops && hasPolishedTops)
                return TopsType.Many;
            else if (!hasRoughTops && !hasPolishedTops)
                return TopsType.None;
            else if (hasRoughTops)
                return TopsType.Rough;
            else if (hasPolishedTops)
                return TopsType.Polished;

            return TopsType.NotSpecified;
        }

        public static TopsType GetTopsTypeByLots(this Lot lot, string sarinActivity,
            TopsDiameterRange topsDiameterRange, EntryStatus entryStatus = EntryStatus.All)
        {
            var lots = new List<Lot> { lot };
            return lots.GetTopsTypeByLots(sarinActivity, topsDiameterRange, entryStatus);
        }

        public static decimal TopsRoughWeightFromTopsList(this IEnumerable<Tops> topsData)
        {
            decimal roughWeight = 0;
            List<Tops> topsDetails = topsData.ToList();

            if (topsDetails != null && topsDetails.Count > 0)
                roughWeight = topsData.Where(x => x.IsActive).Sum(s => s.PartWeight);

            return roughWeight;
        }
    }
}
