﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class ShapeService : Service<Shape>, IShapeService
    {
        private IRepository<Shape> _repository;

        public ShapeService(IUnitOfWork unitOfWork, IRepository<Shape> repository) : base(unitOfWork)
        {
            _repository = repository;
        }

        public string CheckNameIsUnique(string name, int id)
        {
            string shapeName = name.Trim();
            Shape shape = _repository
                .FirstOrDefault(p => (p.Name == shapeName) && (p.Id != id));

            if (shape == null)
            {
                return null;
            }

            return shape.IsActive 
                ? $"Shape Name - {shapeName} entry is already exists"
                : $"Shape Name - {shapeName} entry is already exists but status is deleted";
        }
    }
}
