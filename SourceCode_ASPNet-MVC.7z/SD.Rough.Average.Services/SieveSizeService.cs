﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class SieveSizeService : Service<SieveSize>, ISieveSizeService
    {
        #region Fields
        private IRepository<SieveSize> _repository;
        #endregion

        #region Ctor
        public SieveSizeService(IUnitOfWork unitOfWork, IRepository<SieveSize> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckNameIsUnique(string name, int id)
        {
            string sieveSizeName = name.Trim();
            SieveSize sieveSize = _repository.FirstOrDefault(p => (p.Name == sieveSizeName) && (p.Id != id));

            if (sieveSize == null)
            {
                return null;
            }
            return sieveSize.IsActive
            ? $"Sieve Size Name - {sieveSizeName} entry is already exists"
            : $"Sieve Size Name - {sieveSizeName} entry is already exists but status is deleted";
        }
        #endregion
    }
}
