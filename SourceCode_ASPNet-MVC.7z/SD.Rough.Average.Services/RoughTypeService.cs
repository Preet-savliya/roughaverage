﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Interface;

    public class RoughTypeService : Service<RoughType>, IRoughTypeService
    {
        #region Fields
        private IRepository<RoughType> _repository;
        #endregion

        #region Ctor
        public RoughTypeService(IUnitOfWork unitOfWork,
            IRepository<RoughType> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckNameIsUnique(string name, int id)
        {
            string roughTypeName = name.Trim();

            RoughType roughType = _repository.FirstOrDefault(m => (m.Name == roughTypeName) && (m.Id != id));

            if (roughType == null)
            {
                return null;
            }

            return roughType.IsActive
               ? $"Rough Type Name - {roughTypeName} entry is already exists"
               : $"Rough Type Name - {roughTypeName} entry is already exists but status is deleted";
        }
        #endregion
    }
}
