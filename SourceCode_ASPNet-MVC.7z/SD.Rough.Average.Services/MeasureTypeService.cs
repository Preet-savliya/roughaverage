﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class MeasureTypeService : Service<MeasureType>, IMeasureTypeService
    {
        #region Fields
        private IRepository<MeasureType> _repository;
        #endregion

        #region Ctor
        public MeasureTypeService(IUnitOfWork unitOfWork, IRepository<MeasureType> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckCodeIsUnique(string code, int id)
        {
            string measureTypeCode = code.Trim();
            MeasureType measureType = _repository.FirstOrDefault(m => (m.Code == measureTypeCode) && (m.Id != id));

            if (measureType == null)
            {
                return null;
            }

            return measureType.IsActive
                ? $"Measure Type Code - {measureTypeCode} entry is already exists"
                : $"Measure Type Code - {measureTypeCode} entry is already exists but status is deleted";
        }

        public string CheckNameIsUnique(string name, int id)
        {
            string measureTypeName = name?.Trim();

            MeasureType measureType = _repository.FirstOrDefault(m => (m.Name == measureTypeName) && (m.Id != id));

            if (measureType == null)
            {
                return null;
            }

            return measureType.IsActive
                ? $"Measure Type Name - {measureTypeName} entry is already exists"
                : $"Measure Type Name - {measureTypeName} entry is already exists but status is deleted";
        }
        #endregion
    }
}
