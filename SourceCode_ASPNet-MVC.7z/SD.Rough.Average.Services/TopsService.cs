﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;
using System.Collections.Generic;

namespace SD.Rough.Average.Services
{
    public class TopsService : Service<Tops>, ITopsService
    {
        #region PrivateFields
        private IRepository<Tops> _repository;
        #endregion

        #region Ctor
        public TopsService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<Tops>();
        }
        #endregion

        #region Methods
        public ICollection<Lot> DeActivateTops(ICollection<Lot> lots, int userId)
        {
            foreach (Lot lot in lots)
            {
                foreach (Stone stone in lot.Stones)
                {
                    DeActivateMany(stone.Topses, userId);
                }
            }

            return lots;
        }

        public ICollection<Stone> DeActivateTops(ICollection<Stone> stones, int userId)
        {
            foreach (Stone stone in stones)
            {
                DeActivateMany(stone.Topses, userId);
            }

            return stones;
        }

        public ICollection<Stone> ActivateTopsDetail(ICollection<Stone> stones, int userId)
        {
            foreach (Stone stone in stones)
            {
                ActivateMany(stone.Topses, userId);
            }

            return stones;
        }

        #endregion
    }
}
