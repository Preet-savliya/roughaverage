﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Interface;

    public class LossTypeService : Service<LossType>, ILossTypeService
    {
        #region Fields
        private IRepository<LossType> _repository;
        #endregion

        #region Ctor
        public LossTypeService(IUnitOfWork unitOfWork,IRepository<LossType> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckCodeIsUnique(string code, int id)
        {
            string lossTypeCode = code.Trim();
            LossType lossType = _repository.FirstOrDefault(p => (p.Code == lossTypeCode) && (p.Id != id));

            if (lossType == null)
            {
                return null;
            }

            return lossType.IsActive
            ? $"Loss Type Code - {lossTypeCode.ToUpper()} entry is already exists"
            : $"Loss Type Code - {lossTypeCode.ToUpper()} entry is already exists but status is deleted";
        }

        public string CheckTypeIsUnique(string type, int id)
        {
            string lossTypeTypes = type.Trim();
            LossType lossType = _repository.FirstOrDefault(p => (p.Type == lossTypeTypes) && (p.Id != id));

            if (lossType == null)
            {
                return null;
            }

            return lossType.IsActive
            ? $"Loss Type Types - {lossTypeTypes} entry is already exists"
            : $"Loss Type Types - {lossTypeTypes} entry is already exists but status is deleted";
        }
        #endregion
    }
}
