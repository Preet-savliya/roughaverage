﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IColorRateVersionService : IService<ColorRateVersion>
    {
        #region Methods
        string CheckColorIdNameIsUnique(int colorId, string name, int id);
        #endregion
    }
}
