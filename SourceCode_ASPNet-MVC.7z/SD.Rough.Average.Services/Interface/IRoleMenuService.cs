﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using System.Collections.Generic;

namespace SD.Rough.Average.Services.Interface
{
    public interface IRoleMenuService : IService<RoleMenu>
    {
        #region Methods
        IList<RoleMenu> GetAllRoleMenuByID(int roleID);
        #endregion
    }
}
