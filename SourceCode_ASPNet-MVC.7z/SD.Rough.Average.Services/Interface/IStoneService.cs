﻿using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface IStoneService : IService<Stone>
    {
        ICollection<Lot> DeActivateStones(ICollection<Lot> lots, int userId);
    }
}
