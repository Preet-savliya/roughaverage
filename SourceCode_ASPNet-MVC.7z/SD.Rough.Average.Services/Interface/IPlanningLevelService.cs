﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IPlanningLevelService : IService<PlanningLevel>
    {
        #region Methods
        string CheckNameIsUnique(string name,int id);
        #endregion
    }
}
