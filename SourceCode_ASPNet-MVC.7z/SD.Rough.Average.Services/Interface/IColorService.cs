﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IColorService : IService<Color>
    {
        #region Methods
        string CheckNameIsUnique(string name, int id);
        #endregion
    }
}
