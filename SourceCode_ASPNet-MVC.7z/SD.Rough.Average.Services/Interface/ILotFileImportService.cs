﻿using System.Collections.Generic;
using SD.Rough.Average.Core;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.DTO;
using SD.Rough.Average.Services.Shared;

namespace SD.Rough.Average.Services.Interface
{
    public interface ILotFileImportService
    {
        Either<Lot, List<StoneDTO>> ParseLotFiles(Dictionary<string, List<string>> lotAllFilesData,
            SubRough subRough, Lot lot, SarinActivityType sarinActivity,
            TopsType subRoughTopsType, TopsDiameterRange topsDiameterRange,
            IReadOnlyList<LotFileHeaderSchema> lotFileHeaderSchema, 
            ColorRateVersion colorRateVersion, int userLoginId);
    }
}
