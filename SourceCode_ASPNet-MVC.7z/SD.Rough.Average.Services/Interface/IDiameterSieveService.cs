﻿using System;
using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface IDiameterSieveService : IService<DiameterSieveSize>
    {
        decimal? GetDiameterBySize(int sieveSizeId, DateTime effectiveDate);
        IList<DiameterSieveSize> GetDiametersAsOn(DateTime asOnDate);
        string CheckDiameterIsUnique(decimal minDiameter, int sieveSizeFileImportId, int id);

        string ValidateMinDiameterAndMinDiameterUpTo(decimal minDiameter, decimal? minDiameterUpTo);
    }
}
