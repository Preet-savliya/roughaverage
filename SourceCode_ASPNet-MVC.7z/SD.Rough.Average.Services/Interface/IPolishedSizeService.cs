﻿namespace SD.Rough.Average.Services.Interface
{
    using System;
    using System.Collections.Generic;
    using Models;
    using Abstract;

    public interface IPolishedSizeService : IService<PolishedSieveSize>
    {
        #region Method
        IList<PolishedSieveSize> GetPolishedSieveSizeWithDiameters(IList<PolishedSieveSize> polishedSieveSizes, SubRough subRough);

        IEnumerable<PolishedSieveSize> GetPolishedSieveSizeAsOn(DateTime assignedOn);

        string CheckMinSieveSizeMaxSieveSizeParentIdIsActiveAndEffectiveDateIsUnique
            (int? minSieveSizeId, int? maxSieveSizeId, DateTime effectiveFrom, int? parentId, int polishedSieveSizeId);

        string ValidateMinSieveSizeAndMaxSieveSize(int? minSieveSizeId, int? maxSieveSizeId);
        #endregion
    }
}
