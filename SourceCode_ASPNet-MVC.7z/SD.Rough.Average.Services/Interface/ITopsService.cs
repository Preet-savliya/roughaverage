﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using System.Collections.Generic;

namespace SD.Rough.Average.Services.Interface
{
    public interface ITopsService : IService<Tops>
    {
        ICollection<Lot> DeActivateTops(ICollection<Lot> lots, int userId);

        ICollection<Stone> DeActivateTops(ICollection<Stone> stones, int userId);

        ICollection<Stone> ActivateTopsDetail(ICollection<Stone> stones, int userId);
    }
}
