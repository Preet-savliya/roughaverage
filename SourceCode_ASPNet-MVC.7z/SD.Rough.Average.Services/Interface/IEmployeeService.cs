﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using System.Collections.Generic;
    using SD.Rough.Average.Services.Abstract;
    using System.ComponentModel.DataAnnotations;

    public interface IEmployeeService : IService<Employee>
    {
        IEnumerable<ValidationResult> ValidateEmployeeNoUniqueness(Employee employee);
    }
}
