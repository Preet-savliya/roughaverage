﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Core;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface ILotService : IService<Lot>
    {
        //Lot ReadLotImportFile(string filePath, SubRough subRough, int lotId, int sessionId,
        //    string sarinActivity, TopsType topsType, int polishedStoneIterations, out int rowCount);

        bool TryParseLotFileName(string file, int lotId);

        bool ValidateTopsType(TopsType subRoughTopsType, TopsType lotTopsType);
    }
}
