﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using System.Collections.Generic;

namespace SD.Rough.Average.Services.Interface
{
    public interface IPolishedStoneService : IService<PolishedStone>
    {
        ICollection<Lot> DeActivatePolishedStones(ICollection<Lot> lots, int userId);

        ICollection<Stone> DeActivatePolishedStones(ICollection<Stone> stones, int userId);

        ICollection<Stone> ActivatePolishedStones(ICollection<Stone> stones, int userId);
    }
}
