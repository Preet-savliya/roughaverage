﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using System.Collections.Generic;

namespace SD.Rough.Average.Services.Interface
{
    public interface ILotAssignService : IService<LotAssign>
    {
        void DeleteLotAssignDetail(IList<LotAssign> dbLotAssigns, IList<LotAssign> lotAssign);
        void UpdateLotAssignDetail(IList<LotAssign> dbLotAssigns, IList<LotAssign> lotAssign, int userId);
        void InsertLotAssignDetail(IList<LotAssign> lotAssign, int userId);
    }
}
