﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IRoughCategoryService : IService<RoughCategory>
    {
        #region Methods
        string CheckNameIsUnique(string name, int id);
        #endregion
    }
}
