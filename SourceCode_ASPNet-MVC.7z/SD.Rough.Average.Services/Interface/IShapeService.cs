﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IShapeService : IService<Shape>
    {
        string CheckNameIsUnique(string name, int id);
    }
}
