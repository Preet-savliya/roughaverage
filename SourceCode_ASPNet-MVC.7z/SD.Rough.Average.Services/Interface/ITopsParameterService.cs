﻿using System;
using System.Collections.Generic;

using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface ITopsParameterService : IService<TopsParameter>
    {
        IEnumerable<TopsParameter> GetTopsParametersAsOn(DateTime assignedOn);

        string CheckMinSieveSizeMaxSieveSizeIsActiveAndEffectiveDateIsUnique
            (int? MinSieveSizeId, int? MaxSieveSizeId, DateTime effectiveFrom, int topsParametersId);

        string ValidateMinSieveSizeAndMaxSieveSize(int? minSieveSizeId, int? maxSieveSizeId);
    }
}