﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface IAuthenticationService : IService<AppUser>
    {
        #region Methods
        void Login(string loginId, int userId, bool rememberMe = false);
        void Logout();
        #endregion
    }
}
