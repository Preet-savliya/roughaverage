﻿using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface IMenuService : IService<Menu>
    {
        #region Methods
        List<Menu> GetAllMenus(int roleId);
        #endregion
    }
}
