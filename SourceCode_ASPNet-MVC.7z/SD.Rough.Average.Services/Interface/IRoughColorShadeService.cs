﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IRoughColorShadeService : IService<RoughColorShade>
    {
        #region Methods
        string CheckNameIsUnique(string name, int id);
        string CheckColorIsUnique(int? colorId, int id);
        #endregion
    }
}
