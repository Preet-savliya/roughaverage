﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IRoughTypeService : IService<RoughType>
    {
        string CheckNameIsUnique(string name, int id);
    }
}
