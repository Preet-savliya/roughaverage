﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SD.Rough.Average.Services.Interface
{
    public interface IRejectionService : IService<Rejection>
    {
    }
}
