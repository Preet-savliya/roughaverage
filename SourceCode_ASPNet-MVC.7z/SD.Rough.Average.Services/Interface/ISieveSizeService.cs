﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface ISieveSizeService : IService<SieveSize>
    {
        string CheckNameIsUnique(string name, int id);
    }
}
