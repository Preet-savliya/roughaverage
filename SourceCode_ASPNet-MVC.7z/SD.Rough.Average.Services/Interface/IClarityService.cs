﻿namespace SD.Rough.Average.Services.Interface
{
    using System;
    using System.Collections.Generic;
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IClarityService : IService<Clarity>
    {
        IList<Clarity> GetClaritiesAsOn(DateTime asOnDate);
        string CheckNameGroupNameAndEffectiveDateIsUnique(string name, DateTime effectiveFrom, int clarityId);
    }
}
