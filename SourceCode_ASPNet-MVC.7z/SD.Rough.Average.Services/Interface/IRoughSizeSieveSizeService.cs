﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IRoughSizeSieveSizeService : IService<RoughSizeSieveSize>
    {
        #region Method
        string CheckNameAndRoughSizeIsUnique(string name, int roughSizeId, int roughSizeSieveSizeId);

        string ValidateMinSieveSizeAndMaxSieveSize(int? MinSieveSizeId, int? MaxSieveSizeId);
        #endregion
    }
}
