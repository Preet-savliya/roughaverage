﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface IMachineTypeService : IService<MachineType>
    {
        string CheckNameIsUnique(string name, int id);
    }
}
