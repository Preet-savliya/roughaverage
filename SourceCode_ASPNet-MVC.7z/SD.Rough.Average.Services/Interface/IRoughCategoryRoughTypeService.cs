﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IRoughCategoryRoughTypeService : IService<RoughCategoryRoughType>
    {
        #region Method
        string CheckRoughTypeWiseRoughCategoryIsUnique(int roughTypeId, int roughCategoryId, int roughCategoryRoughTypeId);
        string CheckRoughTypeWiseDisplayOrderIsUnique(int roughTypeId,int displayOrder, int roughCategoryRoughTypeId);
        #endregion
    }
}
