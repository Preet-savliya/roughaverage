﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IRoughSizeService : IService<RoughSize>
    {
        string CheckNameIsUnique(string name, int roughSizeId);
        string CheckDisplayNameIsUnique(string displayName, int roughSizeId);
        string CheckDisplayOrderIsUnique(int displayOrder, int roughSizeId);
    }
}
