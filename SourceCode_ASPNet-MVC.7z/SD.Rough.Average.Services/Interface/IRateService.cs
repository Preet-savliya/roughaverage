﻿namespace SD.Rough.Average.Services.Interface
{
    using Models;
    using Abstract;

    public interface IRateService : IService<Rate>
    {
    }
}
