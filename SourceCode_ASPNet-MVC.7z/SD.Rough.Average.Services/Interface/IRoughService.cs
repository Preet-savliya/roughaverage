﻿using System.Collections.Generic;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface IRoughService : IService<Models.Rough>
    {
       
    }
}
