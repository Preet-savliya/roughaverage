﻿using System.Collections.Generic;

using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface ILotStoneTopsParameterService : IService<LotStoneTopsParameter>
    {
        //void AddTopsParameters(IList<LotStoneTopsParameter> topsParameters, int userId);

        void UpdateTopsParameters(IList<LotStoneTopsParameter> dbTopsParameters,
            IList<LotStoneTopsParameter> topsParameters, int userId);

        void DeleteTopsParameters(IList<LotStoneTopsParameter> deletedTopsParameters);
        void DeleteStoneTopsParameters(IList<StoneTopsParameter> deletedStoneTopsParameters);
    }
}
