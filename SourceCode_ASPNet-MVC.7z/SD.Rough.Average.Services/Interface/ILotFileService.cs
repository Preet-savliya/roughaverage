﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface ILotFileService : IService<LotFile>
    {
        #region Methods
        #endregion
    }
}
