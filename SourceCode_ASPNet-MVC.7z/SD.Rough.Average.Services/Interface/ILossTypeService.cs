﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface ILossTypeService : IService<LossType>
    {
        #region Methods
        string CheckCodeIsUnique(string code, int id);
        string CheckTypeIsUnique(string type, int id);
        #endregion
    }
}
