﻿using System.Collections.Generic;
using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;

namespace SD.Rough.Average.Services.Interface
{
    public interface IAppUserService : IService<AppUser>
    {
        #region Methods
        //IEnumerable<AppUser> GetUserInfo(string loginId, string password);
        AppUser GetUserInfo(string loginId);

        int GetUserRoleId(int userId);
        #endregion
    }
}
