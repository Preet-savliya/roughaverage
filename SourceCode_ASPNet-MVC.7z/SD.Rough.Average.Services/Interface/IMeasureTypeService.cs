﻿namespace SD.Rough.Average.Services.Interface
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IMeasureTypeService : IService<MeasureType>
    {
        string CheckCodeIsUnique(string code,int id);
        string CheckNameIsUnique(string name, int id);
    }
}
