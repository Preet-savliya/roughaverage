﻿namespace SD.Rough.Average.Services.Interface
{
    using System;
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Services.Abstract;

    public interface IRoughSizePolishedSieveSizeService : IService<RoughSizePolishedSieveSize>
    {
        #region Method
        string CheckRoughSizeWisePolishedSieveSizeIsUnique(int roughSizeId, int polishedSieveSizeId, DateTime effectiveFrom, int roughSizePolishedSieveSizeId);
        #endregion
    }
}
