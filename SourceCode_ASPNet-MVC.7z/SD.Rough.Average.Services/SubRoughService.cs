﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Services.Shared;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using static SD.Rough.Average.Services.Shared.SubRoughExtensions;

namespace SD.Rough.Average.Services
{
    public class SubRoughService : Service<SubRough>, ISubRoughService
    {
        private IRepository<SubRough> _repository;

        public SubRoughService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<SubRough>();
        }

        IEnumerable<ValidationResult> ISubRoughService.ValidateSubRoughEntry(SubRough subRough, string sieveSizeFileAction)
        {
            List<ValidationResult> errors = new List<ValidationResult>();

            SubRough subRoughEntry = _repository.FirstOrDefault(sr => (sr.RoughTypeId == subRough.RoughTypeId)
                                                        && (sr.RoughColorShadeId == subRough.RoughColorShadeId)
                                                        && (sr.Number == subRough.Number)
                                                        && (sr.RoughSizeId == subRough.RoughSizeId)
                                                        && (sr.PieceCount == subRough.PieceCount)
                                                        && (sr.Weight == subRough.Weight)
                                                        && (sr.Id != subRough.Id));

            if (subRoughEntry != null)
            {
                if (subRoughEntry.IsActive)
                    errors.Add(new ValidationResult("Sub rough entry with same combination of values is already exists"));
                else
                    errors.Add(new ValidationResult("Sub rough entry with same combination of values is already exists but status is deleted"));
            }
            //if (!(subRough.RoughTypeId > 0 || subRough.RoughColorShadeId > 0))
            //    errors.Add(new ValidationResult("Please select either Cut Type or Color Shade"));
            if (subRough.MakeablePieceCount.HasValue && (subRough.MakeableWeight == null ||
                subRough.MakeableMinPolishedDiameter == null || subRough.MakeableTopsPolishedDiameter == null))
            {
                if (subRough.MakeableWeight == null)
                    errors.Add(new ValidationResult("Please enter makeable weight"));
                if (subRough.MakeableMinPolishedDiameter == null)
                    errors.Add(new ValidationResult("Please enter makeable min polished diameter"));
                if (subRough.MakeableTopsPolishedDiameter == null)
                    errors.Add(new ValidationResult("Please enter makeable tops polished diameter"));
            }
            if (subRough.MakeableWeight.HasValue && (subRough.MakeablePieceCount == null
                || subRough.MakeableMinPolishedDiameter == null || subRough.MakeableTopsPolishedDiameter == null))
            {
                if (subRough.MakeablePieceCount == null)
                    errors.Add(new ValidationResult("Please enter makeable piece count"));
                if (subRough.MakeableMinPolishedDiameter == null)
                    errors.Add(new ValidationResult("Please enter makeable min polished diameter"));
                if (subRough.MakeableTopsPolishedDiameter == null)
                    errors.Add(new ValidationResult("Please enter makeable tops polished diameter"));
            }
            if (subRough.MakeableWeight.HasValue)
            {
                if (subRough.MakeableWeight.Value > subRough.Weight)
                    errors.Add(new ValidationResult("Enter makeable weight less than cut weight"));
            }
            if (string.Compare(sieveSizeFileAction, "Other", true) == 0)
            {
                if (!subRough.SieveSizeFileImportId.HasValue)
                    errors.Add(new ValidationResult("Please select Sievesize File"));
            }

            return errors;
        }

        public int GetRoughSubTypeCount(int subRoughId)
        {
            SubRough subRough = _repository.FirstOrDefault(x => x.Id == subRoughId && x.IsActive);
            int roughSubTypecount = 0;

            if (subRough != null)
                roughSubTypecount = subRough.RoughSubTypes(RoughSubTypeBehavior.BehaveSeparately).Count;

            return roughSubTypecount;
        }
    }
}