﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class RoughColorShadeService : Service<RoughColorShade>, IRoughColorShadeService
    {
        #region Fields
        private IRepository<RoughColorShade> _repository;
        #endregion

        #region Ctor
        public RoughColorShadeService(IUnitOfWork unitOfWork, IRepository<RoughColorShade> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckNameIsUnique(string name, int id)
        {
            string roughColorShadeName = name.Trim();

            RoughColorShade roughColorShade = _repository
                .FirstOrDefault(r => (r.Name == roughColorShadeName) && (r.Id != id));

            if (roughColorShade == null)
            {
                return null;
            }

            return roughColorShade.IsActive
                ? $"Rough Color Shade Name - {roughColorShadeName} entry is already exists"
                : $"Rough Color Shade Name - {roughColorShadeName} entry is already exists but status is deleted";
        }

        public string CheckColorIsUnique(int? colorId, int id)
        {
            RoughColorShade roughColorShade = _repository
                .FirstOrDefault(r => (colorId != null && r.Color.Id == colorId) && (r.Id != id));

            if (roughColorShade == null)
            {
                return null;
            }

            return roughColorShade.IsActive
                ? $"Rough Color Shade with same color - {roughColorShade.Color?.Name} entry is already exists"
                : $"Rough Color Shade with same color - {roughColorShade.Color?.Name} entry is already exists but status is deleted";
        }
        #endregion
    }
}
