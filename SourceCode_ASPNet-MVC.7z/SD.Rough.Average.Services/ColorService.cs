﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class ColorService : Service<Color>, IColorService
    {
        #region Fields
        private IRepository<Color> _repository;
        #endregion

        #region Ctor
        public ColorService(IUnitOfWork unitOfWork, IRepository<Color> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckNameIsUnique(string name, int id)
        {
            string colorName = name.Trim();
            Color color = _repository.FirstOrDefault(p => (p.Name == colorName) && (p.Id != id));

            if (color == null)
            {
                return null;
            }
            return color.IsActive
            ? $"Color Name - {colorName} entry is already exists"
            : $"Color Name - {colorName} entry is already exists but status is deleted";
        }
        #endregion
    }
}
