﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Data.UnitOfWork;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Data.Repositories;
using SD.Rough.Average.Services.Interface;

namespace SD.Rough.Average.Services
{
    public class LotFileService : Service<LotFile>, ILotFileService
    {
        private readonly IRepository<LotFile> _repository;

        public LotFileService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<LotFile>();
        }
    }
}
