﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;

    public class PlanningLevelService : Service<PlanningLevel>, IPlanningLevelService
    {
        #region Fields
        private IRepository<PlanningLevel> _repository;
        #endregion

        #region Ctor
        public PlanningLevelService(IUnitOfWork unitOfWork,IRepository<PlanningLevel> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckNameIsUnique(string name,int id)
        {
            string planningLevelName = name.Trim();
            PlanningLevel planningLevel = _repository
                .FirstOrDefault(p => (p.Name == planningLevelName) && (p.Id != id));

            if (planningLevel == null)
            {
                return null;
            }
                return planningLevel.IsActive 
                ? $"Planning Level Name - {planningLevelName} entry is already exists" 
                : $"Planning Level Name - {planningLevelName} entry is already exists but status is deleted";
        }
        #endregion
    }
}