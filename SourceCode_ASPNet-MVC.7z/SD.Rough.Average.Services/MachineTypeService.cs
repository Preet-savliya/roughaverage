﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Interface;

    public class MachineTypeService : Service<MachineType>, IMachineTypeService
    {
        #region Fields
        private IRepository<MachineType> _repository;
        #endregion

        #region Ctor
        public MachineTypeService(IUnitOfWork unitOfWork, IRepository<MachineType> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckNameIsUnique(string name, int id)
        {
            string machineTypeName = name.Trim();

            MachineType machineType = _repository.FirstOrDefault(m => (m.Name == machineTypeName) && (m.Id != id));

            if (machineType == null)
            {
                return null;
            }

            return machineType.IsActive
               ? $"Machine Type Name - {machineTypeName} entry is already exists"
               : $"Machine Type Name - {machineTypeName} entry is already exists but status is deleted";
        }
        #endregion
    }
}
