﻿namespace SD.Rough.Average.Services
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Abstract;
    using Data.Repositories;
    using Data.UnitOfWork;
    using Interface;
    using Models;

    public class DiameterSieveService : Service<DiameterSieveSize>, IDiameterSieveService
    {
        private IRepository<DiameterSieveSize> _repository;

        public DiameterSieveService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<DiameterSieveSize>();
        }

        public decimal? GetDiameterBySize(int sieveSizeId, DateTime asOnDate)
        {
            DiameterSieveSize diameterEntry = _repository
                .Get(x => x.SieveSizeId == sieveSizeId && x.EffectiveFrom <= asOnDate)
                .OrderByDescending(x => x.EffectiveFrom)
                .FirstOrDefault();

            return (diameterEntry != null && diameterEntry.IsActive) ? (decimal?)diameterEntry.Diameter : null;
        }

        public IList<DiameterSieveSize> GetDiametersAsOn(DateTime asOnDate)
        {
            var diameterSieveSizes = new List<DiameterSieveSize>();
            diameterSieveSizes = _repository
                .Get(x => x.EffectiveFrom <= asOnDate)
                .GroupBy(x => x.SieveSizeId)
                .Select((IGrouping<int, DiameterSieveSize> grp) => new
                {
                    grp.Key,
                    Diameter = grp.OrderByDescending(a => a.EffectiveFrom).FirstOrDefault()
                })
                .Where(x => x.Diameter.IsActive)
                .Select(x => x.Diameter)
                .ToList();

            return diameterSieveSizes;
        }

        public string CheckDiameterIsUnique(decimal minDiameter, int sieveSizeFileImportId, int id)
        {
            DiameterSieveSize diameterSieveSize = _repository
                .FirstOrDefault(p => p.Diameter == minDiameter && p.SieveSizeFileImportId == sieveSizeFileImportId && p.Id != id);

            if (diameterSieveSize == null)
            {
                return null;
            }

            return $"Diameter Sieve Size with same diameter - {minDiameter} entry is already exists";
        }

        public string ValidateMinDiameterAndMinDiameterUpTo(decimal minDiameter, decimal? minDiameterUpTo)
        {
            if (minDiameterUpTo.HasValue && minDiameter <= minDiameterUpTo)
            {
                return "Min Diameter must be grater than the min diameter up to";
            }

            return null;
        }
    }
}
