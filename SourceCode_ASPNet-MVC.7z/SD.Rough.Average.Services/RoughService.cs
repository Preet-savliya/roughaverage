﻿using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using System.Collections.Generic;
using SD.Rough.Average.Data.UnitOfWork;

namespace SD.Rough.Average.Services
{
    public class RoughService : Service<Models.Rough>, IRoughService
    {
        #region Ctor
        public RoughService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
        #endregion
    }
}
