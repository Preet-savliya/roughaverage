﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using System.Collections.Generic;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Services.Interface;
    using System.ComponentModel.DataAnnotations;

    public class EmployeeService : Service<Employee>, IEmployeeService
    {
        #region Fields
        private IRepository<Employee> _repository;
        #endregion

        #region Ctor
        public EmployeeService(IUnitOfWork unitOfWork,
            IRepository<Employee> repository) : base(unitOfWork)
        {
            _repository = unitOfWork.Repository<Employee>();
        }
        #endregion

        #region Methods
        public IEnumerable<ValidationResult> ValidateEmployeeNoUniqueness(Employee employee)
        {
            List<ValidationResult> errors = new List<ValidationResult>();

            if (string.IsNullOrEmpty(employee.EmployeeNo))
            {
                return errors;
            }

            Employee employeeEntry = _repository.FirstOrDefault(m => (m.EmployeeNo == employee.EmployeeNo)
                                                        && (m.Id != employee.Id));

            if (employeeEntry != null)
            {
                if (employeeEntry.IsActive)
                {
                    errors.Add(new ValidationResult($"Employee Number - {employee.EmployeeNo} entry is already exists"));
                }
                else
                {
                    errors.Add(new ValidationResult($"Employee Number - {employee.EmployeeNo} entry is already exists but status is deleted"));
                }
            }

            return errors;
        }
        #endregion
    }
}
