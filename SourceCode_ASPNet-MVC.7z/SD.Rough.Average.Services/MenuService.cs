﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using System.Collections.Generic;
using System.Linq;
using SD.Rough.Average.Data.UnitOfWork;

namespace SD.Rough.Average.Services
{
    public class MenuService : Service<Menu>, IMenuService
    {
        #region Private Fields
        private IRoleMenuService _roleMenuService;
        #endregion

        #region Ctor
        public MenuService(IUnitOfWork unitOfWork,
            IRoleMenuService roleMenuService) : base(unitOfWork)
        {
            _roleMenuService = roleMenuService;
        }
        #endregion

        #region Methods
        public List<Menu> GetAllMenus(int roleId)
        {
            var roleMenu = _roleMenuService.GetAllRoleMenuByID(roleId).Where(m => m.IsActive).ToList();
            var menus = GetAll().Where(m => m.IsActive).ToList();
            List<Menu> menuList = new List<Menu>();

            menuList = (from menu in menus
                        join rolemenu in roleMenu
                        on menu.Id equals rolemenu.MenuId
                        orderby menu.DisplayOrder
                        select menu).ToList();

            return menuList;
        }
        #endregion
    }
}
