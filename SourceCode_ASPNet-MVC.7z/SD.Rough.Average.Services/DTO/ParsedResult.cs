﻿using System.Collections.Generic;

using SD.Rough.Average.Core;

namespace SD.Rough.Average.Services.DTO
{
    //public abstract class ParsedAttribute
    //{
    //    public string FileValue { get; set; }
    //}

    //public class ParseError
    //{
    //    public string FileValue { get; set; }
    //    public string Message { get; set; }
    //    //public IList<string> Errors { get; set; }
    //}

    public class ParsedResult<T>
    {
        public string FileValue { get; set; }

        public T ParsedValue { get; set; }

        //public string Error { get; set; }
        public List<string> Errors { get; set; } = new List<string>();

        public bool IsValid
            => Errors is null || Errors.Count == 0;
        //=> string.IsNullOrEmpty(Error) && (Errors is null || Errors.Count == 0);
    }

    public static class ParsedResultExtensions
    {
        public static ParsedResult<T> ToParsedResult<T>(this Result<T> result, string fileValue)
        {
            var parsedResult = new ParsedResult<T>
            {
                FileValue = fileValue
            };

            if (result.IsSuccess)
            {
                parsedResult.ParsedValue = result.Value;
            }
            else
            {
                parsedResult.Errors.Add(result.Error);
            }
            return parsedResult;
        }
    }
}