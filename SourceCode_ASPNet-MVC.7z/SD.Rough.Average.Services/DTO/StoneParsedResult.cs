﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace SD.Rough.Average.Services.DTO
{
    public class OperatorDTO
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public class StoneNumberDTO
    {
        public bool IsM2 { get; set; }
        public string StoneNumber { get; set; }
        public int NumericalStoneNumber { get; set; }
    }

    public class MachineNumberDTO
    {
        public int Id { get; set; }
        public int MachineNumber { get; set; }
    }

    public class MeasureTypeDTO
    {
        public int Id { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
    }

    public class PlanningLevelDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class StoneDTO
    {
        public string FileName { get; set; }

        public bool HasMisMatchInPartsCount { get; set; } = false;

        public ParsedResult<DateTime> MeasureDate { get; set; }
        public ParsedResult<TimeSpan> MeasureTime { get; set; }

        public ParsedResult<OperatorDTO> Operator { get; set; }
        public ParsedResult<StoneNumberDTO> StoneNumber { get; set; }
        public ParsedResult<MachineNumberDTO> MachineNumber { get; set; }
        public ParsedResult<MeasureTypeDTO> MeasureType { get; set; }
        public ParsedResult<PlanningLevelDTO> PlanningLevel { get; set; }

        public ParsedResult<decimal> RoughWeight { get; set; }

        public IList<PolishStoneDTO> PolishStones { get; set; }

        public List<string> Errors { get; set; } = new List<string>();
        public bool HasError
            => (Errors != null && Errors.Count > 0) || PolishStones.Any(ps => ps.HasError);

        public List<string> CollectErrors()
        {
            var errors = new List<string>();

            if(MeasureDate.Errors?.Count > 0)
                errors.AddRange(MeasureDate.Errors);

            if(MeasureTime.Errors?.Count > 0)
                errors.AddRange(MeasureTime.Errors);
            
            if(Operator.Errors?.Count > 0)
                errors.AddRange(Operator.Errors);
            
            if(StoneNumber.Errors?.Count > 0)
                errors.AddRange(StoneNumber.Errors);
            
            if(MachineNumber.Errors?.Count > 0)
                errors.AddRange(MachineNumber.Errors);
            
            if(MeasureType.Errors?.Count > 0)
                errors.AddRange(MeasureType.Errors);
            
            if(PlanningLevel.Errors?.Count > 0)
                errors.AddRange(PlanningLevel.Errors);
            
            if(RoughWeight.Errors?.Count > 0)
                errors.AddRange(RoughWeight.Errors);

            return errors;
        }
    }
}
