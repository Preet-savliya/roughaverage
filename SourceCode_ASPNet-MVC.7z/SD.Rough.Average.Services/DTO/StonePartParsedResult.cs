﻿using System.Collections.Generic;

using SD.Rough.Average.Models;

namespace SD.Rough.Average.Services.DTO
{
    public class ColorDTO
    {
        public int Id { get; set; }
        public int ColorId { get; set; }
        public string Name { get; set; }
    }

    public class ClarityDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

    public class ShapeDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public decimal Diameter { get; set; }
        public decimal Length { get; set; }

        public MeasurementParameters MeasurementBy { get; set; }
        public decimal MeasurementValue
        {
            get
            {
                if (MeasurementBy == MeasurementParameters.Diameter)
                    return Diameter;

                if (MeasurementBy == MeasurementParameters.Length)
                    return Length;

                return 0.0M;
            }
        }
    }

    public class RateDTO
    {
        public decimal OldRate { get; set; }
        public decimal OldMeasurementValue { get; set; }

        public decimal Rate { get; set; }
        public decimal MeasurementValue { get; set; }
    }

    public class SieveSizeDTO
    {
        public int? MinSieveSizeId { get; set; }
        public int? MaxSieveSizeId { get; set; }

        public string Name { get; set; }
    }

    public class PolishStoneDTO
    {
        public ParsedResult<decimal> PartWeight { get; set; }
        public ParsedResult<decimal> ResultPartWeight { get; set; }
        public ParsedResult<decimal> PolishWeight { get; set; }

        public ParsedResult<ColorDTO> Color { get; set; }
        public ParsedResult<ClarityDTO> Clarity { get; set; }
        public ParsedResult<ShapeDTO> Shape { get; set; }
        public ParsedResult<decimal> MeasurementValue { get; set; }

        public ParsedResult<RateDTO> Rate { get; set; }
        public ParsedResult<SieveSizeDTO> SieveSize { get; set; }

        public List<string> Errors { get; set; }
        public bool HasError => Errors != null && Errors.Count > 0;

        public bool IsValid => Errors == null || Errors.Count == 0; // !HasError;

        public List<string> CollectErrors()
        {
            var errors = new List<string>();
            
            if(PartWeight != null && PartWeight.Errors.Count > 0)
                errors.AddRange(PartWeight.Errors);

            if(ResultPartWeight != null && ResultPartWeight.Errors.Count > 0)
                errors.AddRange(ResultPartWeight.Errors);

            if(PolishWeight != null && PolishWeight.Errors.Count > 0)
                errors.AddRange(PolishWeight.Errors);

            if(Color != null && Color.Errors.Count > 0)
                errors.AddRange(Color.Errors);
            
            if(Clarity != null && Clarity.Errors.Count > 0)
                errors.AddRange(Clarity.Errors);
            
            if(Shape != null && Shape.Errors.Count > 0)
                errors.AddRange(Shape.Errors);

            if(Rate != null && Rate.Errors.Count > 0)
                errors.AddRange(Rate.Errors);

            if(SieveSize != null && SieveSize.Errors.Count > 0)
                errors.AddRange(SieveSize.Errors);

            return errors;
        }
    }
}
