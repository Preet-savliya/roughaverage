﻿namespace SD.Rough.Average.Services
{
    using SD.Rough.Average.Models;
    using SD.Rough.Average.Data.UnitOfWork;
    using SD.Rough.Average.Services.Abstract;
    using SD.Rough.Average.Data.Repositories;
    using SD.Rough.Average.Services.Interface;

    public class RoughCategoryService : Service<RoughCategory>, IRoughCategoryService
    {
        #region Fields
        private IRepository<RoughCategory> _repository;
        #endregion

        #region Ctor
        public RoughCategoryService(IUnitOfWork unitOfWork,IRepository<RoughCategory> repository) : base(unitOfWork)
        {
            _repository = repository;
        }
        #endregion

        #region Method
        public string CheckNameIsUnique(string name, int id)
        {
            string roughCategoryName = name.Trim();

            RoughCategory roughCategory = _repository.FirstOrDefault(p => (p.Name == roughCategoryName) && (p.Id != id));

            if (roughCategory == null)
            {
                return null;
            }

            return roughCategory.IsActive
            ? $"Rough Category Name - {roughCategoryName} entry is already exists"
            : $"Rough Category Name - {roughCategoryName} entry is already exists but status is deleted";
        }
        #endregion
    }
}
