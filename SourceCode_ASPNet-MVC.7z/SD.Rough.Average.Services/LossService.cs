﻿using SD.Rough.Average.Models;
using SD.Rough.Average.Services.Abstract;
using SD.Rough.Average.Services.Interface;
using SD.Rough.Average.Data.UnitOfWork;

namespace SD.Rough.Average.Services
{
    public class LossService : Service<Loss>, ILossService
    {
        public LossService(IUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }
    }
}
