﻿namespace SD.Rough.Average.Models
{
    public class SieveSize : BaseEntity
    {
        public string Name { get; set; }
    }

    public class SieveSizeName
    {
        public int? MinSieveSizeId { get; set; }
        public string MinSieveSize { get; set; }

        public int? MaxSieveSizeId { get; set; }
        public string MaxSieveSize { get; set; }
    }
}
