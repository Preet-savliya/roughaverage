﻿namespace SD.Rough.Average.Models
{
    public enum SarinActivityType
    {
        RoughPlanning,
        MakeablePlanning
    }

    public class SarinActivity : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }

        public static SarinActivityType GetSarinActivity(string sarinActivityName)
        {
            if (string.Compare(sarinActivityName.Trim(), "Rough", true) == 0
                || string.Compare(sarinActivityName.Trim(), "Rough Planning", true) == 0)
            {
                return SarinActivityType.RoughPlanning;
            }
            else
            {
                return SarinActivityType.MakeablePlanning;
            }
        }
    }
}
