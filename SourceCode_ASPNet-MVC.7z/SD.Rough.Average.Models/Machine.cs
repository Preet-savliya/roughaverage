﻿using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Models
{
    [MetadataType(typeof(MachineMetadata))]
    public class Machine : BaseEntity
    {
        #region Properties
        public int Number { get; set; }
        public int MachineTypeId{ get; set; }
        
        //Navigation Properties
        public virtual MachineType MachineType { get; set; }
        #endregion
    }

    internal sealed class MachineMetadata
    {
        #region Properties
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Number")]
        public int Number { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Machine Type")]
        public int MachineTypeId { get; set; }
        #endregion
    }
}
