﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class LotFile : BaseEntity
    {
        public LotFile()
        {
            Stones = new HashSet<Stone>();
        }

        public int LotId { get; set; }
        public string FileName { get; set; }

        // Navigation Properties
        public virtual Lot Lot { get; set; }
        public virtual ICollection<Stone> Stones { get; set; }
    }
}
