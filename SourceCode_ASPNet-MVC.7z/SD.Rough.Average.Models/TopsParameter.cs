﻿using System;

namespace SD.Rough.Average.Models
{
    public class TopsParameter : BaseEntity
    {
        public string Name
        {
            get
            {
                var minSizeName = MinSieveSizeId.HasValue ? MinSieveSize.Name : "0";
                var maxSizeName = MaxSieveSizeId.HasValue ? MaxSieveSize.Name : "25";

                return $"+{minSizeName} -{maxSizeName}";

                // NOTE: Do not delete below code as it will be used after Temporal implementation
                //if (MinSieveSizeId.HasValue && MaxSieveSizeId.HasValue)
                //{
                //    return $"+{MinSieveSize.Name} -{MaxSieveSize.Name}";
                //}
                //else if (MinSieveSizeId.HasValue)
                //{
                //    return $"+{MinSieveSize.Name}";
                //}
                //else if (MaxSieveSizeId.HasValue)
                //{
                //    return $"-{MaxSieveSize.Name}";
                //}
                //else
                //{
                //    return "-";
                //}
            }
        }

        public int? MinSieveSizeId { get; set; }
        public int? MaxSieveSizeId { get; set; }

        //public int ClarityId { get; set; }
        //public int ColorId { get; set; }

        public DateTime EffectiveFrom { get; set; }

        public virtual SieveSize MinSieveSize { get; set; }
        public virtual SieveSize MaxSieveSize { get; set; }

        //public virtual Clarity Clarity { get; set; }
        //public virtual Color Color { get; set; }
    }

    public class TopsParameterTemporal : BaseEntity
    {
        public int TopsParameterId { get; set; }

        public int? MinSieveSizeId { get; set; }
        public int? MaxSieveSizeId { get; set; }

        //public int ClarityId { get; set; }
        //public int ColorId { get; set; }

        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
    }
}
