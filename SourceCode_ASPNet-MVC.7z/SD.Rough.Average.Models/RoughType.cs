﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class RoughType : BaseEntity
    {
        public RoughType()
        {
            RoughCategoryRoughTypes = new HashSet<RoughCategoryRoughType>();
        }

        public string Name { get; set; }
        public string Description { get; set; }

        public virtual ICollection<RoughCategoryRoughType> RoughCategoryRoughTypes { get; set; }

    }
}
