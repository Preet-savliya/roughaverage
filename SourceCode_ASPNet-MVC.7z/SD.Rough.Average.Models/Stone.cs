﻿using System;
using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class Stone : BaseEntity
    {
        public Stone()
        {
            PolishedStones = new HashSet<PolishedStone>();
            Topses = new HashSet<Tops>();
        }

        public DateTime? StoneDate { get; set; } = null;
        public TimeSpan? StoneTime { get; set; } = null;
        
        public string StoneNumber { get; set; }
        public bool IsM2Stone { get; set; } = false;

        public decimal Weight { get; set; }
        
        public int LotId { get; set; }
        public int? LotFileId { get; set; }
        public int OpertorId { get; set; }
        public int MachineId { get; set; }
        public int MeasureTypeId { get; set; }
        public int PlanningLevelId { get; set; }

        // Ignored Properties
        public string FileName { get; set; }
        public bool IsExist { get; set; }
        public bool IsInsertUpdateSuccess { get; set; }
        public bool IsDelete { get; set; }
        public bool IsValid { get; set; }
        public string Comment { get; set; }
        public int StoneNumberNumeric { get; set; }

        //Navigation Properties
        public virtual Lot Lot { get; set; }
        public virtual LotFile LotFile { get; set; }
        public virtual Employee Operator { get; set; }
        public virtual Machine Machine { get; set; }
        public virtual MeasureType MeasureType { get; set; }
        public virtual PlanningLevel PlanningLevel { get; set; }
        public virtual ICollection<PolishedStone> PolishedStones { get; set; }
        public virtual ICollection<Tops> Topses { get; set; }
    }
}
