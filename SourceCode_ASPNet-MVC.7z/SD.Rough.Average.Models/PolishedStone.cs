﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class PolishedStone : BaseEntity
    {
        public decimal PartWeight { get; set; }
        public decimal PolishedWeight { get; set; }
        public decimal Rate { get; set; }
        public decimal? OldRate { get; set; }
        public decimal Diameter { get; set; }
        public decimal Length { get; set; }
        public decimal MeasureByValue { get; set; }
        public decimal? OldMeasureByValue { get; set; }
        public int? MinSieveSizeId { get; set; }
        public int? MaxSieveSizeId { get; set; }
        public string SieveSize { get; set; }
        public int StoneId { get; set; }
        public int? ColorRateVersionId { get; set; }
        public int? ClarityId { get; set; }
        public int? ShapeId { get; set; }

        //Ignored Properties
        public bool IsValid { get; set; }
        public string Comment { get; set; }

        // Navigation Properties
        public virtual Stone Stone { get; set; }
        public virtual ColorRateVersion ColorRateVersion { get; set; }
        public virtual Clarity Clarity { get; set; }
        public virtual Shape Shape { get; set; }
        public virtual SieveSize MinSieveSize { get; set; }
        public virtual SieveSize MaxSieveSize { get; set; }
    }
}
