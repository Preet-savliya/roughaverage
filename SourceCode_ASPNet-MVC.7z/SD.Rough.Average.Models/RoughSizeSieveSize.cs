﻿namespace SD.Rough.Average.Models
{
    public class RoughSizeSieveSize : BaseEntity
    {
        #region Properties
        public string Name { get; set; }
        public int RoughSizeId { get; set; }
        public int? MinSieveSizeId { get; set; }
        public int? MaxSieveSizeId { get; set; }
        public int DisplayOrder { get; set; }

        //Navigation Properties
        public virtual RoughSize RoughSize{ get; set; }
        public virtual SieveSize MinSieveSize { get; set; }
        public virtual SieveSize MaxSieveSize { get; set; }
        #endregion
    }
}
