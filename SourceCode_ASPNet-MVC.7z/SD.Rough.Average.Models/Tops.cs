﻿namespace SD.Rough.Average.Models
{
    public class Tops : BaseEntity
    {
        public int StoneId { get; set; }
        public decimal PartWeight { get; set; }

        //Ignored Properties
        public bool IsValid { get; set; }
        public string Comment { get; set; }

        // Navigation Properties
        public virtual Stone Stone { get; set; }
    }
}
