﻿namespace SD.Rough.Average.Models
{
    public class RoughColorShade : BaseEntity
    {
        public string Name { get; set; }
        public string LotColorGroupName { get; set; }
        public int? LotColorDisplayOrder { get; set; }
        public string Description { get; set; }

        public int? ColorId { get; set; }

        public virtual Color Color { get; set; }
    }
}
