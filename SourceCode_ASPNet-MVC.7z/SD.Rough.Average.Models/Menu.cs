﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class Menu : BaseEntity
    {
        public Menu()
        {
            Menus = new HashSet<Menu>();
        }

        public string Name { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }
        public int? ParentId { get; set; }
        public int DisplayOrder { get; set; }

        //Ignore Property
        public bool IsSelected { get; set; } = false;
        //public int? SelectedChildMenu { get; set; }

        public virtual ICollection<Menu> Menus { get; set; }
        public virtual Menu ParentMenu { get; set; }
    }
}
