﻿namespace SD.Rough.Average.Models
{
    public class Rate : BaseEntity
    {
        public decimal Diameter { get; set; }
        public decimal UnitPrice { get; set; }

        public int ColorRateVersionId { get; set; }
        public int ShapeId { get; set; }
        public int ClarityId { get; set; }

        // Navigation-Properties
        public virtual ColorRateVersion ColorRateVersion { get; set; }
        public virtual Shape Shape { get; set; }
        public virtual Clarity Clarity { get; set; }
    }
}
