﻿namespace SD.Rough.Average.Models
{
    public class Rough : BaseEntity
    {
        #region Properties
        public decimal? Weight { get; set; }
        public int? PieceCount { get; set; }
        public string Description { get; set; }
        public int RoughTypeId { get; set; }

        //Navigation Properties
        public virtual RoughType RoughType { get; set; }
        #endregion
    }
}
