﻿using System;

namespace SD.Rough.Average.Models
{
    public abstract class BaseEntity
    {
        public int Id { get; set; }

        public bool IsActive { get; set; } = true;
        
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.Now;
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }

        // Navigation Properties
        public virtual AppUser CreatedByUser { get; set; }
        public virtual AppUser ModifiedByUser { get; set; }
    }
}
