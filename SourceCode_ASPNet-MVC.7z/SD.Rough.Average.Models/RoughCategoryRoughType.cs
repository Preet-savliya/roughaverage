﻿namespace SD.Rough.Average.Models
{
    public class RoughCategoryRoughType : BaseEntity
    {
        public int RoughTypeId { get; set; }
        public int RoughCategoryId { get; set; }
        public bool? IsBehaveSeparately { get; set; }
        public int DisplayOrder { get; set; }

        // Navigation Property
        public virtual RoughType RoughType { get; set; }
        public virtual RoughCategory RoughCategory { get; set; }
    }
}
