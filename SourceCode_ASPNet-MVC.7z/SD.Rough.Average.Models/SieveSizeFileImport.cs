﻿using System;
using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class SieveSizeFileImport : BaseEntity
    {
        public SieveSizeFileImport()
        {
            DiameterSieveSizes = new HashSet<DiameterSieveSize>();
        }

        public string Name { get; set; }
        public DateTime EffectiveFrom { get; set; }

        public virtual ICollection<DiameterSieveSize> DiameterSieveSizes { get; set; }
        public virtual ICollection<SubRough> SubRoughs { get; set; }
    }
}
