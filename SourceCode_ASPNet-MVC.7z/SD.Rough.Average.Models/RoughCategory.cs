﻿namespace SD.Rough.Average.Models
{
    public class RoughCategory : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
