﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class Color : BaseEntity
    {
        public string Name { get; set; }
        public string Description { get; set; }

        public virtual ICollection<ColorRateVersion> ColorRateVersions { get; set; }
    }
}
