﻿using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Models
{
    [MetadataType(typeof(EmployeeMetadata))]
    public class Employee : BaseEntity
    {
        #region Properties
        public string EmployeeNo { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int DesignationId { get; set; }

        // Navigation Properties
        public virtual Designation Designation { get; set; }
        #endregion
    }

    internal sealed class EmployeeMetadata
    {
        #region Properties
        [Display(Name = "Employee NO")]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [RegularExpression(AlphaNumericRegEx, ErrorMessage = InValidErrorMessage)]
        public string EmployeeNo { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Designation")]
        public int DesignationId { get; set; }
        #endregion
    }
}
