﻿using System;
using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class PolishedSieveSize : BaseEntity
    {
        public PolishedSieveSize()
        {
            ChildPolishedSieveSizes = new HashSet<PolishedSieveSize>();
        }

        public string Name { get; set; }

        public int? MinSieveSizeId { get; set; }
        public int? MaxSieveSizeId { get; set; }


        public int? ParentId { get; set; }

        public bool IsPointerApply { get; set; } = false;

        public DateTime EffectiveFrom { get; set; }

        public decimal? MinDiameter { get; set; }
        public decimal? MaxDiameter { get; set; }

        public virtual SieveSize MinSieveSize { get; set; }
        public virtual SieveSize MaxSieveSize { get; set; }

        public virtual PolishedSieveSize ParentPolishedSieveSize { get; set; }
        public virtual ICollection<PolishedSieveSize> ChildPolishedSieveSizes { get; set; }

        public virtual ICollection<RoughSizePolishedSieveSize> RoughSizePolishedSieveSizes { get; set; }
    }

    public class PolishedSieveSizeTemporal : BaseEntity
    {
        public string Name { get; set; }

        public int? MinSieveSizeId { get; set; }
        public int? MaxSieveSizeId { get; set; }

        public int? ParentId { get; set; }

        public bool IsPointerApply { get; set; } = false;

        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }
    }
}
