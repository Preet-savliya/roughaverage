﻿using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Models
{
    [MetadataType(typeof(RejectionMetadata))]
    public class Rejection : BaseEntity
    {
        #region Properties
        public int SubRoughId { get; set; }
        public int SarinActivityId { get; set; }
        public int? PieceCount { get; set; }
        public decimal? Weight { get; set; }

        public virtual SubRough SubRough { get; set; }
        public virtual SarinActivity SarinActivity { get; set; }
        #endregion
    }

    internal sealed class RejectionMetadata
    {
        #region Properties
        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), DefaultValue, WeightMaxValue, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Display(Name = "Weight")]
        public decimal? Weight { get; set; }

        [Range(IntDefaultValue, PieceMaxValue, ErrorMessage = NumberDefaultErrorMessage)]
        [RegularExpression(DigitOneToMaxFourDigitRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Display(Name = "Piece(s)")]
        public int? PieceCount { get; set; }

        #endregion
    }
}
