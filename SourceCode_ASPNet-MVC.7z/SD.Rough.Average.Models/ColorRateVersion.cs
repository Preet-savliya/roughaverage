﻿using System;

namespace SD.Rough.Average.Models
{
    public class ColorRateVersion : BaseEntity
    {
        public string Name { get; set; }
        public DateTime EffectiveFrom { get; set; }

        public int ColorId { get; set; }

        // Navigation-Properties
        public virtual Color Color { get; set; }
    }
}
