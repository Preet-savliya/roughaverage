﻿using System;

namespace SD.Rough.Average.Models
{
    public class AppUser : BaseEntity
    {
        #region Properties
        public int EmployeeId { get; set; }
        public string LoginId { get; set; }
        public string Password { get; set; }
        public int RoleId { get; set; }
        public bool LoginStatus { get; set; } = false;
        public DateTime? LastLoginOn { get; set; }

        // Navigation Properties
        public virtual Role Role { get; set; }
        public virtual Employee Employee { get; set; }
        #endregion
    }
}
