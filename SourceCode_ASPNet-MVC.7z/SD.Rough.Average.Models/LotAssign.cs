﻿using System;

namespace SD.Rough.Average.Models
{
    public class LotAssign : BaseEntity
    {
        public int LotId { get; set; }
        public int AssignedTo { get; set; }
        public DateTime? AssignedOn { get; set; }

        // Navigation Property
        public virtual Lot Lot { get; set; }
        public virtual Employee Assigning { get; set; }
    }
}
