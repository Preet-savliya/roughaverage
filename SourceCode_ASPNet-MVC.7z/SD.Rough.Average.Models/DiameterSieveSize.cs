﻿using System;

namespace SD.Rough.Average.Models
{
    public class DiameterSieveSize : BaseEntity
    {
        public decimal Diameter { get; set; }
        public decimal? DiameterUpTo { get; set; }

        public int SieveSizeId { get; set; }
        public int? SieveSizeFileImportId { get; set; }

        public DateTime EffectiveFrom { get; set; }

        public virtual SieveSize SieveSize { get; set; }
        public virtual SieveSizeFileImport SieveSizeFileImport { get; set; }
    }
}
