﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class Role : BaseEntity
    {
        #region Ctor
        public Role()
        {
            RoleMenus = new HashSet<RoleMenu>();
        }
        #endregion

        #region Properties
        public string Name { get; set; }
        public string Description { get; set; }

        // Navigation Properties
        public virtual ICollection<RoleMenu> RoleMenus { get; set; }
        #endregion
    }
}
