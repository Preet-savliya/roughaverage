﻿namespace SD.Rough.Average.Models
{
    using System;

    public class RoughSizePolishedSieveSize : BaseEntity
    {
        #region Properties
        public int RoughSizeId { get; set; }
        public int PolishedSieveSizeId { get; set; }
        public DateTime EffectiveFrom { get; set; }

        //Navigation Properties
        public virtual RoughSize RoughSize { get; set; }
        public virtual PolishedSieveSize PolishedSieveSize { get; set; }
        #endregion
    }
}
