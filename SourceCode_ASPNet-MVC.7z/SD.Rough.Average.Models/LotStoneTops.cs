﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class LotStoneTopsParameter: BaseEntity
    {
        public LotStoneTopsParameter()
        {
            StoneTopsParameters = new HashSet<StoneTopsParameter>();
        }

        public int LotId { get; set; }
        public virtual Lot Lot { get; set; }

        public int StoneNumberFrom { get; set; }
        public int StoneNumberTo { get; set; }        

        public virtual ICollection<StoneTopsParameter> StoneTopsParameters { get; set; }
    }

    public class StoneTopsParameter: BaseEntity
    {
        public int LotStoneTopsParameterId { get; set; }
        public virtual LotStoneTopsParameter LotStoneTopsParameter { get; set; }

        public int ClarityId { get; set; }
        public virtual Clarity Clarity { get; set; }

        public decimal TopsDiameter { get; set; }
    }
}
