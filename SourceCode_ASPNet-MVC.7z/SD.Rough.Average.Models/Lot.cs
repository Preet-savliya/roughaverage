﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class Lot : BaseEntity
    {
        public Lot()
        {
            Stones = new HashSet<Stone>();
            LotFiles = new HashSet<LotFile>();
            LotStoneTopsParameters = new HashSet<LotStoneTopsParameter>();
        }

        public decimal? Weight { get; set; }
        public int? PieceCount { get; set; }

        public int SubRoughId { get; set; }
        public string SizeSign { get; set; }
        public int? SieveSizeId { get; set; }
        public int SarinActivityId { get; set; }
        public bool? IsTopsLot { get; set; }

        public int? ClarityId { get; set; }
        public int? RoughCategoryId { get; set; }
        public int? ColorShadeId { get; set; }
        public int? ColorRateVersionId { get; set; }
        public string Description { get; set; }

        //Ignore properties
        public bool IsValidTops { get; set; } = true;

        public virtual SubRough SubRough { get; set; }
        public virtual Clarity Clarity { get; set; }
        public virtual SarinActivity SarinActivity { get; set; }
        public virtual SieveSize SieveSize { get; set; }
        public virtual RoughCategory RoughCategory { get; set; }
        public virtual RoughColorShade RoughColorshade { get; set; }
        public virtual ColorRateVersion ColorRateVersion { get; set; }
        public virtual ICollection<Stone> Stones { get; set; }
        public virtual ICollection<LotFile> LotFiles { get; set; }
        public virtual ICollection<LotAssign> LotAssigns { get; set; }

        public virtual ICollection<LotStoneTopsParameter> LotStoneTopsParameters { get; set; }
    }
}
