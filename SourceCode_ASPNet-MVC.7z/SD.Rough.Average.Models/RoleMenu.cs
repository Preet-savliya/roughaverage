﻿namespace SD.Rough.Average.Models
{
    public class RoleMenu : BaseEntity
    {
        #region Properties
        public int RoleId { get; set; }
        public int MenuId { get; set; }

        //Navigation Properties
        public virtual Role Roles { get; set; }
        public virtual Menu Menus { get; set; }
        #endregion
    }
}
