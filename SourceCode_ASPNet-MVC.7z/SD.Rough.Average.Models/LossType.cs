﻿namespace SD.Rough.Average.Models
{
    public class LossType : BaseEntity
    {
        #region Properties
        public string Type { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
        #endregion
    }
}
