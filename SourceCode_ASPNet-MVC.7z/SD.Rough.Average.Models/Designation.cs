﻿using System.Collections.Generic;

namespace SD.Rough.Average.Models
{
    public class Designation : BaseEntity
    {
        #region Properties
        public string Name { get; set; }

        // Navigation Properties
        public virtual ICollection<Employee> Employees { get; set; }
        #endregion
    }
}
