﻿namespace SD.Rough.Average.Models
{
    public class MachineType : BaseEntity
    {
        #region Properties
        public string Name { get; set; }
        public string Description { get; set; }
        #endregion
    }
}
