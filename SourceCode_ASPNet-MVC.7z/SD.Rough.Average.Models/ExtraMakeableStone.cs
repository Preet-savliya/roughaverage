﻿namespace SD.Rough.Average.Models
{
    public class ExtraMakeableStone : BaseEntity
    {
        #region Properties
        public int StoneNumber { get; set; }
        public int LotId { get; set; }

        // Navigation Properties
        public virtual Lot Lot { get; set; }
        #endregion
    }
}
