﻿using System;
using System.Text;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using static SD.Rough.Average.Core.AppGlobalSettings;
using static SD.Rough.Average.Core.Validation.ValidationGlobalSettings;

namespace SD.Rough.Average.Models
{
    [MetadataType(typeof(SubRoughMetadata))]
    public class SubRough : BaseEntity
    {
        public SubRough()
        {
            Lots = new HashSet<Lot>();
            Losses = new HashSet<Loss>();
            Rejections = new HashSet<Rejection>();
        }

        public int RoughTypeId { get; set; }
        public int? RoughColorShadeId { get; set; }
        public int? Number { get; set; }
        public decimal? Weight { get; set; }
        public int? PieceCount { get; set; }

        public decimal? MakeableWeight { get; set; }
        public int? MakeablePieceCount { get; set; }

        public int? MakeableTopsPieces { get; set; }
        public decimal? MakeableTopsWeight { get; set; }

        public int? RoughSizeId { get; set; }
        public int EmployeeId { get; set; }

        public DateTime AssignedOn { get; set; }
        public DateTime? MakeableEntryDate { get; set; }
        public DateTime? MakeableTopsEntryDate { get; set; }

        public decimal? RoughMinPolishedDiameter { get; set; }
        public decimal? RoughTopsPolishedDiameter { get; set; }

        public decimal? MakeableMinPolishedDiameter { get; set; }
        public decimal? MakeableTopsPolishedDiameter { get; set; }

        public int? SieveSizeFileImportId { get; set; }
        public bool IsLotBySize { get; set; }
        public string Description { get; set; }

        //Ignored Properties
        public string GroupName { get; set; } //=> GetName(RoughType)
        public string Name { get; set; } //=> GetName(RoughType)
        public string SarinActivity { get; set; }
        public bool IsPrintSubRoughDetail { get; set; }
        public StringBuilder Comment { get; set; }
        public string PriceList { get; set; }
        public string SieveSizeFileName { get; set; }

        //Navigation Properties
        //public virtual Rough Rough { get; set; }
        public virtual RoughType RoughType { get; set; }
        public virtual RoughColorShade RoughColorShade { get; set; }
        public virtual Employee Employee { get; set; }
        public virtual RoughSize RoughSize { get; set; }
        public virtual SieveSizeFileImport SieveSizeFileImport { get; set; }
        public virtual ICollection<Lot> Lots { get; set; }
        public virtual ICollection<Loss> Losses { get; set; }
        public virtual ICollection<Rejection> Rejections { get; set; }

        public string MakeableEntryDateFormat => MakeableEntryDate?.ToString($"{DateFormat} {TimeFormat}");
    }

    internal sealed class SubRoughMetadata
    {
        [Display(Name = "Sub Rough Type")]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        public int RoughTypeId { get; set; }

        [Display(Name = "Color Shade")]
        public int? RoughColorShadeId { get; set; }

        [Range(CutNumberMinValue, CutNumberMaxValue, ErrorMessage = "Cut number must be between 1 to 30")]
        [Display(Name = "Cut Number")]
        public int? Number { get; set; }

        [Display(Name = "Rough Cut Size")]
        public int? RoughSizeId { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), DecimalPositiveMinValue, WeightMaxValue, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Weight")]
        public decimal? Weight { get; set; }

        //[DisplayFormat(DataFormatString = NumberFormatString, ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Range(IntPositiveMinValue, PieceMaxValue, ErrorMessage = NumberPositiveZeroErrorMessage)]
        [RegularExpression(DigitOneToMaxFourDigitRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Display(Name = "Piece(s)")]
        public int? PieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), DecimalPositiveMinValue, WeightMaxValue, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Display(Name = "Makeable Weight")]
        public decimal? MakeableWeight { get; set; }

        [Range(IntPositiveMinValue, PieceMaxValue, ErrorMessage = NumberPositiveZeroErrorMessage)]
        [RegularExpression(DigitOneToMaxFourDigitRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Display(Name = "Makeable Piece(s)")]
        public short? MakeablePieceCount { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), DecimalPositiveMinValue, WeightMaxValue, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Display(Name = "Makeable Tops Weight")]
        public decimal? MakeableTopsWeight { get; set; }

        [Range(IntPositiveMinValue, PieceMaxValue, ErrorMessage = NumberPositiveZeroErrorMessage)]
        [RegularExpression(DigitOneToMaxFourDigitRegEx, ErrorMessage = NumberOnlyErrorMessage)]
        [Display(Name = "Makeable Tops Piece(s)")]
        public short? MakeableTopsPieces { get; set; }


        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Assigned To")]
        public int EmployeeId { get; set; }

        [Display(Name = "Assigned On")]
        [DisplayFormat(DataFormatString = DateTimeFormatString, ApplyFormatInEditMode = true)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        public DateTime AssignedOn { get; set; } = DateTime.Now;

        [DisplayFormat(DataFormatString = DateTimeFormatString)]
        public DateTime? MakeableEntryDate { get; set; }

        [DisplayFormat(DataFormatString = DateTimeFormatString)]
        public DateTime? MakeableTopsEntryDate { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), LowerLimitPolishedDiameter, UpparLimitMinPolishedDiameter, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Min Polished Diameter")]
        public decimal? RoughMinPolishedDiameter { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), LowerLimitPolishedDiameter, UpparLimitTopsPolishedDiameter, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Required(ErrorMessage = RequiredValidationErrorMessage)]
        [Display(Name = "Tops Polished Diameter")]
        public decimal? RoughTopsPolishedDiameter { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), LowerLimitPolishedDiameter, UpparLimitMinPolishedDiameter, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Display(Name = "Min Polished Diameter")]
        public decimal? MakeableMinPolishedDiameter { get; set; }

        [DisplayFormat(DataFormatString = DecimalFormatString, ApplyFormatInEditMode = true)]
        [Range(typeof(decimal), LowerLimitPolishedDiameter, UpparLimitTopsPolishedDiameter, ErrorMessage = DecimalWeightErrorMessage)]
        [RegularExpression(DecimalPositiveValidationRegEx, ErrorMessage = DecimalValidationErrorMessage)]
        [Display(Name = "Tops Polished Diameter")]
        public decimal? MakeableTopsPolishedDiameter { get; set; }

        [Display(Name = "SieveSize File")]
        //[Required(ErrorMessage = RequiredValidationErrorMessage)]
        public int? SieveSizeFileImportId { get; set; }

        [Display(Name = "Is Lot By Size")]
        public bool IsLotBySize { get; set; }

        public string Description { get; set; }
    }
}
