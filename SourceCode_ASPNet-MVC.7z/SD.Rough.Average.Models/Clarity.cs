﻿using System;

namespace SD.Rough.Average.Models
{
    public class Clarity : BaseEntity
    {
        public string Name { get; set; }
        public string GroupName { get; set; }

        public DateTime EffectiveFrom { get; set; }

        public int DisplayOrder { get; set; }
    }

    public class ClarityTemporal : BaseEntity
    {
        public string Name { get; set; }
        public string GroupName { get; set; }

        public DateTime EffectiveFrom { get; set; }
        public DateTime EffectiveTo { get; set; }

        public int DisplayOrder { get; set; }
    }
}
