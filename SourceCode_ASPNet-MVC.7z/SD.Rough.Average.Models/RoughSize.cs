﻿namespace SD.Rough.Average.Models
{
    using System.Collections.Generic;

    public class RoughSize : BaseEntity
    {
        #region Ctor
        public RoughSize()
        {
            RoughSizeSieveSizes = new HashSet<RoughSizeSieveSize>();
        }
        #endregion

        #region Properties
        public string Name { get; set; }
        public string DisplayName { get; set; }
        public int DisplayOrder { get; set; }
        public string Description { get; set; }

        //Navigation Properties
        public virtual ICollection<RoughSizeSieveSize> RoughSizeSieveSizes { get; set; }
        public virtual ICollection<RoughSizePolishedSieveSize> RoughSizePolishedSieveSizes { get; set; }
        #endregion
    }
}
