﻿namespace SD.Rough.Average.Models
{
    public enum MeasurementParameters
    {
        Diameter,
        Length
    }    

    public class Shape : BaseEntity
    {
        public string Name { get; set; }
        public string MeasurementBy { get; set; }
        public string Description { get; set; }
    }
}
