/* File: gulpfile.js */

// grab our gulp packages
var gulp  = require('gulp'),
    less = require('gulp-less');

//Creates a less task and converts to css
gulp.task('less', function () {
  return gulp.src('SD.Rough.Average.Web/Content/less/style.less')
    .pipe(less())
    .pipe(gulp.dest('SD.Rough.Average.Web/Content/')); // your output folder
});

// create a default task and just log a message
gulp.task('default', gulp.parallel('less'));