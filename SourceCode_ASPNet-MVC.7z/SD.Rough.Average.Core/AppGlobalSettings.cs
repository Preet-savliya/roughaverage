﻿using System;
using System.Configuration;

namespace SD.Rough.Average.Core
{
    public static class AppGlobalSettings
    {
        public static string RoughAverageDBConnStringKey => GetConfigAppSettingValue("AppDbConnStringKey");

        #region Application-Related
        public static string ApplicationName = GetConfigAppSettingValue("ApplicationName");

        public const string RoughSarinActivity = "Rough Planning";
        public const string MakeableSarinActivity = "Makeable Planning";

        public static int IntMaxValue = Convert.ToInt32(GetConfigAppSettingValue("IntMaxValue"));
        public static int StatusCode => Convert.ToInt32(GetConfigAppSettingValue("StatusCode")); // Custom status code 
        public static string InvalidEntryMessage => "Entry does not exists";
        
        public static char FileDataSeparator => Convert.ToChar(GetConfigAppSettingValue("FileDataSeparator"));
        public static char FileExtensionSeparator => Convert.ToChar(GetConfigAppSettingValue("FileExtensionSeparator"));
        public static char SortColumnSeparator => Convert.ToChar(GetConfigAppSettingValue("SortColumnSeparator"));
        public static string LotDetailSeparator => (GetConfigAppSettingValue("LotDetailSeparator"));
        public static char FileNameSeparator => Convert.ToChar(GetConfigAppSettingValue("FileNameSeparator"));
        public static char EntityValueSeprator => Convert.ToChar(GetConfigAppSettingValue("EntityValueSeprator"));
        public static string LotFileExtension => GetConfigAppSettingValue("LotFileExtension");
        public static string LessThanValueText => GetConfigAppSettingValue("LessThanValueText");
        public static string GreaterThanValueText => GetConfigAppSettingValue("GreaterThanValueText");
        public static string PlusSign => GetConfigAppSettingValue("PlusSign");
        public static string MinusSign => GetConfigAppSettingValue("MinusSign");
        public static string MinSieveSizeForPointer => GetConfigAppSettingValue("MinSieveSizeForPointer");
        public static string RoughTypeSeparator => GetConfigAppSettingValue("RoughTypeSeparator");
        public static decimal WhitenerRange => Convert.ToDecimal(GetConfigAppSettingValue("WhitenerRange"));
        public static string RoughCategoryName => GetConfigAppSettingValue("RoughCategoryName");
        public static string MeasureTypeCode => GetConfigAppSettingValue("MeasureTypeCode");
        public static DateTime MakeableEntryEffectiveDate => Convert.ToDateTime(GetConfigAppSettingValue("MakeableEntryEffectiveDate"));

        //File path
        public static string LocalPath => GetConfigAppSettingValue("LocalPath"); 

        public static int DefaultPartsCount 
            => Convert.ToInt32(GetConfigAppSettingValue("DefaultPartsCount"));
        public static string LotFileHeadersFilePath 
            => GetConfigAppSettingValue("LotFileHeadersFilePath");

        // SieveSize file import detail
        public static int DiameterDecimalPlace => Convert.ToInt32(GetConfigAppSettingValue("DiameterDecimalPlace"));
        public static string SieveSizeFileExtension = GetConfigAppSettingValue("SieveSizeFileExtension");
        public static string SieveSizeAttributeMinDiameter = GetConfigAppSettingValue("SieveSizeAttributeMinDiameter");
        public static string SieveSizeAttributeMaxDiameter = GetConfigAppSettingValue("SieveSizeAttributeMaxDiameter");
        public static string SieveSizeAttributeName = GetConfigAppSettingValue("SieveSizeAttributeName");
        public static string SieveSizeFileElement = GetConfigAppSettingValue("SieveSizeFileElement");
        public static string SieveSizeAttributeMinDiameterUpTo = GetConfigAppSettingValue("SieveSizeAttributeMinDiameterUpTo");
        #endregion

        #region UIProperties
        //public const string DateFormatValue = "{0:dd-MMM-yyyy}"; //GetConfigAppSettingValue("DateFormat");
        public static string DateFormat => GetConfigAppSettingValue("DateFormat");
        public static string TimeFormat => GetConfigAppSettingValue("TimeFormat");
        public static string StoneDateFormat => GetConfigAppSettingValue("StoneDateFormat");

        //public const string DateTimeFormatValue = "{0:dd/MM/yyyy hh:mm tt}";
        public static string DateTimeFormat => GetConfigAppSettingValue("DateTimeFormat");

        public const int ConstantPageSize = 100;
        public static int PageSize => Convert.ToInt32(GetConfigAppSettingValue("PageSize"));

        //public static string NumberFormat => $"{{0: {GetConfigAppSettingValue("NumberFormat")}}}";
        public static string NumberFormat => GetConfigAppSettingValue("NumberFormat");
        public static string DecimalNumberFormat => $"{{0: {GetConfigAppSettingValue("DecimalNumberFormat")}}}";
        public static decimal ValidateWeight => Convert.ToDecimal(GetConfigAppSettingValue("ValidateWeightValue"));
        #endregion

        private static string GetConfigAppSettingValue(string key) => ConfigurationManager.AppSettings[key]?.ToString() ?? string.Empty;
    }
}
