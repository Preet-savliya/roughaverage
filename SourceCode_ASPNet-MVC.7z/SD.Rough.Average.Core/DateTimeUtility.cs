﻿using System;

namespace SD.Rough.Average.Core
{
    public static class DateTimeUtility
    {
        public static DateTime ChangeTime(DateTime inputDateTime)
            => inputDateTime.AddDays(1).Date.AddSeconds(-1);
    }   
}
