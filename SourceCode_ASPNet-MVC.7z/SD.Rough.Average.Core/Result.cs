﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace SD.Rough.Average.Core
{
    public struct Unit
    {
        public static readonly Unit Value = new Unit();
    }

    public class Result<T>
    {
        public bool IsSuccess { get; }
        public bool IsFailure => !IsSuccess;
        public string Error { get; }
        public T Value { get; }

        private Result(T value, bool isSuccess, string error)
        {
            //if (isSuccess && error != null)
            //    throw new InvalidOperationException("Successful result cannot have an error message.");

            //if (!isSuccess && value != null)
            //    throw new InvalidOperationException("Failure result cannot have a value.");

            IsSuccess = isSuccess;
            Error = error;

            Value = value;
        }

        public static Result<T> Success(T value) => new Result<T>(value, true, null);

        public static Result<T> Failure(string error) => new Result<T>(default(T), false, error);

        // --- Functional Chaining ---
        // If success, run the given function, else propagate failure
        public Result<K> Bind<K>(Func<T, Result<K>> func)
        {
            if (IsFailure)
                return Result<K>.Failure(Error);

            return func(Value);
        }

        // Map success value to another type
        public Result<K> Map<K>(Func<T, K> func)
        {
            if (IsFailure)
                return Result<K>.Failure(Error);

            return Result<K>.Success(func(Value));
        }

        // Run side-effect only on success
        public Result<T> OnSuccess(Action<T> action)
        {
            if (IsSuccess)
                action(Value);
            return this;
        }

        // Run side-effect only on failure
        public Result<T> OnFailure(Action<string> action)
        {
            if (IsFailure)
                action(Error);
            return this;
        }
    }

    public static class ResultExtensions
    {
        // Convert List<Result<T>> → Result<List<T>>
        public static Result<List<T>> ToResultList<T>(this IEnumerable<Result<T>> results)
        {
            var values = new List<T>();

            foreach (var result in results)
            {
                if (result.IsFailure)
                    return Result<List<T>>.Failure(result.Error);

                values.Add(result.Value);
            }

            return Result<List<T>>.Success(values);
        }

        // Optional: collect *all* errors instead of failing fast
        public static Result<List<T>> ToResultListCollectErrors<T>(this IEnumerable<Result<T>> results)
        {
            var values = new List<T>();
            var errors = new List<string>();

            foreach (var result in results)
            {
                if (result.IsFailure)
                    errors.Add(result.Error);
                else
                    values.Add(result.Value);
            }

            if (errors.Any())
                return Result<List<T>>.Failure(string.Join("; ", errors));

            return Result<List<T>>.Success(values);
        }
    }


    public class Either<T, E>
    {
        public bool IsSuccess { get; }
        public bool IsFailure => !IsSuccess;

        public T Value { get; }
        public E Error { get; }

        private Either(T value, E error, bool isSuccess)
        {
            IsSuccess = isSuccess;
            Value = value;
            Error = error;
        }

        public static Either<T, E> Success(T value) =>
            new Either<T, E>(value, default(E), true);

        public static Either<T, E> Failure(E error) =>
            new Either<T, E>(default(T), error, false);

        // --- Functional chaining ---
        public Either<K, E> Bind<K>(Func<T, Either<K, E>> func)
        {
            if (IsFailure)
                return Either<K, E>.Failure(Error);

            return func(Value);
        }

        public Either<K, E> Map<K>(Func<T, K> func)
        {
            if (IsFailure)
                return Either<K, E>.Failure(Error);

            return Either<K, E>.Success(func(Value));
        }

        public Either<T, E> OnSuccess(Action<T> action)
        {
            if (IsSuccess)
                action(Value);
            return this;
        }

        public Either<T, E> OnFailure(Action<E> action)
        {
            if (IsFailure)
                action(Error);
            return this;
        }
    }

    public static class EitherExtensions
    {
        // Fail-fast: stop on first failure
        public static Either<List<T>, E> ToResultList<T, E>(this IEnumerable<Either<T, E>> results)
        {
            var values = new List<T>();

            foreach (var result in results)
            {
                if (result.IsFailure)
                    return Either<List<T>, E>.Failure(result.Error);

                values.Add(result.Value);
            }

            return Either<List<T>, E>.Success(values);
        }

        // Collect all errors if E is List<string>
        public static Either<List<T>, List<E>> ToResultListCollectErrors<T, E>(this IEnumerable<Either<T, E>> results)
        {
            var values = new List<T>();
            var errors = new List<E>();

            foreach (var result in results)
            {
                if (result.IsFailure)
                    errors.Add(result.Error);
                else
                    values.Add(result.Value);
            }

            if (errors.Any())
                return Either<List<T>, List<E>>.Failure(errors);

            return Either<List<T>, List<E>>.Success(values);
        }
    }

}
