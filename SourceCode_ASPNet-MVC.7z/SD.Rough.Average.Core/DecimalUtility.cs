﻿namespace SD.Rough.Average.Core
{
    public class DecimalUtility
    {
        public static Result<decimal> Parse(string inputValue, string fieldName)
        {
            var value = inputValue.Trim();

            if (string.IsNullOrEmpty((string)value))
            {
                return Result<decimal>.Failure($"{fieldName} value is empty.");
            }

            var parseResult = decimal.TryParse(value, out decimal decimalValue);

            return parseResult
                ? Result<decimal>.Success(decimalValue)
                : Result<decimal>.Failure($"{fieldName} value is not a valid decimal value.");
        }
    }
}
