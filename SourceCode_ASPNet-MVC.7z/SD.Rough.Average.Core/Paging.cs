﻿using System;

namespace SD.Rough.Average.Core
{
    public static class Paging
    {
        public static int GetTotalPageCount(int totalRecord, int pageSize) 
            => totalRecord > 0 ? (int)Math.Ceiling((double)totalRecord / pageSize) : 1;

        public static int GetMinPageIndex(int totalRecord, int pageNumber, int pageSize) 
            => totalRecord > 0 ? (((pageNumber - 1) * pageSize)) : 0;

        public static int GetMaxPageIndex(int totalRecord, int minPageIndex, int pageSize) 
            => ((minPageIndex + pageSize) > totalRecord) ? totalRecord : (minPageIndex + pageSize);
    }
}
