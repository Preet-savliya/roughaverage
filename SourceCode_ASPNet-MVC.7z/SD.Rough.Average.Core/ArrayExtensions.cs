﻿using System.Linq;
using System.Runtime.CompilerServices;

namespace SD.Rough.Average.Core
{
    public static class ArrayExtensions
    {
        public static string[] SubArray(this string[] data, int startIndex, int length)
        {
            return data
                .Skip(startIndex)
                .Take(length)
                //.Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(v => v.Trim())
                .ToArray();
        }

        public static int MaxIndexOfNonEmptyValue(this string[] data)
        {
            var entries = data
                .Select((value, index) => new { Index = index, Value = value })
                .Where(s => !string.IsNullOrWhiteSpace(s.Value))
                .ToArray();

            if (entries.Length == 0)
                return -1;

            return entries.Max(g => g.Index);
        }
    }
}
