﻿using System.ComponentModel.DataAnnotations;

namespace SD.Rough.Average.Core
{    
    public enum DropdownDefaultValue
    {
        None,
        All,
        Select
    }

    public enum ImportAction
    {
        [Display(Name = "New Import")]
        New = 1,
        [Display(Name = "Overwrite Existing")]
        Overwrite = 2
    }

    public enum EntryStatus
    {
        All = 0,
        Active = 1,
        Deleted = 2
    }

    public enum ChangeEntryStatusCommand
    {
        Activate = 1,
        DeActivate
    }

    public enum ProgressStatus
    {
        LotPending,
        LotImportPending,
        Complete
    }

    public enum Status
    {
        MisMatch,
        InComplete,
        Pending,
        Complete
    }

    public enum TopsType
    {
        Many,
        None,
        Polished,
        Rough,
        NotSpecified
    }

    public enum LossTypeCode
    {
        LSL,
        DMG,
        OTH,
        L,
        GL,
        LSD
    }
}