﻿namespace SD.Rough.Average.Core.Validation
{
    public static class ValidationGlobalSettings
    {

        public const string DateFormatString = "{0:dd-MMM-yyyy}";
        public const string TimeFormatString = "{0:h:mm tt}";
        public const string FileTimeFormatString = @"hh\:mm";
        public const string DateTimeFormatString = "{0:dd-MMM-yyyy HH:mm}";
        public const string DecimalFormatString = "{0:#,##0.000}";
        public const string TwoDecimalFormatString = "{0:#,##0.00}";
        public const string NumberFormatString = "{0:#,##0}";
        public const string PercentageDisplayString = "{0:P2}";
        public const string DecimalPositiveMinValue = "0.010";
        public const string DecimalMinValue = "0.010";
        public const string DefaultValue = "0";
        public const string LowerLimitPolishedDiameter = "0.000";
        public const string UpparLimitMinPolishedDiameter = "2.000";
        public const decimal DecimalDefaultValue = 0.0M;
        public const string WeightMaxValue = "5000.000";
        public const string UpparLimitTopsPolishedDiameter = "2.210";
        public const int IntDefaultValue = 0;
        public const int IntPositiveMinValue = 1;
        public const int PieceMaxValue = 10000;
        public const short CutNumberMinValue = 1;
        public const short CutNumberMaxValue = 30;

        public const string DateValidationRegEx = @"^(([1-9])|([0-2][0-9])|([3][0-1]))\-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\-\d{4}$";
        public const string DecimalPositiveValidationRegEx = @"^[\d]{0,7}([.,][\d]{0,3})?";
        public const string DigitOneToMaxFourDigitRegEx = @"^\d{0,5}";
        public const string TimeValidationRegEx = @"^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$";
        public const string NumericRegEx = "^[0-9]+$";
        public const string AlphaNumericWithDotSpaceRegEx = "^[a-zA-Z0-9.\\s]*$";
        public const string AlphaNumericWithSpaceRegEx = "^[a-zA-Z0-9\\s]*$";
        public const string AlphaNumericRegEx = "^[a-zA-Z0-9]*$";
        public const string AlphaNumericWithHyphenPlusDotSpaceRegEx = "^[a-zA-Z0-9.\\-\\+\\s]*$";
        public const string NumericWithHyphenPlusSpaceRegEx = "^[0-9-\\+\\s]*$";
        public const string NumericWithHyphenPlusSlashRegEx = "^[0-9-\\+\\/]*$";
        public const string NumericWithHyphenPlusDotSpaceRegEx = "^[0-9.\\-\\+\\s]*$";
        public const string AlphaRegEx = "^[a-zA-Z]*$";
        public const string NumericAndComaRegEx = "^[0-9\\,]*$";

        public const string TimeValidationErrorMessage = @"Invalid Time.";
        public const string DecimalValidationErrorMessage = @"{0} must be a positive number with maximum 3 decimal values.";
        public const string RequiredValidationErrorMessage = @"{0} is required.";
        public const string NumberPositiveZeroErrorMessage = @"{0} value must be between 1 to 10000.";
        public const string NumberDefaultErrorMessage = @"{0} value must be between 0 to 10000.";
        public const string DecimalPositiveZeroErrorMessage = @"{0} cannot be negative.";
        public const string DecimalWeightErrorMessage = @"{0} is not valid weight.";
        public const string NumberOnlyErrorMessage = @"{0} have invalid number.";
        public const string ValueLessThanErrorMessage = @"{0} must be less than {1}.";
        public const string SuccessMessage = @"Success.";
        public const string DataMissingMessage = @"Required data missing.";
        public const string RecordExistMessage = @"Record already exists.";
        public const string InValidErrorMessage = @"{0} is invalid.";
    }
}
